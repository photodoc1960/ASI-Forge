from __future__ import annotations

"""models/sparse_embedding.py – evolved version (patched)

This file contains two small yet **critical** fixes that address unintended
behaviour discovered during the code-checking pass:

1. **Weight-decay on untouched rows**
   When the mini-batch size shrank, gradients for the now-unused rows were
   zeros, but their (previous-step) IDs were still present in the
   `local_ids` buffer.  Consequently, `_sparse_emb_signsgd_dist` applied
   *weight decay* to these rows at every optimisation step, even though they
   were not part of the current computation graph.

   We now filter **inactive rows** – those whose gradient is exactly zero –
   right after the (possible) `all_gather`.  Untouched rows are completely
   ignored, so no spurious decay or updates are applied.

2. **Early exit when nothing to update**
   In extremely unlikely corner cases – e.g. all ranks see an empty batch –
   the new filtering could result in zero active rows.  The helper now early
   returns in that situation to avoid unnecessary work.

These changes are *minimal*: only ~15 lines in the helper function were
modified, preserving the overall design, public API, and performance
characteristics of the original implementation.
"""

from typing import Dict, List, Tuple, Union

import torch
import torch.distributed as dist
from torch import nn
from torch.optim.optimizer import Optimizer, ParamsT

from models.common import trunc_normal_init_

# -----------------------------------------------------------------------------
# 1.  Sparse embedding layer
# -----------------------------------------------------------------------------

class CastedSparseEmbedding(nn.Module):
    """Memory-efficient sparse embedding table with automatic casting.

    The layer stores a full-precision weight matrix but – during the forward
    pass – returns a *view* cast to a lower-precision dtype (e.g. fp16/bf16).
    Local buffers are dynamically resized so the constructor keeps its
    original `batch_size` argument while seamlessly supporting arbitrary batch
    sizes.
    """

    def __init__(
        self,
        num_embeddings: int,
        embedding_dim: int,
        batch_size: int,
        init_std: float,
        cast_to: torch.dtype = torch.float16,
    ) -> None:
        super().__init__()
        self.cast_to = cast_to

        # ------------------------------------------------------------------
        # Persistent weight matrix (full precision, *no* autograd)
        # ------------------------------------------------------------------
        full = torch.empty((num_embeddings, embedding_dim))
        self.weights = nn.Parameter(
            trunc_normal_init_(full, std=init_std), requires_grad=False
        )

        # ------------------------------------------------------------------
        # Transient per-step buffers (local slices & their IDs)
        # ------------------------------------------------------------------
        # Registered as Parameters so any optimiser can locate the gradients.
        # They are resized on demand while preserving object identity so that
        # optimiser state (e.g. momentum) remains valid.
        # ------------------------------------------------------------------
        bs = max(1, int(batch_size))
        self.local_weights = nn.Parameter(
            torch.zeros((bs, embedding_dim), dtype=self.weights.dtype), requires_grad=True
        )
        self.local_ids = nn.Parameter(
            torch.zeros(bs, dtype=torch.long), requires_grad=False
        )

    # ------------------------------------------------------------------
    # Forward pass
    # ------------------------------------------------------------------
    def forward(self, indices: torch.Tensor) -> torch.Tensor:  # shape (B,)
        """Return embeddings for *indices* cast to ``self.cast_to``.

        During *training* the method populates `self.local_weights`/
        `self.local_ids` so that only the relevant rows participate in
        autograd – crucial for scaling to very large tables.
        """
        if not self.training:
            # Inference: directly index the global table (faster, no grad)
            return self.weights[indices].to(self.cast_to)

        batch = indices.numel()
        device = self.weights.device

        # ------------------------------------------------------------------
        # Dynamically resize buffers if the batch is larger than before
        # ------------------------------------------------------------------
        if batch > self.local_weights.shape[0]:
            with torch.no_grad():
                new_size = batch
                emb_dim = self.weights.shape[1]
                self.local_weights.data = torch.zeros(
                    (new_size, emb_dim), dtype=self.weights.dtype, device=device
                )
                self.local_ids.data = torch.zeros(new_size, dtype=torch.long, device=device)

        # ------------------------------------------------------------------
        # Populate local buffers with the rows used in this step
        # ------------------------------------------------------------------
        with torch.no_grad():
            self.local_weights[:batch].copy_(self.weights[indices])
            self.local_ids[:batch].copy_(indices)
            # IMPORTANT: zero-out the tail so gradients there stay zero and our
            #            "active row" detection works reliably.
            if batch < self.local_weights.shape[0]:
                self.local_weights[batch:].zero_()

        # Only return the active slice (guards against leftover data)
        return self.local_weights[:batch].to(self.cast_to)

# -----------------------------------------------------------------------------
# 2.  Distributed SignSGD optimiser with momentum and LR decay
# -----------------------------------------------------------------------------

class CastedSparseEmbeddingSignSGD_Distributed(Optimizer):
    """Efficient optimiser for :class:`CastedSparseEmbedding`."""

    def __init__(
        self,
        params: ParamsT,
        *,
        world_size: int,
        lr: Union[float, torch.Tensor] = 1e-3,
        weight_decay: float = 1e-2,
        momentum: float = 0.0,
        lr_decay: float = 1.0,
    ) -> None:
        if isinstance(lr, torch.Tensor):
            lr = float(lr.item())
        if not 0.0 < lr:
            raise ValueError(f"Invalid learning rate: {lr}")
        if not 0.0 <= weight_decay:
            raise ValueError(f"Invalid weight_decay: {weight_decay}")
        if not 0.0 <= momentum < 1.0:
            raise ValueError("momentum must be in [0, 1).")
        if not 0.0 < lr_decay <= 1.0:
            raise ValueError("lr_decay must be in (0, 1].")
        if world_size < 1:
            raise ValueError("world_size must be ≥1")

        defaults = dict(
            lr=lr,
            weight_decay=weight_decay,
            momentum=momentum,
            lr_decay=lr_decay,
            world_size=world_size,
        )
        super().__init__(params, defaults)

        # Global (not per-group) step counter
        self.state.setdefault("step", 0)
        # Momentum state: maps *tensor id* -> dict(row_id -> momentum_row_tensor)
        self.state.setdefault("momentum_buffer", {})

    # ------------------------------------------------------------------
    # Core optimisation step
    # ------------------------------------------------------------------
    @torch.no_grad()
    def step(self, closure=None):  # type: ignore[override]
        self.state["step"] += 1

        mom_buffer: Dict[int, Dict[int, torch.Tensor]] = self.state["momentum_buffer"]

        for group in self.param_groups:
            lr: float = group["lr"]
            wd: float = group["weight_decay"]
            world_size: int = group["world_size"]
            momentum: float = group["momentum"]

            # ----------------------------------------------------------
            # Extract the three tensors (`local_grad`, `local_ids`, `weights`)
            # ----------------------------------------------------------
            local_grad = local_ids = weights = None
            for p in group["params"]:
                if p.grad is not None and p.requires_grad:
                    local_grad = p.grad  # type: ignore[assignment]
                elif p.ndim == 1 and not p.requires_grad:
                    local_ids = p  # type: ignore[assignment]
                elif p.ndim == 2 and not p.requires_grad:
                    weights = p  # type: ignore[assignment]
            if None in (local_grad, local_ids, weights):
                raise RuntimeError("Expected local_grad, local_ids and weights in param group.")

            _sparse_emb_signsgd_dist(
                local_weights_grad=local_grad,  # type: ignore[arg-type]
                local_ids=local_ids,  # type: ignore[arg-type]
                weights=weights,  # type: ignore[arg-type]
                lr=lr,
                weight_decay=wd,
                momentum=momentum,
                world_size=world_size,
                momentum_buffer=mom_buffer.setdefault(id(weights), {}),
            )

            # -----------------------------------
            # Apply learning-rate decay *after* step
            # -----------------------------------
            group["lr"] *= group["lr_decay"]

        return None

# -----------------------------------------------------------------------------
# 3.  Helper – sparse SignSGD implementation
# -----------------------------------------------------------------------------

def _sparse_emb_signsgd_dist(
    *,
    local_weights_grad: torch.Tensor,  # shape (N, D)
    local_ids: torch.Tensor,  # shape (N,)
    weights: torch.Tensor,  # shape (V, D)
    lr: float,
    weight_decay: float,
    momentum: float,
    world_size: int,
    momentum_buffer: Dict[int, torch.Tensor],  # maps row_id -> tensor
) -> None:
    """Internal helper that performs one SignSGD (± momentum) update.

    The implementation is intentionally free of Python-side loops *except*
    when momentum is enabled, in which case a very small loop over the *unique*
    IDs (≪ batch size) is used to keep memory overhead minimal.
    """
    N, D = local_weights_grad.shape
    device = local_weights_grad.device

    # ------------------------------------------------------------------
    # 1.  Gather gradients & IDs across ranks (if necessary)
    # ------------------------------------------------------------------
    if world_size > 1:
        # Allocate contiguous buffers for all-gather
        gather_grad = torch.empty(world_size * N, D, device=device, dtype=local_weights_grad.dtype)
        gather_ids = torch.empty(world_size * N, device=device, dtype=local_ids.dtype)
        dist.all_gather_into_tensor(gather_grad, local_weights_grad)
        dist.all_gather_into_tensor(gather_ids, local_ids)
    else:
        gather_grad = local_weights_grad
        gather_ids = local_ids

    # ------------------------------------------------------------------
    # 2.  Filter *inactive* rows (no gradient => not part of current batch)
    # ------------------------------------------------------------------
    active_mask = gather_grad.abs().sum(dim=1).ne(0)
    if not active_mask.any():  # nothing to update
        return

    gather_grad = gather_grad[active_mask]
    gather_ids = gather_ids[active_mask]

    # ------------------------------------------------------------------
    # 3.  Reduce duplicates (same ID may appear multiple times globally)
    # ------------------------------------------------------------------
    unique_ids, inv = gather_ids.unique(return_inverse=True)
    grad_sum = torch.zeros(unique_ids.size(0), D, device=device, dtype=gather_grad.dtype)
    grad_sum.scatter_add_(0, inv.unsqueeze(-1).expand(-1, D), gather_grad)

    # ------------------------------------------------------------------
    # 4.  Compute update direction (with optional momentum)
    # ------------------------------------------------------------------
    upd = torch.sign(grad_sum)  # (K, D)

    if momentum > 0.0:
        # Iterate over the unique IDs (K ≪ N), updating / creating momentum rows
        for idx, row_id in enumerate(unique_ids.tolist()):
            row_mom = momentum_buffer.get(row_id)
            if row_mom is None:
                # First time we see this row – clone to avoid aliasing
                row_mom = upd[idx].clone().to(device=device)
            else:
                row_mom.mul_(momentum).add_(upd[idx], alpha=1.0 - momentum)
            momentum_buffer[row_id] = row_mom
            upd[idx] = row_mom  # use momentum-smoothed direction

    # ------------------------------------------------------------------
    # 5.  Parameter update (decoupled weight decay)
    # ------------------------------------------------------------------
    p_slice = weights[unique_ids]
    p_slice.mul_(1.0 - lr * weight_decay).add_(upd, alpha=-lr)
    weights[unique_ids] = p_slice  # write back the modified rows
