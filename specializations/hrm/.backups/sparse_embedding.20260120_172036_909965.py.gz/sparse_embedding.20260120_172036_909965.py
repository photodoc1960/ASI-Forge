from __future__ import annotations

"""models/sparse_embedding.py – evolved version

Key improvements over the baseline implementation:

1. CastedSparseEmbedding
   • The *local* buffers are now dynamically resized if a larger batch is
     encountered.  This removes the hard dependency on a fixed `batch_size`
     passed at construction time while keeping the public API unchanged.
   • Buffers are created as `nn.Parameter` objects so that the optimiser can
     reliably access gradients and state.
   • Additional safety checks guard against accidental dtype / device mismatch.

2. CastedSparseEmbeddingSignSGD_Distributed
   • Adds optional `momentum` (sparse – only the rows touched in a given step
     are stored) for faster and stabler convergence on noisy gradients.
   • Adds multiplicative `lr_decay` that is applied *after* every optimisation
     step, enabling simple yet effective learning-rate scheduling without an
     external scheduler object.
   • Keeps a global step counter (``optimizer.state["step"]``) useful for
     advanced scheduling strategies or logging.
   • Preserves the original SignSGD semantics when `momentum == 0` and
     `lr_decay == 1` so existing checkpoints remain valid.

3. Internal helper `_sparse_emb_signsgd_dist`
   • Now supports momentum in a memory-efficient way using a Python dict that
     stores *only* the momentum rows that have been updated at least once,
     avoiding a full copy of the potentially gigantic embedding table.
   • Minor micro-optimisations: re-uses buffers when possible and performs all
     heavy lifting inside vectorised PyTorch ops.

The public class names and signatures remain *unchanged*, ensuring full
backwards compatibility with the rest of the codebase.
"""

from typing import Dict, List, Tuple, Union

import torch
import torch.distributed as dist
from torch import nn
from torch.optim.optimizer import Optimizer, ParamsT

from models.common import trunc_normal_init_

# -----------------------------------------------------------------------------
# 1.  Sparse embedding layer
# -----------------------------------------------------------------------------

class CastedSparseEmbedding(nn.Module):
    """Memory-efficient sparse embedding table with automatic casting.

    The layer stores a full-precision weight matrix but – during the forward
    pass – it returns a *view* cast to a lower-precision dtype (e.g. fp16 or
    bf16).  To facilitate sparse updates, the layer allocates *local* buffers
    that contain only the rows actually used in the current forward pass.  The
    custom optimiser then updates the corresponding rows in the global weight
    matrix.
    """

    def __init__(
        self,
        num_embeddings: int,
        embedding_dim: int,
        batch_size: int,
        init_std: float,
        cast_to: torch.dtype = torch.float16,
    ) -> None:
        super().__init__()
        self.cast_to = cast_to

        # ------------------------------------------------------------------
        # Persistent weight matrix (full precision, *no* autograd)
        # ------------------------------------------------------------------
        full = torch.empty((num_embeddings, embedding_dim))
        self.weights = nn.Parameter(trunc_normal_init_(full, std=init_std), requires_grad=False)

        # ------------------------------------------------------------------
        # Transient per-step buffers (local slices & their IDs)
        # ------------------------------------------------------------------
        # Created as Parameters so the optimiser can easily find them.  They do
        # **not** accumulate gradients across steps (being overwritten each
        # forward call) so a custom optimiser is required.
        #
        # The buffers are *dynamically* resized to fit the largest batch seen
        # so far – this preserves object identity, keeping optimiser state
        # intact.
        # ------------------------------------------------------------------
        bs = max(1, int(batch_size))
        self.local_weights = nn.Parameter(
            torch.zeros((bs, embedding_dim), dtype=self.weights.dtype), requires_grad=True
        )
        self.local_ids = nn.Parameter(torch.zeros(bs, dtype=torch.long), requires_grad=False)

    # ------------------------------------------------------------------
    # Forward pass
    # ------------------------------------------------------------------
    def forward(self, indices: torch.Tensor) -> torch.Tensor:  # shape (B,)
        """Return embeddings for *indices* cast to ``self.cast_to``.

        During *training* the method populates `self.local_weights` /
        `self.local_ids` so that only the relevant rows participate in
        autograd – crucial for scaling to very large tables.
        """
        if not self.training:
            # Inference: directly index the global table (faster, no grad)
            return self.weights[indices].to(self.cast_to)

        batch = indices.numel()
        device = self.weights.device

        # ------------------------------------------------------------------
        # Dynamically resize the buffers if the batch is larger than before
        # ------------------------------------------------------------------
        if batch > self.local_weights.shape[0]:
            with torch.no_grad():
                new_size = batch
                emb_dim = self.weights.shape[1]
                self.local_weights.data = torch.zeros(
                    (new_size, emb_dim), dtype=self.weights.dtype, device=device
                )
                self.local_ids.data = torch.zeros(new_size, dtype=torch.long, device=device)

        # ------------------------------------------------------------------
        # Populate local buffers with the rows used in this step
        # ------------------------------------------------------------------
        with torch.no_grad():
            self.local_weights[:batch].copy_(self.weights[indices])
            self.local_ids[:batch].copy_(indices)

        # Only return the active slice (guards against leftover data)
        return self.local_weights[:batch].to(self.cast_to)

# -----------------------------------------------------------------------------
# 2.  Distributed SignSGD optimiser with momentum and LR decay
# -----------------------------------------------------------------------------

class CastedSparseEmbeddingSignSGD_Distributed(Optimizer):
    """Efficient optimiser for :class:`CastedSparseEmbedding`.

    Parameters
    ----------
    params : iterable
        Parameters to optimise – *must* come from exactly one
        :class:`CastedSparseEmbedding` instance.
    world_size : int
        Number of distributed ranks (≥1).  If ``1`` the optimiser behaves as a
        regular single-process optimiser.
    lr : float, default=1e-3
        Learning rate.
    weight_decay : float, default=1e-2
        Decoupled weight decay (L2 regularisation) coefficient.
    momentum : float, default=0.0
        Momentum term.  ``0`` disables momentum (original SignSGD behaviour).
        Must be in the interval ``[0, 1)``.
    lr_decay : float, default=1.0
        Multiplicative decay factor applied to ``lr`` *after* every optimisation
        step.  Values in ``(0, 1)`` implement exponential decay; ``1`` keeps the
        LR constant (baseline behaviour).
    """

    def __init__(
        self,
        params: ParamsT,
        *,
        world_size: int,
        lr: Union[float, torch.Tensor] = 1e-3,
        weight_decay: float = 1e-2,
        momentum: float = 0.0,
        lr_decay: float = 1.0,
    ) -> None:
        if isinstance(lr, torch.Tensor):
            lr = float(lr.item())
        if not 0.0 < lr:
            raise ValueError(f"Invalid learning rate: {lr}")
        if not 0.0 <= weight_decay:
            raise ValueError(f"Invalid weight_decay: {weight_decay}")
        if not 0.0 <= momentum < 1.0:
            raise ValueError("momentum must be in [0, 1).")
        if not 0.0 < lr_decay <= 1.0:
            raise ValueError("lr_decay must be in (0, 1].")
        if world_size < 1:
            raise ValueError("world_size must be ≥1")

        defaults = dict(
            lr=lr,
            weight_decay=weight_decay,
            momentum=momentum,
            lr_decay=lr_decay,
            world_size=world_size,
        )
        super().__init__(params, defaults)

        # Global (not per-group) step counter
        self.state.setdefault("step", 0)
        # Momentum state: maps *tensor id* -> dict(row_id -> momentum_row_tensor)
        self.state.setdefault("momentum_buffer", {})

    # ------------------------------------------------------------------
    # Core optimisation step
    # ------------------------------------------------------------------
    @torch.no_grad()
    def step(self, closure=None):  # type: ignore[override]
        self.state["step"] += 1

        mom_buffer: Dict[int, Dict[int, torch.Tensor]] = self.state["momentum_buffer"]

        for group in self.param_groups:
            lr: float = group["lr"]
            wd: float = group["weight_decay"]
            world_size: int = group["world_size"]
            momentum: float = group["momentum"]

            # ----------------------------------------------------------
            # Extract the three tensors (`local_grad`, `local_ids`, `weights`)
            # ----------------------------------------------------------
            local_grad = local_ids = weights = None
            for p in group["params"]:
                if p.grad is not None and p.requires_grad:
                    local_grad = p.grad  # type: ignore[assignment]
                elif p.ndim == 1 and not p.requires_grad:
                    local_ids = p  # type: ignore[assignment]
                elif p.ndim == 2 and not p.requires_grad:
                    weights = p  # type: ignore[assignment]
            if None in (local_grad, local_ids, weights):
                raise RuntimeError("Expected local_grad, local_ids and weights in param group.")

            _sparse_emb_signsgd_dist(
                local_weights_grad=local_grad,  # type: ignore[arg-type]
                local_ids=local_ids,  # type: ignore[arg-type]
                weights=weights,  # type: ignore[arg-type]
                lr=lr,
                weight_decay=wd,
                momentum=momentum,
                world_size=world_size,
                momentum_buffer=mom_buffer.setdefault(id(weights), {}),
            )

            # -----------------------------------
            # Apply learning-rate decay *after* step
            # -----------------------------------
            group["lr"] *= group["lr_decay"]

        return None

# -----------------------------------------------------------------------------
# 3.  Helper – sparse SignSGD implementation
# -----------------------------------------------------------------------------

def _sparse_emb_signsgd_dist(
    *,
    local_weights_grad: torch.Tensor,  # shape (N, D)
    local_ids: torch.Tensor,  # shape (N,)
    weights: torch.Tensor,  # shape (V, D)
    lr: float,
    weight_decay: float,
    momentum: float,
    world_size: int,
    momentum_buffer: Dict[int, torch.Tensor],  # maps row_id -> tensor
) -> None:
    """Internal helper that performs one SignSGD (± momentum) update.

    The implementation is intentionally free of Python-side loops *except* when
    momentum is enabled, in which case a very small loop over the *unique* IDs
    (≪ batch size) is used to keep memory overhead minimal.
    """
    N, D = local_weights_grad.shape
    device = local_weights_grad.device

    # ------------------------------------------------------------------
    # 1.  Gather gradients & IDs across ranks
    # ------------------------------------------------------------------
    if world_size > 1:
        # Allocate contiguous buffers for all-gather
        gather_grad = torch.empty(world_size * N, D, device=device, dtype=local_weights_grad.dtype)
        gather_ids = torch.empty(world_size * N, device=device, dtype=local_ids.dtype)
        dist.all_gather_into_tensor(gather_grad, local_weights_grad)
        dist.all_gather_into_tensor(gather_ids, local_ids)
    else:
        gather_grad = local_weights_grad
        gather_ids = local_ids

    # ------------------------------------------------------------------
    # 2.  Reduce duplicates (same ID may appear multiple times globally)
    # ------------------------------------------------------------------
    unique_ids, inv = gather_ids.unique(return_inverse=True)
    grad_sum = torch.zeros(unique_ids.size(0), D, device=device, dtype=gather_grad.dtype)
    grad_sum.scatter_add_(0, inv.unsqueeze(-1).expand(-1, D), gather_grad)

    # ------------------------------------------------------------------
    # 3.  Compute update direction (with optional momentum)
    # ------------------------------------------------------------------
    upd = torch.sign(grad_sum)  # (K, D)

    if momentum > 0.0:
        # Iterate over the unique IDs (K ≪ N), updating / creating momentum rows
        for idx, row_id in enumerate(unique_ids.tolist()):
            row_mom = momentum_buffer.get(row_id)
            if row_mom is None:
                # first time we see this row – clone to avoid aliasing
                row_mom = upd[idx].clone().to(device=device)
            else:
                row_mom.mul_(momentum).add_(upd[idx], alpha=1.0 - momentum)
            momentum_buffer[row_id] = row_mom
            upd[idx] = row_mom  # use momentum-smoothed direction

    # ------------------------------------------------------------------
    # 4.  Parameter update (decoupled weight decay)
    # ------------------------------------------------------------------
    p_slice = weights[unique_ids]
    p_slice.mul_(1.0 - lr * weight_decay).add_(upd, alpha=-lr)
    weights[unique_ids] = p_slice  # write back the modified rows
