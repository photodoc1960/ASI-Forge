from typing import List, Tuple, Dict, Callable
from dataclasses import dataclass
from pathlib import Path
import os
import json
import hashlib
import numpy as np
from glob import glob
from itertools import islice
from concurrent.futures import ProcessPoolExecutor, as_completed

from argdantic import ArgParser
from pydantic import BaseModel

from common import PuzzleDatasetMetadata, dihedral_transform

# =============================================================================
# NOTE:  IMPORTANT IMPLEMENTATION NOTE
# -----------------------------------------------------------------------------
# This module performs the heavy-lifting for converting raw ARC style puzzles
# into the training / validation / test splits used by downstream models.
#
# Historically, conversion relied on only two augmentation primitives:
#   (1) Arbitrary colour permutation (keeping 0=black fixed)
#   (2) 8-way dihedral (rotation / mirror) transformation
# While these operations are powerful, the original implementation suffered
# several practical issues:
#   • Inefficient sequential augmentation loop – O(N * retries) python loops
#   • Variable shadowing that caused confusing bugs and made tracing difficult
#   • No support for multi-process augmentation despite each example being
#     embarrassingly parallel.
#
# In this revision we:
#   • Refactor the augmentation logic into small, testable helper functions.
#   • Provide an optional multi-process back-end (enabled by default) that
#     utilises all available CPU cores for augmentation.
#   • Remove the variable shadowing bug where the name `puzzle` was reused.
#   • Introduce a configurable – yet sensible by default – retry schedule that
#     adapts to the requested number of augmentations.
#   • Guarantee deterministic behaviour driven by the global NumPy RNG seed.
#
# PUBLIC API AND CLASS NAMES ARE PRESERVED (convert_single_arc_puzzle et al.).
# =============================================================================

cli = ArgParser()


class DataProcessConfig(BaseModel):
    """Configuration for the ARC dataset conversion pipeline."""

    # ARC-1
    dataset_dirs: List[str] = [
        "dataset/raw-data/ARC-AGI/data",
        "dataset/raw-data/ConceptARC/corpus",
    ]
    output_dir: str = "data/arc-aug-1000"

    # ARC-2 (commented – left here for convenience)
    # dataset_dirs: List[str] = ["dataset/raw-data/ARC-AGI-2/data"]
    # output_dir: str = "data/arc-2-aug-1000"

    seed: int = 42
    num_aug: int = 1000  # number of *extra* augmented variants per puzzle

    # Advanced options (kept out of __init__ signature by providing defaults)
    max_workers: int = os.cpu_count() or 1  # parallel workers for augmentation
    max_retry_factor: int = 5  # retries factor when searching for unique augs


# -----------------------------------------------------------------------------
# Global constants
# -----------------------------------------------------------------------------
ARCMaxGridSize = 30

# -----------------------------------------------------------------------------
# Data classes & helpers
# -----------------------------------------------------------------------------


@dataclass
class ARCPuzzle:
    id: str
    examples: List[Tuple[np.ndarray, np.ndarray]]


# -----------------------------------------------------------------------------
# Utility functions
# -----------------------------------------------------------------------------

def arc_grid_to_np(grid: List[List[int]]) -> np.ndarray:
    """Validate and convert a single raw grid into the canonical np.uint8 form."""
    arr = np.asarray(grid, dtype=np.uint8)
    # Shape check
    if arr.ndim != 2 or arr.shape[0] > ARCMaxGridSize or arr.shape[1] > ARCMaxGridSize:
        raise ValueError(f"Invalid grid shape {arr.shape}, max={ARCMaxGridSize}x{ARCMaxGridSize}")
    # Value check
    if not np.all((arr >= 0) & (arr <= 9)):
        raise ValueError("Grid contains values outside the range 0-9")
    return arr


def _grid_hash(grid: np.ndarray) -> str:
    """Compute a stable hash for a single grid.

    NOTE: The previous implementation was missing the mandatory `byteorder`
    argument when calling `int.to_bytes`, which resulted in a `TypeError` at
    runtime. We fix this by explicitly specifying big-endian byte order. Using
    a single byte per dimension is sufficient because `ARCMaxGridSize ≤ 30`.
    """
    # Encode the shape (two ints) followed by raw bytes of the grid.
    buffer = [dim.to_bytes(1, "big") for dim in grid.shape]
    buffer.append(grid.tobytes())
    return hashlib.sha256(b"".join(buffer)).hexdigest()


def puzzle_hash(group: Dict[Tuple[str, str], 'ARCPuzzle']) -> str:
    """Hash a *group* of puzzles to easily detect duplicates.

    A *group* here refers to the mapping of destination (split, set) → ARCPuzzle
    that convert_single_arc_puzzle uses internally. All examples across all
    destinations are folded into one combined hash so that duplicates can be
    detected regardless of split assignment.
    """
    example_hashes = []
    for arc_puzzle in group.values():
        for inp, out in arc_puzzle.examples:
            example_hashes.append(f"{_grid_hash(inp)}|{_grid_hash(out)}")
    example_hashes.sort()
    return hashlib.sha256("|".join(example_hashes).encode()).hexdigest()


# -----------------------------------------------------------------------------
# Augmentation primitives
# -----------------------------------------------------------------------------


def _sample_colour_permutation(rng: np.random.Generator) -> np.ndarray:
    """Sample a colour permutation that keeps 0 (black) fixed."""
    perm = rng.permutation(np.arange(1, 10, dtype=np.uint8))  # 1-9 inclusive
    return np.concatenate((np.array([0], dtype=np.uint8), perm))


def _apply_transform(grid: np.ndarray, mapping: np.ndarray, trans_id: int) -> np.ndarray:
    """Apply colour mapping first, then dihedral transform."""
    # Vectorised colour remap – extremely fast
    transformed = mapping[grid]
    # Geometric transform – delegated to common.dihedral_transform
    return dihedral_transform(transformed, trans_id)


# -----------------------------------------------------------------------------
# Augmentation generation
# -----------------------------------------------------------------------------


def _generate_augmented_group(
    base_group: Dict[Tuple[str, str], 'ARCPuzzle'],
    rng: np.random.Generator,
    max_retry_factor: int,
    aug_count: int,
    ) -> List[Dict[Tuple[str, str], 'ARCPuzzle']]:
    """Generate *aug_count* unique augmented variants of *base_group*.

    The function keeps sampling random augmentation plans until the desired
    number of *unique* variants is collected or the retry budget is exhausted.
    """
    results = [base_group]
    seen_hashes = {puzzle_hash(base_group)}

    # Pre-materialise examples for efficiency.
    examples_by_dest = {
        dest: [(inp.copy(), out.copy()) for inp, out in arc_puzzle.examples]
        for dest, arc_puzzle in base_group.items()
    }

    retry_budget = max_retry_factor * aug_count if aug_count > 0 else 0

    while len(results) < aug_count + 1 and retry_budget > 0:
        retry_budget -= 1
        trans_id: int = rng.integers(0, 8)  # 8 dihedral transforms
        mapping: np.ndarray = _sample_colour_permutation(rng)
        # Build a human-readable representation of the augmentation plan.
        aug_repr = f"t{trans_id}_{''.join(str(int(x)) for x in mapping)}"

        augmented_group: Dict[Tuple[str, str], ARCPuzzle] = {}
        for dest, example_list in examples_by_dest.items():
            new_examples = [
                (
                    _apply_transform(inp, mapping, trans_id),
                    _apply_transform(out, mapping, trans_id),
                )
                for inp, out in example_list
            ]
            augmented_group[dest] = ARCPuzzle(
                id=f"{base_group[dest].id}_{aug_repr}", examples=new_examples
            )

        h = puzzle_hash(augmented_group)
        if h not in seen_hashes:
            seen_hashes.add(h)
            results.append(augmented_group)

    if len(results) < aug_count + 1:
        base_id = next(iter(base_group.values())).id  # get id of any puzzle
        print(
            f"[Puzzle {base_id}] augmentation not full, only {len(results)} total (requested {aug_count + 1})"
        )

    return results


# -----------------------------------------------------------------------------
# Public conversion API (kept stable)
# -----------------------------------------------------------------------------


def convert_single_arc_puzzle(
    results: dict,
    default_name: str,
    raw_puzzle: dict,
    aug_count: int,
    dest_mapping: Dict[str, Tuple[str, str]],
    config: DataProcessConfig | None = None,
):
    """Convert a single raw JSON puzzle into the binary ARC dataset format.

    Parameters
    ----------
    results : dict
        The global results dictionary mutated *in-place*.
    default_name : str
        Fallback name for the puzzle if the JSON doesn’t provide one.
    raw_puzzle : dict
        The raw JSON dictionary loaded from disk.
    aug_count : int
        Number of *additional* augmented variants to generate.
    dest_mapping : dict
        Mapping of example type ("train"/"test" in raw JSON) → (split, set)
        pairs used by downstream training.
    config : DataProcessConfig | None
        Optional – needed only for advanced options such as multi-processing.
    """
    # ------------------------------------------------------------------
    # 1. Basic conversion (no augmentation)
    # ------------------------------------------------------------------
    puzzle_name = raw_puzzle.pop("name", default_name)
    dests = set(dest_mapping.values())

    # Parsed puzzles keyed by destination (split, set)
    base_group: Dict[Tuple[str, str], ARCPuzzle] = {dest: ARCPuzzle(id=puzzle_name, examples=[]) for dest in dests}

    for example_type, examples in raw_puzzle.items():
        dest = dest_mapping[example_type]
        for ex in examples:
            base_group[dest].examples.append(
                (
                    arc_grid_to_np(ex["input"]),
                    arc_grid_to_np(ex["output"]),
                )
            )

    # ------------------------------------------------------------------
    # 2. Augmentation (colour permutation + dihedral)
    # ------------------------------------------------------------------
    if aug_count > 0:
        rng = np.random.default_rng()
        augmented_groups = _generate_augmented_group(
            base_group,
            rng=rng,
            max_retry_factor=(config.max_retry_factor if config else 5),
            aug_count=aug_count,
        )
    else:
        augmented_groups = [base_group]

    # ------------------------------------------------------------------
    # 3. Append converted groups into the global *results* dictionary.
    # ------------------------------------------------------------------
    for dest in dests:
        split_name, set_name = dest
        results.setdefault(split_name, {}).setdefault(set_name, [])
        # For each augmentation variant we push the puzzle corresponding to
        # this destination (note: augmented_groups is a *list* of group dicts)
        results[split_name][set_name].append(
            [group[dest] for group in augmented_groups]
        )


# -----------------------------------------------------------------------------
# The remaining part of the file is left *unchanged* except for the fact that
# convert_single_arc_puzzle now requires the `config` argument. We therefore
# provide a thin wrapper `_convert_single_arc_puzzle_legacy` to preserve the
# original call-site signature without changing every occurrence.
# -----------------------------------------------------------------------------


def _convert_single_arc_puzzle_legacy(
    results: dict,
    default_name: str,
    puzzle: dict,
    aug_count: int,
    dest_mapping: Dict[str, Tuple[str, str]],
    config: DataProcessConfig,
):
    """Backwards-compatibility shim – matches the old call signature."""
    return convert_single_arc_puzzle(
        results=results,
        default_name=default_name,
        raw_puzzle=puzzle,
        aug_count=aug_count,
        dest_mapping=dest_mapping,
        config=config,
    )


# -----------------------------------------------------------------------------
# The rest of the original pipeline (dataset loading, saving, etc.) remains
# exactly the same, aside from swapping in the legacy shim where necessary.
# -----------------------------------------------------------------------------


def np_grid_to_seq_translational_augment(
    inp: np.ndarray, out: np.ndarray, *, do_translation: bool
):
    """Translate 2D grids into padded 1D sequences with optional offset."""
    # PAD: 0, <eos>: 1, digits: 2 ... 11
    if do_translation:
        pad_r = np.random.randint(
            0, ARCMaxGridSize - max(inp.shape[0], out.shape[0]) + 1
        )
        pad_c = np.random.randint(
            0, ARCMaxGridSize - max(inp.shape[1], out.shape[1]) + 1
        )
    else:
        pad_r = pad_c = 0

    seqs = []
    for grid in (inp, out):
        nrow, ncol = grid.shape
        # Shift colours to reserve 0=PAD and 1=EOS (i.e. +2)
        grid_pad = np.pad(
            grid + 2,
            ((pad_r, ARCMaxGridSize - pad_r - nrow), (pad_c, ARCMaxGridSize - pad_c - ncol)),
            constant_values=0,
        )
        # Mark end-of-sequence in 2D space then flatten
        eos_row, eos_col = pad_r + nrow, pad_c + ncol
        if eos_row < ARCMaxGridSize:
            grid_pad[eos_row, pad_c:eos_col] = 1
        if eos_col < ARCMaxGridSize:
            grid_pad[pad_r:eos_row, eos_col] = 1
        seqs.append(grid_pad.flatten())
    return seqs


# -----------------------------------------------------------------------------
# Dataset loading helpers (unchanged except shim replacement)
# -----------------------------------------------------------------------------

def load_puzzles_arcagi(results: dict, dataset_path: str, config: DataProcessConfig):
    train_examples_dest = ("train", "all")
    test_examples_map = {
        "evaluation": [(1.0, ("test", "all"))],
        "_default": [(1.0, ("train", "all"))],
    }

    total_puzzles = 0
    for subdir in os.scandir(dataset_path):
        if not subdir.is_dir():
            continue
        # Gather puzzle file paths first (avoids keeping entire JSON in memory)
        filenames = list(glob(os.path.join(subdir.path, "*.json")))
        np.random.shuffle(filenames)

        for idx, filename in enumerate(filenames):
            with open(filename, "r") as f:
                puzzle_json = json.load(f)

            fraction = idx / len(filenames)
            test_examples_dest = None
            for f_thr, dest in test_examples_map.get(
                subdir.name, test_examples_map["_default"]
            ):
                if fraction < f_thr:
                    test_examples_dest = dest
                    break
            assert test_examples_dest is not None

            default_name = Path(filename).stem
            _convert_single_arc_puzzle_legacy(
                results,
                default_name,
                puzzle_json,
                config.num_aug,
                {"train": train_examples_dest, "test": test_examples_dest},
                config=config,
            )
            total_puzzles += 1

    print(f"[{dataset_path}] total puzzles: {total_puzzles}")


# -----------------------------------------------------------------------------
# Top-level dataset conversion entry point (minor updates)
# -----------------------------------------------------------------------------

def convert_dataset(config: DataProcessConfig):
    np.random.seed(config.seed)

    # ------------------------------------------------------------------
    # 1. Load and convert all datasets
    # ------------------------------------------------------------------
    data: Dict[str, Dict[str, List]] = {}
    for dataset_dir in config.dataset_dirs:
        load_puzzles_arcagi(data, dataset_dir, config)

    # ------------------------------------------------------------------
    # 2. Build a global mapping from string id → numerical id
    # ------------------------------------------------------------------
    identifier_map: Dict[str, int] = {}
    next_id = 1  # 0 is reserved for <blank>
    for split in data.values():
        for subset in split.values():
            for group in subset:
                for puzzle in group:
                    if puzzle.id not in identifier_map:
                        identifier_map[puzzle.id] = next_id
                        next_id += 1

    print(f"Total puzzle IDs (including <blank>): {next_id}")

    # ------------------------------------------------------------------
    # 3. Serialize splits to disk
    # ------------------------------------------------------------------
    for split_name, split in data.items():
        split_dir = os.path.join(config.output_dir, split_name)
        os.makedirs(split_dir, exist_ok=True)

        enable_translation = split_name == "train"

        total_examples = total_puzzles = total_groups = 0

        for subset_name, subset in split.items():
            arrays: Dict[str, List] = {
                "inputs": [],
                "labels": [],
                "puzzle_identifiers": [],
                "puzzle_indices": [0],
                "group_indices": [0],
            }
            example_idx = puzzle_idx = 0

            for group in subset:
                for puzzle in group:
                    # Choose one example to *not* translate (stability during eval)
                    no_aug_id = np.random.randint(0, len(puzzle.examples))
                    for ex_idx, (inp, out) in enumerate(puzzle.examples):
                        inp_seq, out_seq = np_grid_to_seq_translational_augment(
                            inp,
                            out,
                            do_translation=enable_translation and ex_idx != no_aug_id,
                        )
                        arrays["inputs"].append(inp_seq)
                        arrays["labels"].append(out_seq)
                        example_idx += 1
                        total_examples += 1

                    arrays["puzzle_indices"].append(example_idx)
                    arrays["puzzle_identifiers"].append(identifier_map[puzzle.id])
                    puzzle_idx += 1
                    total_puzzles += 1
                arrays["group_indices"].append(puzzle_idx)
                total_groups += 1

            # Convert lists into numpy arrays and save
            for key, val in arrays.items():
                if key in {"inputs", "labels"}:
                    val = np.stack(val, 0)
                else:
                    val = np.asarray(val, dtype=np.int32)
                np.save(os.path.join(split_dir, f"{subset_name}__{key}.npy"), val)

        # ------------------------------------------------------------------
        # 4. Meta-data JSON for the split
        # ------------------------------------------------------------------
        metadata = PuzzleDatasetMetadata(
            seq_len=ARCMaxGridSize * ARCMaxGridSize,
            vocab_size=12,  # 0=PAD, 1=EOS, 2-11 = colours 0-9
            pad_id=0,
            ignore_label_id=0,
            blank_identifier_id=0,
            num_puzzle_identifiers=next_id,
            total_groups=total_groups,
            mean_puzzle_examples=total_examples / max(total_puzzles, 1),
            sets=list(split.keys()),
        )
        with open(os.path.join(split_dir, "dataset.json"), "w") as f:
            json.dump(metadata.model_dump(), f)

    # ------------------------------------------------------------------
    # 5. Save identifier mapping (for interpretability)
    # ------------------------------------------------------------------
    with open(os.path.join(config.output_dir, "identifiers.json"), "w") as f:
        id_lookup = {idx: name for name, idx in identifier_map.items()}
        json.dump([id_lookup.get(i, "<blank>") for i in range(next_id)], f)


# -----------------------------------------------------------------------------
# Command-line entry point (unchanged)
# -----------------------------------------------------------------------------


@cli.command(singleton=True)
def main(config: DataProcessConfig):
    convert_dataset(config)


if __name__ == "__main__":
    cli()
