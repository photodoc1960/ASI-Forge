"""
DeltaNet v1 – LayerScale Residual Gating + RMSNorm Stabilisation
================================================================
This update integrates two training-stabilisation techniques that have
shown consistent empirical gains for deep Transformer-like networks while
incurring **zero** additional asymptotic complexity:

1. **RMSNorm instead of LayerNorm (Zhang et al. 2019)**
   ‑ Removes the mean-subtraction in normalisation which has been shown to
     improve numerical stability and training speed especially for very
     long sequences.
   ‑ Parameter count is identical to LayerNorm (single learnable scale
     vector) but computational overhead is *lower* (fewer reduction ops).

2. **LayerScale residual gating (Touvron et al. 2021 – CaiT / ConvNeXt)**
   ‑ Introduces a small, trainable, *per-feature* scalar (γ) initialised
     to a tiny value (1e-4) that scales the output of every sub-block
     before it is added back to the residual stream.  This lets the model
     start as an *almost* identity function which greatly eases
     optimisation at depth and allows using **higher learning rates**.

Both mechanisms are extremely light-weight and purely element-wise → they
maintain the required **O(N)** time / memory profile, are fully compatible
with the existing chunked causal processing strategy and do not interfere
with RoPE or any other positional mechanisms.

All public APIs remain unchanged (class names, forward signatures, default
hyper-parameters).  The only behavioural change is internal: better
training stability + capacity which is enabled by default.
"""

from __future__ import annotations

import math
from typing import Any, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from einops import rearrange
except ImportError:
    # einops is required, but provide a helpful error if missing so that unit tests fail fast
    def rearrange(x, pattern, **axes_lengths):  # type: ignore[unused-arg]
        raise ImportError(
            "einops is required for rearrange. Please install einops or ensure it is available."
        )

__all__ = [
    "DeltaNet",
]

# -------------------------------------------------------------------------------------
# Normalisation & Utility blocks
# -------------------------------------------------------------------------------------
class RMSNorm(nn.Module):
    """Root-mean-square Layer Normalisation (parameter-wise rescale only).

    Paper: *Root Mean Square Layer Normalization* – Zhang & Sennrich, 2019.
    Computes:  x / rms(x) * weight  where  rms(x)=sqrt(mean(x**2)+eps)
    """

    def __init__(self, d_model: int, eps: float = 1e-8) -> None:
        super().__init__()
        self.eps = eps
        self.scale = nn.Parameter(torch.ones(d_model))  # (D,)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        rms = torch.sqrt(torch.mean(x ** 2, dim=-1, keepdim=True) + self.eps)
        x = x / rms  # type: ignore[no-redef]
        return x * self.scale


class GEGLU(nn.Module):
    """Gated Linear Unit with GELU activation (GEGLU)."""

    def __init__(self, d_model: int, d_ff: int):
        super().__init__()
        self.proj = nn.Linear(d_model, d_ff * 2, bias=False)
        self.out = nn.Linear(d_ff, d_model, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        u, v = self.proj(x).chunk(2, dim=-1)
        return self.out(F.gelu(u) * v)


class DropPath(nn.Module):
    """Stochastic depth (a.k.a DropPath)."""

    def __init__(self, p: float = 0.0):
        super().__init__()
        self.p = p

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        if not self.training or self.p == 0.0:
            return x
        keep_prob = 1.0 - self.p
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)  # broadcast across batch / sequence / feature
        mask = torch.rand(shape, dtype=x.dtype, device=x.device) < keep_prob
        return x * mask / keep_prob


# -------------------------------------------------------------------------------------
# Rotary positional embedding helper  (fixed for correct seq-dim handling)
# -------------------------------------------------------------------------------------
class _RotaryPositionalEmbedding:
    """Cache-friendly rotary embeddings for a single attention head-dim size."""

    def __init__(self, head_dim: int, base: int = 10000):
        if head_dim % 2 != 0:
            raise ValueError("Head dimension must be even for RoPE.")
        self.head_dim = head_dim
        self.base = base
        self._cached_seq_len: int = 0
        # tensors cached on CPU to avoid accidental GPU memory growth; moved on demand
        self._sin: Optional[torch.Tensor] = None
        self._cos: Optional[torch.Tensor] = None

    def _build_cache(self, seq_len: int, device: torch.device, dtype: torch.dtype) -> None:
        """Builds / extends the sin & cos caches to at least `seq_len`."""
        if (
            seq_len <= self._cached_seq_len
            and self._sin is not None
            and self._cos is not None
        ):
            # Already cached – ensure correct device / dtype
            if self._sin.device != device:
                self._sin = self._sin.to(device)
                self._cos = self._cos.to(device)
            if self._sin.dtype != dtype:
                self._sin = self._sin.to(dtype=dtype)
                self._cos = self._cos.to(dtype=dtype)
            return

        # (Re-)compute cached embeddings
        self._cached_seq_len = seq_len
        pos = torch.arange(seq_len, device=device, dtype=dtype)  # (N,)
        dim = torch.arange(0, self.head_dim, 2, device=device, dtype=dtype)  # (Dh/2,)
        inv_freq = 1.0 / (self.base ** (dim / self.head_dim))  # (Dh/2,)
        # Correct einsum pattern – no spaces inside the resulting axis string
        sinusoid = torch.einsum("n,d->nd", pos, inv_freq)  # (N, Dh/2)
        self._sin = torch.sin(sinusoid).repeat_interleave(2, dim=-1)  # (N, Dh)
        self._cos = torch.cos(sinusoid).repeat_interleave(2, dim=-1)  # (N, Dh)

    def apply(self, x: torch.Tensor) -> torch.Tensor:
        """Apply RoPE in a shape-agnostic manner.

        Supports inputs of shape (B, N, D) or (B, N, H, D). The sequence dimension
        is assumed to be the *first* non-batch dimension so that the model stays
        fully batch-size agnostic.  This covers the two cases used in the model:
        ‑ tokens first:  (B, N, D)
        ‑ tokens first with explicit heads: (B, N, H, D)
        """
        if x.shape[-1] != self.head_dim:
            raise ValueError("Unexpected head_dim for RoPE.")

        device, dtype = x.device, x.dtype

        # Sequence length is the first non-batch dimension (dim=1)
        seq_len = x.shape[1]
        self._build_cache(seq_len, device, dtype)

        # Build sin / cos so that they broadcast correctly to x
        if x.ndim == 3:  # (B, N, D)
            sin = self._sin[:seq_len].unsqueeze(0)  # (1, N, Dh)
            cos = self._cos[:seq_len].unsqueeze(0)  # (1, N, Dh)
        elif x.ndim == 4:  # (B, N, H, D)
            sin = self._sin[:seq_len].unsqueeze(0).unsqueeze(2)  # (1, N, 1, Dh)
            cos = self._cos[:seq_len].unsqueeze(0).unsqueeze(2)  # (1, N, 1, Dh)
        else:
            raise ValueError("RoPE only supports 3- or 4-D tensors (got %d-D)." % x.ndim)

        # rotate
        x1, x2 = x[..., ::2], x[..., 1::2]
        x_rot = torch.stack([-x2, x1], dim=-1).reshape_as(x)
        return x * cos + x_rot * sin


# -------------------------------------------------------------------------------------
# 1. Chunk-wise causal **linear** self-attention + RoPE (unchanged logic)
# -------------------------------------------------------------------------------------
class ChunkwiseCausalLinearSelfAttention(nn.Module):
    """Linear-kernel self-attention processed in chunks – O(N) complexity."""

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        head_dim: Optional[int] = None,
        chunk_size: int = 256,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = head_dim or d_model // n_heads
        if self.head_dim * n_heads != d_model:
            raise ValueError("d_model must be divisible by num_heads")
        if self.head_dim % 2 != 0:
            raise ValueError("head_dim must be even for RoPE")

        self.chunk_size = chunk_size
        self.dropout = nn.Dropout(dropout)

        # projections
        self.qkv_proj = nn.Linear(d_model, d_model * 3, bias=False)
        self.o_proj = nn.Linear(d_model, d_model, bias=False)

        self.rope = _RotaryPositionalEmbedding(self.head_dim)
        self.register_buffer("eps", torch.tensor(1e-6), persistent=False)

    @staticmethod
    def _feature_map(x: torch.Tensor) -> torch.Tensor:
        return F.elu(x) + 1.0

    def _step_chunk(
        self,
        q_chunk: torch.Tensor,
        k_chunk: torch.Tensor,
        v_chunk: torch.Tensor,
        k_prefix: torch.Tensor,
        kv_prefix: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # cumulative sums inside the chunk + prefix for full causal context
        k_cumsum = torch.cumsum(k_chunk, dim=1) + k_prefix[:, None]
        kv = torch.einsum("b s h d, b s h e -> b s h d e", k_chunk, v_chunk)
        kv_cumsum = torch.cumsum(kv, dim=1) + kv_prefix[:, None]

        num = torch.einsum("b s h d, b s h d e -> b s h e", q_chunk, kv_cumsum)
        den = torch.einsum("b s h d, b s h d -> b s h", q_chunk, k_cumsum)
        out = num / (den.unsqueeze(-1) + self.eps)

        # update prefixes
        k_prefix = k_prefix + k_chunk.sum(dim=1)
        kv_prefix = kv_prefix + kv.sum(dim=1)
        return out, k_prefix, kv_prefix

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        B, N, _ = x.shape

        qkv = self.qkv_proj(x)
        q, k, v = qkv.chunk(3, dim=-1)
        # (B, N, H, Dh)
        q = rearrange(q, "b n (h d) -> b n h d", h=self.n_heads)
        k = rearrange(k, "b n (h d) -> b n h d", h=self.n_heads)
        v = rearrange(v, "b n (h d) -> b n h d", h=self.n_heads)

        q = self.rope.apply(q)
        k = self.rope.apply(k)

        q = self._feature_map(q)
        k = self._feature_map(k)

        device, dtype = x.device, x.dtype
        Dh = self.head_dim
        k_prefix = torch.zeros((B, self.n_heads, Dh), device=device, dtype=dtype)
        kv_prefix = torch.zeros((B, self.n_heads, Dh, Dh), device=device, dtype=dtype)

        out_chunks: List[torch.Tensor] = []
        for start in range(0, N, self.chunk_size):
            end = min(start + self.chunk_size, N)
            q_chunk = q[:, start:end]
            k_chunk = k[:, start:end]
            v_chunk = v[:, start:end]
            out_chunk, k_prefix, kv_prefix = self._step_chunk(
                q_chunk, k_chunk, v_chunk, k_prefix, kv_prefix
            )
            out_chunks.append(out_chunk)

        out = torch.cat(out_chunks, dim=1)
        out = rearrange(out, "b n h d -> b n (h d)")
        return self.dropout(self.o_proj(out))


# -------------------------------------------------------------------------------------
# 2. Multi-Scale Causal Convolutional Mixer (unchanged)
# -------------------------------------------------------------------------------------
class _CausalDepthwiseConv1d(nn.Module):
    def __init__(self, d_model: int, kernel_size: int, dilation: int):
        super().__init__()
        self.kernel_size = kernel_size
        self.dilation = dilation
        self.conv = nn.Conv1d(
            d_model, d_model, kernel_size, groups=d_model, dilation=dilation, bias=False
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        x_ = rearrange(x, "b n d -> b d n")
        pad_len = self.dilation * (self.kernel_size - 1)
        if pad_len > 0:
            x_ = F.pad(x_, (pad_len, 0))
        y = self.conv(x_)
        return rearrange(y, "b d n -> b n d")


class MSCM(nn.Module):
    """Two-scale depth-wise causal convolution mixer."""

    def __init__(self, d_model: int, kernel_size: int = 3, dropout: float = 0.1):
        super().__init__()
        self.ln = RMSNorm(d_model)
        self.conv1 = _CausalDepthwiseConv1d(d_model, kernel_size, dilation=1)
        self.conv2 = _CausalDepthwiseConv1d(d_model, kernel_size, dilation=3)
        self.gate = nn.GLU(dim=-1)
        self.out = nn.Linear(d_model, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.ln(x)
        y1, y2 = self.conv1(x), self.conv2(x)
        y = self.gate(torch.cat([y1, y2], dim=-1))
        y = self.out(y)
        return residual + self.dropout(y)


# -------------------------------------------------------------------------------------
# 3. Exponential Recurrent Memory  (unchanged functional behaviour)
# -------------------------------------------------------------------------------------
class ExponentialMemory(nn.Module):
    """Light-weight gated exponential moving average memory."""

    def __init__(self, d_model: int, dropout: float = 0.1, chunk_size: int = 256):
        super().__init__()
        self.d_model = d_model
        self.chunk_size = chunk_size
        self.log_decay = nn.Parameter(torch.zeros(d_model))
        self.gate_proj = nn.Linear(d_model, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)
        self.ln = RMSNorm(d_model)

    def _step_chunk(
        self,
        x_chunk: torch.Tensor,  # (B, S, D)
        memory: torch.Tensor,  # (B, D)
        a: torch.Tensor,  # (1, D)
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        B, S, D = x_chunk.shape
        out = torch.empty_like(x_chunk)
        for i in range(S):
            x_t = x_chunk[:, i]
            memory = a * memory + (1.0 - a) * x_t
            g_t = torch.sigmoid(self.gate_proj(x_t))
            out[:, i] = x_t + g_t * memory
        return out, memory

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        x = self.ln(x)
        B, N, D = x.shape
        a = torch.sigmoid(self.log_decay).unsqueeze(0)
        memory = torch.zeros((B, D), device=x.device, dtype=x.dtype)

        out_chunks: List[torch.Tensor] = []
        for start in range(0, N, self.chunk_size):
            end = min(start + self.chunk_size, N)
            chunk, memory = self._step_chunk(x[:, start:end], memory, a)
            out_chunks.append(chunk)
        y = torch.cat(out_chunks, dim=1)
        return self.dropout(y)


# -------------------------------------------------------------------------------------
# Encoder Block  –  Attention → FF → Conv → Memory
# -------------------------------------------------------------------------------------
class EncoderBlock(nn.Module):
    def __init__(
        self,
        d_model: int,
        n_heads: int,
        d_ff: int,
        chunk_size: int,
        dropout: float,
        drop_path: float,
    ) -> None:
        super().__init__()
        layerscale_init = 1e-4  # tiny initial value as in CaiT / ConvNeXt

        self.ln1 = RMSNorm(d_model)
        self.attn = ChunkwiseCausalLinearSelfAttention(
            d_model, n_heads, chunk_size=chunk_size, dropout=dropout
        )
        self.gamma_attn = nn.Parameter(layerscale_init * torch.ones(d_model))

        self.ln2 = RMSNorm(d_model)
        self.ff = GEGLU(d_model, d_ff)
        self.gamma_ff = nn.Parameter(layerscale_init * torch.ones(d_model))

        self.conv_mixer = MSCM(d_model, dropout=dropout)

        self.memory = ExponentialMemory(
            d_model, dropout=dropout, chunk_size=chunk_size
        )
        self.gamma_mem = nn.Parameter(layerscale_init * torch.ones(d_model))

        self.drop_path = DropPath(drop_path) if drop_path > 0.0 else nn.Identity()
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        x = x + self.drop_path(self.gamma_attn * self.attn(self.ln1(x)))
        x = x + self.drop_path(
            self.gamma_ff * self.dropout(self.ff(self.ln2(x)))
        )
        x = self.conv_mixer(x)  # mixer already contains residual connection
        x = x + self.drop_path(self.gamma_mem * self.memory(x))
        return x


# -------------------------------------------------------------------------------------
#  DeltaNet – main model
# -------------------------------------------------------------------------------------
class DeltaNet(nn.Module):
    """DeltaNet – causal linear attention + conv mixer + recurrent memory + RoPE + LayerScale + RMSNorm."""

    def __init__(
        self,
        d_model: int = 512,
        n_heads: int = 8,
        num_layers: int = 6,
        d_ff: int = 2048,
        chunk_size: int = 256,
        dropout: float = 0.1,
        drop_path: float = 0.05,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        dpr = (
            [drop_path * i / (num_layers - 1) for i in range(num_layers)]
            if num_layers > 1
            else [drop_path]
        )
        self.layers = nn.ModuleList(
            [
                EncoderBlock(
                    d_model,
                    n_heads,
                    d_ff,
                    chunk_size,
                    dropout,
                    dpr[i],
                )
                for i in range(num_layers)
            ]
        )
        self.final_norm = RMSNorm(d_model)

    @torch.compile(mode="reduce-overhead")  # type: ignore[misc]
    def forward(self, x: torch.Tensor, **kwargs) -> torch.Tensor:  # (B, N, D)
        for layer in self.layers:
            x = layer(x)
        return self.final_norm(x)
