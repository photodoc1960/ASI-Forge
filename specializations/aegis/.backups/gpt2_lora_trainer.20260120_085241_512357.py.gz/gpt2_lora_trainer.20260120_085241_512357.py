"""
DeltaNet: Causal Linear Attention  + Convolutional Mixer  +  Recurrent Exponential-Memory
======================================================================================
This *evolution* of **DeltaNet** tackles the key weakness identified by the
experiments – the model quickly *forgets* content that falls outside the local
chunk processed by the linear attention pathway and therefore struggles on
long-range dependency and multi-step reasoning benchmarks.

The new design keeps the previously introduced
    • Chunk-wise causal **linear attention**  (efficient → O(N D))
    • Multi-Scale **Convolutional Mixer**             (local pattern bias)

and *augments* every layer with a light-weight **Exponential Recurrent Memory**
(ERM) inspired by the *time-mix* idea of RWKV and by exponential state-space
models (S4).

Key Properties
--------------
1.  **O(N) complexity** – the memory path is a simple recurrent update that
    scans the sequence once, therefore keeping the overall complexity linear.
2.  **Chunk-compatible & stateful** – memory is updated chunk-by-chunk, each
    chunk only keeps a single hidden vector per feature dimension so peak
    memory footprint stays tiny.
3.  **Strict causality** – the recurrent equation  `m_t = a * m_{t-1} + b * x_t`
    only uses *past* information.
4.  **Learnable, gated decay** – `a = sigmoid(log_a)` is learned per feature so
    the network can adaptively choose integration windows ranging from a few
    tokens to thousands.
5.  **Residual form** – the memory vector is mixed back into the stream through
    a gated residual ensuring stable gradients and easy optimisation.

Public API, class name ``DeltaNet`` and its ``forward`` signature **do not
change** so the wider code-base remains fully compatible.
"""

from __future__ import annotations

import math
from typing import Any, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

# -------------------------------------------------------------------------------------
# Utility blocks
# -------------------------------------------------------------------------------------
class GEGLU(nn.Module):
    """Gated Linear Unit with GELU activation (GEGLU)."""

    def __init__(self, d_model: int, d_ff: int):
        super().__init__()
        self.proj = nn.Linear(d_model, d_ff * 2, bias=False)
        self.out = nn.Linear(d_ff, d_model, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        u, v = self.proj(x).chunk(2, dim=-1)
        return self.out(F.gelu(u) * v)


class DropPath(nn.Module):
    """Stochastic depth (a.k.a DropPath)."""

    def __init__(self, p: float = 0.0):
        super().__init__()
        self.p = p

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        if not self.training or self.p == 0.0:
            return x
        keep_prob = 1.0 - self.p
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)  # broadcast across batch
        mask = torch.rand(shape, dtype=x.dtype, device=x.device) < keep_prob
        return x * mask / keep_prob


# -------------------------------------------------------------------------------------
# 1. Chunk-wise causal linear self-attention (unchanged)
# -------------------------------------------------------------------------------------
class ChunkwiseCausalLinearSelfAttention(nn.Module):
    """Linear-kernel self-attention processed in chunks – O(N) complexity."""

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        head_dim: Optional[int] = None,
        chunk_size: int = 256,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = head_dim or d_model // n_heads
        assert self.head_dim * n_heads == d_model, "d_model must be divisible by num_heads"

        self.chunk_size = chunk_size
        self.dropout = nn.Dropout(dropout)

        # Projections
        self.qkv_proj = nn.Linear(d_model, d_model * 3, bias=False)
        self.o_proj = nn.Linear(d_model, d_model, bias=False)

        # small epsilon for numerical stability
        self.register_buffer("eps", torch.tensor(1e-6))

    @staticmethod
    def _feature_map(x: torch.Tensor) -> torch.Tensor:
        """Positive random feature map (ELU + 1)"""
        return F.elu(x) + 1.0

    def _step_chunk(
        self,
        q_chunk: torch.Tensor,  # (B, S, H, Dh)
        k_chunk: torch.Tensor,
        v_chunk: torch.Tensor,
        k_prefix: torch.Tensor,  # (B, H, Dh)
        kv_prefix: torch.Tensor,  # (B, H, Dh, Dh)
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # cumulative sums inside the chunk + prefix to get full causal context
        k_cumsum = torch.cumsum(k_chunk, dim=1) + k_prefix[:, None]
        kv = torch.einsum("b s h d, b s h e -> b s h d e", k_chunk, v_chunk)
        kv_cumsum = torch.cumsum(kv, dim=1) + kv_prefix[:, None]

        # Attention output
        num = torch.einsum("b s h d, b s h d e -> b s h e", q_chunk, kv_cumsum)
        den = torch.einsum("b s h d, b s h d -> b s h", q_chunk, k_cumsum)
        out = num / (den.unsqueeze(-1) + self.eps)

        # update prefixes
        k_prefix = k_prefix + k_chunk.sum(dim=1)
        kv_prefix = kv_prefix + kv.sum(dim=1)
        return out, k_prefix, kv_prefix

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        B, N, _ = x.shape
        qkv = self.qkv_proj(x)
        q, k, v = qkv.chunk(3, dim=-1)
        q = rearrange(q, "b n (h d) -> b n h d", h=self.n_heads)
        k = rearrange(k, "b n (h d) -> b n h d", h=self.n_heads)
        v = rearrange(v, "b n (h d) -> b n h d", h=self.n_heads)

        q = self._feature_map(q)
        k = self._feature_map(k)

        device, dtype = x.device, x.dtype
        Dh = self.head_dim
        k_prefix = torch.zeros((B, self.n_heads, Dh), device=device, dtype=dtype)
        kv_prefix = torch.zeros((B, self.n_heads, Dh, Dh), device=device, dtype=dtype)

        out_chunks: List[torch.Tensor] = []
        for start in range(0, N, self.chunk_size):
            end = min(start + self.chunk_size, N)
            q_chunk = q[:, start:end]
            k_chunk = k[:, start:end]
            v_chunk = v[:, start:end]
            out_chunk, k_prefix, kv_prefix = self._step_chunk(
                q_chunk, k_chunk, v_chunk, k_prefix, kv_prefix
            )
            out_chunks.append(out_chunk)

        out = torch.cat(out_chunks, dim=1)
        out = rearrange(out, "b n h d -> b n (h d)")
        return self.dropout(self.o_proj(out))


# -------------------------------------------------------------------------------------
# 2. Multi-Scale Causal Convolutional Mixer (unchanged)
# -------------------------------------------------------------------------------------
class _CausalDepthwiseConv1d(nn.Module):
    def __init__(self, d_model: int, kernel_size: int, dilation: int):
        super().__init__()
        self.kernel_size = kernel_size
        self.dilation = dilation
        self.conv = nn.Conv1d(
            d_model, d_model, kernel_size, groups=d_model, dilation=dilation, bias=False
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        x_ = rearrange(x, "b n d -> b d n")
        pad_len = self.dilation * (self.kernel_size - 1)
        if pad_len > 0:
            x_ = F.pad(x_, (pad_len, 0))  # causal
        y = self.conv(x_)
        return rearrange(y, "b d n -> b n d")


class MSCM(nn.Module):
    """Two-scale depth-wise causal convolution mixer."""

    def __init__(self, d_model: int, kernel_size: int = 3, dropout: float = 0.1):
        super().__init__()
        self.ln = nn.LayerNorm(d_model)
        self.conv1 = _CausalDepthwiseConv1d(d_model, kernel_size, dilation=1)
        self.conv2 = _CausalDepthwiseConv1d(d_model, kernel_size, dilation=3)
        self.gate = nn.GLU(dim=-1)
        self.out = nn.Linear(d_model, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.ln(x)
        y1, y2 = self.conv1(x), self.conv2(x)
        y = self.gate(torch.cat([y1, y2], dim=-1))
        y = self.out(y)
        return residual + self.dropout(y)


# -------------------------------------------------------------------------------------
# 3. Exponential Recurrent Memory (new)
# -------------------------------------------------------------------------------------
class ExponentialMemory(nn.Module):
    """Light-weight gated exponential moving average memory.

    Equation
        m_t  =  a * m_{t-1}  +  (1 - a) * x_t
        y_t  =  x_t + g_t * m_t

    where ``a = sigmoid(log_decay)`` is *learned per feature* and
    ``g_t = sigmoid(W_g x_t)`` is an input-dependent gate.
    """

    def __init__(self, d_model: int, dropout: float = 0.1, chunk_size: int = 256):
        super().__init__()
        self.d_model = d_model
        self.chunk_size = chunk_size

        # learnable decay in logit space initialised so that sigmoid≈0.5
        self.log_decay = nn.Parameter(torch.zeros(d_model))
        self.gate_proj = nn.Linear(d_model, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)
        self.ln = nn.LayerNorm(d_model)

    def _step_chunk(
        self,
        x_chunk: torch.Tensor,  # (B, S, D)
        memory: torch.Tensor,  # (B, D)
        a: torch.Tensor,  # (1, D)
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        B, S, D = x_chunk.shape
        out = torch.empty_like(x_chunk)
        for i in range(S):  # small – S <= chunk_size (256 by default)
            x_t = x_chunk[:, i]
            memory = a * memory + (1.0 - a) * x_t
            g_t = torch.sigmoid(self.gate_proj(x_t))
            out[:, i] = x_t + g_t * memory
        return out, memory

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        x = self.ln(x)
        B, N, D = x.shape
        a = torch.sigmoid(self.log_decay).unsqueeze(0)  # (1, D)
        memory = torch.zeros((B, D), device=x.device, dtype=x.dtype)

        out_chunks: List[torch.Tensor] = []
        for start in range(0, N, self.chunk_size):
            end = min(start + self.chunk_size, N)
            chunk, memory = self._step_chunk(x[:, start:end], memory, a)
            out_chunks.append(chunk)
        y = torch.cat(out_chunks, dim=1)
        return self.dropout(y)


# -------------------------------------------------------------------------------------
# Encoder Block (Attention → FF → Conv → Memory)
# -------------------------------------------------------------------------------------
class EncoderBlock(nn.Module):
    def __init__(
        self,
        d_model: int,
        n_heads: int,
        d_ff: int,
        chunk_size: int,
        dropout: float,
        drop_path: float,
    ) -> None:
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.attn = ChunkwiseCausalLinearSelfAttention(
            d_model, n_heads, chunk_size=chunk_size, dropout=dropout
        )

        self.ln2 = nn.LayerNorm(d_model)
        self.ff = GEGLU(d_model, d_ff)

        self.conv_mixer = MSCM(d_model, dropout=dropout)
        self.memory = ExponentialMemory(d_model, dropout=dropout, chunk_size=chunk_size)

        self.drop_path = DropPath(drop_path) if drop_path > 0.0 else nn.Identity()
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        # 1. Linear Attention
        x = x + self.drop_path(self.attn(self.ln1(x)))
        # 2. Feed-Forward
        x = x + self.drop_path(self.dropout(self.ff(self.ln2(x))))
        # 3. Convolutional Mixer (contains its own residual)
        x = self.conv_mixer(x)
        # 4. Exponential Memory (contains LN, residual handled here)
        x = x + self.drop_path(self.memory(x))
        return x


# -------------------------------------------------------------------------------------
#  DeltaNet – main model
# -------------------------------------------------------------------------------------
class DeltaNet(nn.Module):
    """DeltaNet – causal linear attention + conv mixer + recurrent memory."""

    def __init__(
        self,
        d_model: int = 512,
        n_heads: int = 8,
        num_layers: int = 6,
        d_ff: int = 2048,
        chunk_size: int = 256,
        dropout: float = 0.1,
        drop_path: float = 0.05,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        # progressive drop-path probability along depth
        dpr = [drop_path * i / (num_layers - 1) if num_layers > 1 else drop_path for i in range(num_layers)]
        self.layers = nn.ModuleList(
            [
                EncoderBlock(
                    d_model,
                    n_heads,
                    d_ff,
                    chunk_size,
                    dropout,
                    dpr[i],
                )
                for i in range(num_layers)
            ]
        )
        self.final_ln = nn.LayerNorm(d_model)

    # compile only the heavy forward pass
    @torch.compile(mode="reduce-overhead")  # type: ignore[misc]
    def forward(self, x: torch.Tensor, **kwargs) -> torch.Tensor:  # (B, N, D)
        for layer in self.layers:
            x = layer(x)
        return self.final_ln(x)
