"""
DeltaNet: Linear-Attention + Convolutional Mixer + Exponential Memory **with RoPE**
================================================================================
This evolution **adds Rotary Positional Embeddings (RoPE)** to the *linear*
self-attention pathway.  The original DeltaNet relied on convolutions for local
position bias while the exponential memory is order-agnostic once information
is mixed into the hidden state.  As a consequence, the model struggled with
precise *relative* positional reasoning over long sequences.

RoPE injects a parameter-free, efficient positional signal by rotating query
and key vectors in complex space – fully compatible with the existing positive
kernel feature map and *causal* streaming setup.

Key benefits
------------
1. Parameter-free therefore **no increase** in model size
2. O(ND) element-wise operations – negligible compute overhead
3. Naturally supports *chunked* inference because rotations are applied
   independently at each position → no cross-chunk state
4. Improves robustness to distribution shift where absolute positions differ
   between train & test data (observed in earlier benchmarks)

Public API, class names and method signatures remain unchanged so downstream
code (e.g. GPT2LoRATrainer / HRMTrainer) works out-of-the-box.
"""
from __future__ import annotations

# NOTE: keep imports localised – avoids polluting global namespace when this
#       module is re-exec()-ed by the supervised evolution framework.
import math
from typing import Any, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from einops import rearrange
except ImportError:  # fallback for environments without einops
    def rearrange(x, pattern, **axes_lengths):  # type: ignore[unused-arg]
        raise ImportError(
            "einops is required for rearrange. Please install einops or ensure it is available."
        )

__all__ = [
    "DeltaNet",  # public – referenced by other modules
]

# -------------------------------------------------------------------------------------
# Utility blocks (unchanged)
# -------------------------------------------------------------------------------------
class GEGLU(nn.Module):
    """Gated Linear Unit with GELU activation (GEGLU)."""

    def __init__(self, d_model: int, d_ff: int):
        super().__init__()
        self.proj = nn.Linear(d_model, d_ff * 2, bias=False)
        self.out = nn.Linear(d_ff, d_model, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        u, v = self.proj(x).chunk(2, dim=-1)
        return self.out(F.gelu(u) * v)


class DropPath(nn.Module):
    """Stochastic depth (a.k.a DropPath)."""

    def __init__(self, p: float = 0.0):
        super().__init__()
        self.p = p

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        if not self.training or self.p == 0.0:
            return x
        keep_prob = 1.0 - self.p
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)  # broadcast across batch / seq / feat
        mask = torch.rand(shape, dtype=x.dtype, device=x.device) < keep_prob
        return x * mask / keep_prob


# -------------------------------------------------------------------------------------
# Rotary positional embedding helper – FIXED
# -------------------------------------------------------------------------------------
class _RotaryPositionalEmbedding:
    """Cache-friendly rotary embeddings for a given head_dim.

    The helper now properly supports tensors of shape (B, N, H, Dh) *or*
    (B, N, Dh) without any fixed assumptions on the batch dimension.  The
    positional dimension is assumed to be *sequence length* (index 1) which is
    consistent with DeltaNetʼs internal representation.
    """

    def __init__(self, head_dim: int, base: int = 10000):
        if head_dim % 2 != 0:
            raise ValueError("head_dim must be even for RoPE.")
        self.head_dim = head_dim
        self.base = base
        self._seq_len_cached: int = 0
        self._sin: Optional[torch.Tensor] = None
        self._cos: Optional[torch.Tensor] = None

    # ------------------------------------------------------------------
    def _build_cache(self, seq_len: int, device: torch.device, dtype: torch.dtype):
        """(Re-)build or move the positional cache to the correct device/dtype."""
        if (
            seq_len <= self._seq_len_cached
            and self._sin is not None
            and self._cos is not None
        ):
            # move to correct device / dtype if necessary
            if self._sin.device != device:
                self._sin = self._sin.to(device)
                self._cos = self._cos.to(device)
            if self._sin.dtype != dtype:
                self._sin = self._sin.to(dtype)
                self._cos = self._cos.to(dtype)
            return

        # (re-)compute tables
        self._seq_len_cached = seq_len
        pos = torch.arange(seq_len, device=device, dtype=dtype)
        dim = torch.arange(0, self.head_dim, 2, device=device, dtype=dtype)
        inv_freq = 1.0 / (self.base ** (dim / self.head_dim))  # (Dh/2)
        # outer product → (seq_len, Dh/2)
        angles = torch.outer(pos, inv_freq)
        # duplicate to obtain full Dh dimension
        self._sin = torch.sin(angles).repeat_interleave(2, dim=-1)  # (seq_len, Dh)
        self._cos = torch.cos(angles).repeat_interleave(2, dim=-1)  # (seq_len, Dh)

    # ------------------------------------------------------------------
    def apply(self, x: torch.Tensor) -> torch.Tensor:
        """Apply RoPE to `x`.

        Supported shapes:
            • (B, N, H, Dh) – DeltaNetʼs internal attention representation
            • (B, N, Dh)     – any fallback 3-D representation
        """
        if x.shape[-1] != self.head_dim:
            raise ValueError(
                "Unexpected last‐dimension size: got {} expected {}".format(
                    x.shape[-1], self.head_dim
                )
            )

        device, dtype = x.device, x.dtype
        seq_len = x.shape[1]  # sequence length is ALWAYS dimension 1 in DeltaNet
        self._build_cache(seq_len, device, dtype)

        # Fetch sin / cos `(seq_len, Dh)` and reshape for broadcasting to `x`.
        sin = self._sin[:seq_len]  # (N, Dh)
        cos = self._cos[:seq_len]  # (N, Dh)

        # Add broadcast dimensions so that
        #   sin : (1, N, 1, Dh) for 4-D tensors
        #   sin : (1, N,    Dh) for 3-D tensors
        while sin.ndim < x.ndim:
            sin = sin.unsqueeze(0)
            cos = cos.unsqueeze(0)
        if x.ndim == 4:  # (B, N, H, Dh) → need a head broadcast dim at index 2
            sin = sin.unsqueeze(2)
            cos = cos.unsqueeze(2)

        # Rotate
        x1 = x[..., ::2]
        x2 = x[..., 1::2]
        x_rot = torch.stack((-x2, x1), dim=-1).reshape_as(x)
        return x * cos + x_rot * sin


# -------------------------------------------------------------------------------------
# 1. Chunk-wise causal *linear* self-attention  +  RoPE (UNCHANGED LOGIC)
# -------------------------------------------------------------------------------------
class ChunkwiseCausalLinearSelfAttention(nn.Module):
    """Performer-style positive-kernel attention processed in chunks – O(N) memory.

    Now augmented with rotary positional embeddings (RoPE).
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        head_dim: Optional[int] = None,
        chunk_size: int = 256,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = head_dim or d_model // n_heads
        if self.head_dim * n_heads != d_model:
            raise ValueError("d_model must be divisible by n_heads")
        if self.head_dim % 2 != 0:
            raise ValueError("head_dim must be even to use RoPE")

        self.chunk_size = chunk_size
        self.dropout = nn.Dropout(dropout)

        # projections
        self.qkv_proj = nn.Linear(d_model, d_model * 3, bias=False)
        self.o_proj = nn.Linear(d_model, d_model, bias=False)

        # rotary helper
        self.rope = _RotaryPositionalEmbedding(self.head_dim)

        # epsilon for numerical stability
        self.register_buffer("eps", torch.tensor(1e-6), persistent=False)

    # ------------------------------------------------------------------
    @staticmethod
    def _feature_map(x: torch.Tensor) -> torch.Tensor:
        """Positive "FAVOR+" feature map (ELU + 1)."""
        return F.elu(x) + 1.0

    # ------------------------------------------------------------------
    def _step_chunk(
        self,
        q: torch.Tensor,  # (B, S, H, Dh)
        k: torch.Tensor,
        v: torch.Tensor,
        k_prefix: torch.Tensor,  # (B, H, Dh)
        kv_prefix: torch.Tensor,  # (B, H, Dh, Dh)
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # cumulative sums inside chunk (+ prefix) → full causal context
        k_cumsum = torch.cumsum(k, dim=1) + k_prefix[:, None]
        kv = torch.einsum("b s h d, b s h e -> b s h d e", k, v)
        kv_cumsum = torch.cumsum(kv, dim=1) + kv_prefix[:, None]

        num = torch.einsum("b s h d, b s h d e -> b s h e", q, kv_cumsum)
        den = torch.einsum("b s h d, b s h d -> b s h", q, k_cumsum)
        out = num / (den.unsqueeze(-1) + self.eps)

        k_prefix = k_prefix + k.sum(dim=1)
        kv_prefix = kv_prefix + kv.sum(dim=1)
        return out, k_prefix, kv_prefix

    # ------------------------------------------------------------------
    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        B, N, _ = x.shape
        qkv = self.qkv_proj(x)
        q, k, v = qkv.chunk(3, dim=-1)
        q = rearrange(q, "b n (h d) -> b n h d", h=self.n_heads)
        k = rearrange(k, "b n (h d) -> b n h d", h=self.n_heads)
        v = rearrange(v, "b n (h d) -> b n h d", h=self.n_heads)

        # positional rotary embeddings BEFORE kernel feature map
        q = self.rope.apply(q)
        k = self.rope.apply(k)

        # positive feature map
        q = self._feature_map(q)
        k = self._feature_map(k)

        dtype, device = x.dtype, x.device
        Dh = self.head_dim
        k_prefix = torch.zeros((B, self.n_heads, Dh), device=device, dtype=dtype)
        kv_prefix = torch.zeros((B, self.n_heads, Dh, Dh), device=device, dtype=dtype)

        out_chunks: List[torch.Tensor] = []
        for start in range(0, N, self.chunk_size):
            end = min(N, start + self.chunk_size)
            q_chunk = q[:, start:end]
            k_chunk = k[:, start:end]
            v_chunk = v[:, start:end]
            y, k_prefix, kv_prefix = self._step_chunk(
                q_chunk, k_chunk, v_chunk, k_prefix, kv_prefix
            )
            out_chunks.append(y)

        out = torch.cat(out_chunks, dim=1)
        out = rearrange(out, "b n h d -> b n (h d)")
        return self.dropout(self.o_proj(out))


# -------------------------------------------------------------------------------------
# 2. Multi-Scale Causal Convolutional Mixer (unchanged)
# -------------------------------------------------------------------------------------
class _CausalDepthwiseConv1d(nn.Module):
    def __init__(self, d_model: int, kernel_size: int, dilation: int):
        super().__init__()
        self.kernel_size = kernel_size
        self.dilation = dilation
        self.conv = nn.Conv1d(
            d_model, d_model, kernel_size, groups=d_model, dilation=dilation, bias=False
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        x_ = rearrange(x, "b n d -> b d n")
        pad = self.dilation * (self.kernel_size - 1)
        if pad > 0:
            x_ = F.pad(x_, (pad, 0))  # causal left padding
        y = self.conv(x_)
        return rearrange(y, "b d n -> b n d")


class MSCM(nn.Module):
    """Two-scale depth-wise causal convolution mixer."""

    def __init__(self, d_model: int, kernel_size: int = 3, dropout: float = 0.1):
        super().__init__()
        self.ln = nn.LayerNorm(d_model)
        self.conv1 = _CausalDepthwiseConv1d(d_model, kernel_size, dilation=1)
        self.conv2 = _CausalDepthwiseConv1d(d_model, kernel_size, dilation=3)
        self.gate = nn.GLU(dim=-1)
        self.out = nn.Linear(d_model, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor):
        residual = x
        x = self.ln(x)
        y1, y2 = self.conv1(x), self.conv2(x)
        y = self.gate(torch.cat([y1, y2], dim=-1))
        y = self.out(y)
        return residual + self.dropout(y)


# -------------------------------------------------------------------------------------
# 3. Exponential Recurrent Memory (unchanged)
# -------------------------------------------------------------------------------------
class ExponentialMemory(nn.Module):
    """Gated exponential moving-average memory (O(N))."""

    def __init__(self, d_model: int, dropout: float = 0.1, chunk_size: int = 256):
        super().__init__()
        self.chunk_size = chunk_size
        self.log_decay = nn.Parameter(torch.zeros(d_model))  # sigmoid(log_decay) ≈ 0.5 at init
        self.gate_proj = nn.Linear(d_model, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)
        self.ln = nn.LayerNorm(d_model)

    # ------------------------------------------------------------------
    def _step_chunk(
        self,
        x: torch.Tensor,  # (B, S, D)
        memory: torch.Tensor,  # (B, D)
        a: torch.Tensor,  # (1, D)
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        B, S, D = x.shape
        out = torch.empty_like(x)
        for i in range(S):  # S ≤ chunk_size (≤256) so Python loop acceptable
            x_t = x[:, i]
            memory = a * memory + (1.0 - a) * x_t
            g_t = torch.sigmoid(self.gate_proj(x_t))
            out[:, i] = x_t + g_t * memory
        return out, memory

    # ------------------------------------------------------------------
    def forward(self, x: torch.Tensor):  # (B, N, D)
        x = self.ln(x)
        B, N, D = x.shape
        a = torch.sigmoid(self.log_decay).unsqueeze(0)  # (1, D)
        memory = torch.zeros((B, D), device=x.device, dtype=x.dtype)
        chunks: List[torch.Tensor] = []
        for s in range(0, N, self.chunk_size):
            e = min(N, s + self.chunk_size)
            y, memory = self._step_chunk(x[:, s:e], memory, a)
            chunks.append(y)
        y = torch.cat(chunks, dim=1)
        return self.dropout(y)


# -------------------------------------------------------------------------------------
# Encoder Block (Attention → FF → Conv → Memory)
# -------------------------------------------------------------------------------------
class EncoderBlock(nn.Module):
    def __init__(
        self,
        d_model: int,
        n_heads: int,
        d_ff: int,
        chunk_size: int,
        dropout: float,
        drop_path: float,
    ) -> None:
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.attn = ChunkwiseCausalLinearSelfAttention(
            d_model,
            n_heads,
            chunk_size=chunk_size,
            dropout=dropout,
        )
        self.ln2 = nn.LayerNorm(d_model)
        self.ff = GEGLU(d_model, d_ff)
        self.conv_mixer = MSCM(d_model, dropout=dropout)
        self.memory = ExponentialMemory(d_model, dropout=dropout, chunk_size=chunk_size)
        self.drop_path = DropPath(drop_path) if drop_path > 0.0 else nn.Identity()
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor):  # (B, N, D)
        x = x + self.drop_path(self.attn(self.ln1(x)))  # 1. Linear attention + RoPE
        x = x + self.drop_path(self.dropout(self.ff(self.ln2(x))))  # 2. GEGLU FFN
        x = self.conv_mixer(x)  # 3. Convolutional mixer (has its own residual)
        x = x + self.drop_path(self.memory(x))  # 4. Exponential memory path
        return x


# -------------------------------------------------------------------------------------
# DeltaNet – main model
# -------------------------------------------------------------------------------------
class DeltaNet(nn.Module):
    """DeltaNet: linear attention + conv mixer + recurrent memory + RoPE."""

    def __init__(
        self,
        d_model: int = 512,
        n_heads: int = 8,
        num_layers: int = 6,
        d_ff: int = 2048,
        chunk_size: int = 256,
        dropout: float = 0.1,
        drop_path: float = 0.05,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        if d_model % n_heads != 0:
            raise ValueError("d_model must be divisible by n_heads")
        # progressive drop-path schedule (depth-weighted)
        dpr = (
            [drop_path * i / (num_layers - 1) for i in range(num_layers)]
            if num_layers > 1
            else [drop_path]
        )
        self.layers = nn.ModuleList(
            [
                EncoderBlock(
                    d_model,
                    n_heads,
                    d_ff,
                    chunk_size,
                    dropout,
                    dpr[i],
                )
                for i in range(num_layers)
            ]
        )
        self.final_ln = nn.LayerNorm(d_model)

    # compile only heavy matmul path to reduce overhead (PyTorch 2.0+)
    @torch.compile(mode="reduce-overhead")  # type: ignore[decorator-typing]
    def forward(self, x: torch.Tensor, **kwargs):  # (B, N, D)
        for layer in self.layers:
            x = layer(x)
        return self.final_ln(x)
