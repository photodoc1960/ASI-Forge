from __future__ import annotations

"""
DeltaNet v2 – Mixture-of-Experts Feed-Forward (MoE) + Existing LayerScale / RMSNorm stack
========================================================================================
This evolution introduces a **token-wise Mixture-of-Experts (MoE) feed-forward** module
inside every encoder block, replacing the single GEGLU feed-forward with a *soft* expert
routing mechanism.

Why Mixture-of-Experts?
-----------------------
1. **Capacity Scaling** – MoE increases *parameter* and *representational* capacity
   without proportionally increasing the *compute per token*: each expert is an
   independent GEGLU MLP; their outputs are combined through a learned, per-token
   soft gate.
2. **Sparsity Ready** – although we use *soft* gating by default (every expert is
   evaluated), the implementation is compatible with future top-k or sparse routing
   strategies for even better compute/parameter trade-offs.
3. **Research Backing** – MoE layers (Shazeer et al. 2017; Lepikhin et al. 2021 –
   Switch Transformer) consistently show strong gains on language modelling and
   reasoning tasks by providing specialist subnetworks.

Technical Highlights
--------------------
• **Sub-Quadratic Complexity**: Each expert processes the full sequence but remains
  O(N) w.r.t. sequence length (identical to the replaced GEGLU block).
• **Batch-Size Agnostic**: All tensor shapes are derived at runtime; no hard-coded
  batch assumptions.
• **Chunk-Friendly**: MoE operates purely on the embedding dimension → it does not
  interfere with the chunked causal strategy used by attention / memory modules.
• **Seamless Integration**: Public APIs, class names and signatures remain unchanged
  (EncoderBlock still expects *d_ff* even though the internal capacity rises by
  *n_experts*).

Implementation Details
----------------------
A new `MoEGEGLU` module:
    ‑ Consists of *n_experts* independent GEGLU experts
    ‑ A linear *gate* projects tokens to an E-dim simplex via softmax
    ‑ Per-token expert outputs are stacked and combined using the gate weights
    ‑ A dropout layer follows for regularisation

The EncoderBlock now instantiates `MoEGEGLU` (default `n_experts=4`) and keeps the
LayerScale residual gating identical to previous versions.
"""

import math
from typing import Any, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from einops import rearrange
except ImportError:
    # einops is required, but provide a helpful error if missing so that unit tests fail fast
    def rearrange(x, pattern, **axes_lengths):  # type: ignore[unused-arg]
        raise ImportError(
            "einops is required for rearrange. Please install einops or ensure it is available."
        )

__all__ = [
    "DeltaNet",
]

# -------------------------------------------------------------------------------------
# Normalisation & Utility blocks (unchanged from v1)
# -------------------------------------------------------------------------------------
class RMSNorm(nn.Module):
    """Root-mean-square Layer Normalisation (parameter-wise rescale only)."""

    def __init__(self, d_model: int, eps: float = 1e-8) -> None:
        super().__init__()
        self.eps = eps
        self.scale = nn.Parameter(torch.ones(d_model))

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        rms = torch.sqrt(torch.mean(x ** 2, dim=-1, keepdim=True) + self.eps)
        return x / rms * self.scale  # type: ignore[no-redef]


class GEGLU(nn.Module):
    """Gated Linear Unit with GELU activation (GEGLU)."""

    def __init__(self, d_model: int, d_ff: int):
        super().__init__()
        self.proj = nn.Linear(d_model, d_ff * 2, bias=False)
        self.out = nn.Linear(d_ff, d_model, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        u, v = self.proj(x).chunk(2, dim=-1)
        return self.out(F.gelu(u) * v)


class DropPath(nn.Module):
    """Stochastic depth (a.k.a DropPath)."""

    def __init__(self, p: float = 0.0):
        super().__init__()
        self.p = p

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        if not self.training or self.p == 0.0:
            return x
        keep_prob = 1.0 - self.p
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        mask = torch.rand(shape, dtype=x.dtype, device=x.device) < keep_prob
        return x * mask / keep_prob


# -------------------------------------------------------------------------------------
# NEW: Mixture-of-Experts GEGLU feed-forward
# -------------------------------------------------------------------------------------
class MoEGEGLU(nn.Module):
    """Token-wise Mixture-of-Experts using GEGLU experts and soft routing.

    Args:
        d_model: embedding dimension
        d_ff: hidden dimension **per expert** (total hidden = n_experts * d_ff)
        n_experts: number of experts
        dropout: dropout probability applied *after* expert aggregation
    """

    def __init__(
        self,
        d_model: int,
        d_ff: int,
        n_experts: int = 4,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.n_experts = n_experts
        # Experts – independent parameters
        self.experts = nn.ModuleList(
            [GEGLU(d_model, d_ff) for _ in range(n_experts)]
        )
        # Routing gate
        self.gate = nn.Linear(d_model, n_experts, bias=False)
        self.softmax = nn.Softmax(dim=-1)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        B, N, D = x.shape
        gate_logits = self.gate(x)  # (B, N, E)
        gate_probs = self.softmax(gate_logits)  # (B, N, E)

        # Collect expert outputs – list -> tensor (E, B, N, D)
        expert_outs = [expert(x) for expert in self.experts]
        expert_stack = torch.stack(expert_outs, dim=-1)  # (B, N, D, E)

        # Weighted combination: (B, N, D, E) • (B, N, E) -> (B, N, D)
        y = torch.einsum("b n d e, b n e -> b n d", expert_stack, gate_probs)
        return self.dropout(y)


# -------------------------------------------------------------------------------------
# Rotary positional embedding helper  (identical to v1)
# -------------------------------------------------------------------------------------
class _RotaryPositionalEmbedding:
    """Cache-friendly rotary embeddings for a single attention head-dim size."""

    def __init__(self, head_dim: int, base: int = 10000):
        if head_dim % 2 != 0:
            raise ValueError("Head dimension must be even for RoPE.")
        self.head_dim = head_dim
        self.base = base
        self._cached_seq_len: int = 0
        self._sin: Optional[torch.Tensor] = None
        self._cos: Optional[torch.Tensor] = None

    def _build_cache(self, seq_len: int, device: torch.device, dtype: torch.dtype) -> None:
        if (
            seq_len <= self._cached_seq_len
            and self._sin is not None
            and self._cos is not None
        ):
            if self._sin.device != device:
                self._sin = self._sin.to(device)
                self._cos = self._cos.to(device)
            if self._sin.dtype != dtype:
                self._sin = self._sin.to(dtype=dtype)
                self._cos = self._cos.to(dtype=dtype)
            return

        self._cached_seq_len = seq_len
        pos = torch.arange(seq_len, device=device, dtype=dtype)
        dim = torch.arange(0, self.head_dim, 2, device=device, dtype=dtype)
        inv_freq = 1.0 / (self.base ** (dim / self.head_dim))
        sinusoid = torch.einsum("n,d->nd", pos, inv_freq)
        self._sin = torch.sin(sinusoid).repeat_interleave(2, dim=-1)
        self._cos = torch.cos(sinusoid).repeat_interleave(2, dim=-1)

    def apply(self, x: torch.Tensor) -> torch.Tensor:
        if x.shape[-1] != self.head_dim:
            raise ValueError("Unexpected head_dim for RoPE.")
        device, dtype = x.device, x.dtype
        seq_len = x.shape[1]
        self._build_cache(seq_len, device, dtype)

        if x.ndim == 3:
            sin = self._sin[:seq_len].unsqueeze(0)
            cos = self._cos[:seq_len].unsqueeze(0)
        elif x.ndim == 4:
            sin = self._sin[:seq_len].unsqueeze(0).unsqueeze(2)
            cos = self._cos[:seq_len].unsqueeze(0).unsqueeze(2)
        else:
            raise ValueError("RoPE only supports 3- or 4-D tensors.")

        x1, x2 = x[..., ::2], x[..., 1::2]
        x_rot = torch.stack([-x2, x1], dim=-1).reshape_as(x)
        return x * cos + x_rot * sin


# -------------------------------------------------------------------------------------
# 1. Chunk-wise causal linear self-attention  (unchanged from v1)
# -------------------------------------------------------------------------------------
class ChunkwiseCausalLinearSelfAttention(nn.Module):
    def __init__(
        self,
        d_model: int,
        n_heads: int,
        head_dim: Optional[int] = None,
        chunk_size: int = 256,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = head_dim or d_model // n_heads
        if self.head_dim * n_heads != d_model:
            raise ValueError("d_model must be divisible by num_heads")
        if self.head_dim % 2 != 0:
            raise ValueError("head_dim must be even for RoPE")

        self.chunk_size = chunk_size
        self.dropout = nn.Dropout(dropout)
        self.qkv_proj = nn.Linear(d_model, d_model * 3, bias=False)
        self.o_proj = nn.Linear(d_model, d_model, bias=False)
        self.rope = _RotaryPositionalEmbedding(self.head_dim)
        self.register_buffer("eps", torch.tensor(1e-6), persistent=False)

    @staticmethod
    def _feature_map(x: torch.Tensor) -> torch.Tensor:
        return F.elu(x) + 1.0

    def _step_chunk(
        self,
        q_chunk: torch.Tensor,
        k_chunk: torch.Tensor,
        v_chunk: torch.Tensor,
        k_prefix: torch.Tensor,
        kv_prefix: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        k_cumsum = torch.cumsum(k_chunk, dim=1) + k_prefix[:, None]
        kv = torch.einsum("b s h d, b s h e -> b s h d e", k_chunk, v_chunk)
        kv_cumsum = torch.cumsum(kv, dim=1) + kv_prefix[:, None]

        num = torch.einsum("b s h d, b s h d e -> b s h e", q_chunk, kv_cumsum)
        den = torch.einsum("b s h d, b s h d -> b s h", q_chunk, k_cumsum)
        out = num / (den.unsqueeze(-1) + self.eps)

        k_prefix = k_prefix + k_chunk.sum(dim=1)
        kv_prefix = kv_prefix + kv.sum(dim=1)
        return out, k_prefix, kv_prefix

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        B, N, _ = x.shape
        qkv = self.qkv_proj(x)
        q, k, v = qkv.chunk(3, dim=-1)
        q = rearrange(q, "b n (h d) -> b n h d", h=self.n_heads)
        k = rearrange(k, "b n (h d) -> b n h d", h=self.n_heads)
        v = rearrange(v, "b n (h d) -> b n h d", h=self.n_heads)

        q = self.rope.apply(q)
        k = self.rope.apply(k)

        q = self._feature_map(q)
        k = self._feature_map(k)

        device, dtype = x.device, x.dtype
        Dh = self.head_dim
        k_prefix = torch.zeros((B, self.n_heads, Dh), device=device, dtype=dtype)
        kv_prefix = torch.zeros((B, self.n_heads, Dh, Dh), device=device, dtype=dtype)

        out_chunks: List[torch.Tensor] = []
        for start in range(0, N, self.chunk_size):
            end = min(start + self.chunk_size, N)
            q_chunk = q[:, start:end]
            k_chunk = k[:, start:end]
            v_chunk = v[:, start:end]
            out_chunk, k_prefix, kv_prefix = self._step_chunk(
                q_chunk, k_chunk, v_chunk, k_prefix, kv_prefix
            )
            out_chunks.append(out_chunk)

        out = torch.cat(out_chunks, dim=1)
        out = rearrange(out, "b n h d -> b n (h d)")
        return self.dropout(self.o_proj(out))


# -------------------------------------------------------------------------------------
# 2. Multi-Scale Causal Convolutional Mixer (unchanged)
# -------------------------------------------------------------------------------------
class _CausalDepthwiseConv1d(nn.Module):
    def __init__(self, d_model: int, kernel_size: int, dilation: int):
        super().__init__()
        self.kernel_size = kernel_size
        self.dilation = dilation
        self.conv = nn.Conv1d(
            d_model, d_model, kernel_size, groups=d_model, dilation=dilation, bias=False
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        x_ = rearrange(x, "b n d -> b d n")
        pad_len = self.dilation * (self.kernel_size - 1)
        if pad_len > 0:
            x_ = F.pad(x_, (pad_len, 0))
        y = self.conv(x_)
        return rearrange(y, "b d n -> b n d")


class MSCM(nn.Module):
    """Two-scale depth-wise causal convolution mixer."""

    def __init__(self, d_model: int, kernel_size: int = 3, dropout: float = 0.1):
        super().__init__()
        self.ln = RMSNorm(d_model)
        self.conv1 = _CausalDepthwiseConv1d(d_model, kernel_size, dilation=1)
        self.conv2 = _CausalDepthwiseConv1d(d_model, kernel_size, dilation=3)
        self.gate = nn.GLU(dim=-1)
        self.out = nn.Linear(d_model, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.ln(x)
        y1, y2 = self.conv1(x), self.conv2(x)
        y = self.gate(torch.cat([y1, y2], dim=-1))
        y = self.out(y)
        return residual + self.dropout(y)


# -------------------------------------------------------------------------------------
# 3. Exponential Recurrent Memory (unchanged)
# -------------------------------------------------------------------------------------
class ExponentialMemory(nn.Module):
    def __init__(self, d_model: int, dropout: float = 0.1, chunk_size: int = 256):
        super().__init__()
        self.d_model = d_model
        self.chunk_size = chunk_size
        self.log_decay = nn.Parameter(torch.zeros(d_model))
        self.gate_proj = nn.Linear(d_model, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)
        self.ln = RMSNorm(d_model)

    def _step_chunk(
        self,
        x_chunk: torch.Tensor,
        memory: torch.Tensor,
        a: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        B, S, D = x_chunk.shape
        out = torch.empty_like(x_chunk)
        for i in range(S):
            x_t = x_chunk[:, i]
            memory = a * memory + (1.0 - a) * x_t
            g_t = torch.sigmoid(self.gate_proj(x_t))
            out[:, i] = x_t + g_t * memory
        return out, memory

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.ln(x)
        B, N, D = x.shape
        a = torch.sigmoid(self.log_decay).unsqueeze(0)
        memory = torch.zeros((B, D), device=x.device, dtype=x.dtype)

        out_chunks: List[torch.Tensor] = []
        for start in range(0, N, self.chunk_size):
            end = min(start + self.chunk_size, N)
            chunk, memory = self._step_chunk(x[:, start:end], memory, a)
            out_chunks.append(chunk)
        y = torch.cat(out_chunks, dim=1)
        return self.dropout(y)


# -------------------------------------------------------------------------------------
# Encoder Block – Attention → MoE-FF → Conv → Memory
# -------------------------------------------------------------------------------------
class EncoderBlock(nn.Module):
    def __init__(
        self,
        d_model: int,
        n_heads: int,
        d_ff: int,
        chunk_size: int,
        dropout: float,
        drop_path: float,
        n_experts: int = 4,  # new – number of MoE experts
    ) -> None:
        super().__init__()
        layerscale_init = 1e-4

        self.ln1 = RMSNorm(d_model)
        self.attn = ChunkwiseCausalLinearSelfAttention(
            d_model, n_heads, chunk_size=chunk_size, dropout=dropout
        )
        self.gamma_attn = nn.Parameter(layerscale_init * torch.ones(d_model))

        # Mixture-of-Experts feed-forward
        self.ln2 = RMSNorm(d_model)
        self.ff = MoEGEGLU(d_model, d_ff, n_experts=n_experts, dropout=dropout)
        self.gamma_ff = nn.Parameter(layerscale_init * torch.ones(d_model))

        self.conv_mixer = MSCM(d_model, dropout=dropout)
        self.memory = ExponentialMemory(
            d_model, dropout=dropout, chunk_size=chunk_size
        )
        self.gamma_mem = nn.Parameter(layerscale_init * torch.ones(d_model))

        self.drop_path = DropPath(drop_path) if drop_path > 0.0 else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        x = x + self.drop_path(self.gamma_attn * self.attn(self.ln1(x)))
        x = x + self.drop_path(self.gamma_ff * self.ff(self.ln2(x)))
        x = self.conv_mixer(x)
        x = x + self.drop_path(self.gamma_mem * self.memory(x))
        return x


# -------------------------------------------------------------------------------------
# DeltaNet – main model
# -------------------------------------------------------------------------------------
class DeltaNet(nn.Module):
    """DeltaNet – linear attention + MoE feed-forward + conv mixer + memory + RoPE + LayerScale + RMSNorm."""

    def __init__(
        self,
        d_model: int = 512,
        n_heads: int = 8,
        num_layers: int = 6,
        d_ff: int = 2048,
        chunk_size: int = 256,
        dropout: float = 0.1,
        drop_path: float = 0.05,
        n_experts: int = 4,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        dpr = (
            [drop_path * i / (num_layers - 1) for i in range(num_layers)]
            if num_layers > 1
            else [drop_path]
        )
        self.layers = nn.ModuleList(
            [
                EncoderBlock(
                    d_model,
                    n_heads,
                    d_ff,
                    chunk_size,
                    dropout,
                    dpr[i],
                    n_experts=n_experts,
                )
                for i in range(num_layers)
            ]
        )
        self.final_norm = RMSNorm(d_model)

    @torch.compile(mode="reduce-overhead")  # type: ignore[misc]
    def forward(self, x: torch.Tensor, **kwargs) -> torch.Tensor:  # (B, N, D)
        for layer in self.layers:
            x = layer(x)
        return self.final_norm(x)
