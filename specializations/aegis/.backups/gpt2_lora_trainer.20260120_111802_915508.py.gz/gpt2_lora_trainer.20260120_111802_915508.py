"""
GPT2LoRATrainer - Phase 2: GPT-2 Fine-Tuning with LoRA

Fine-tunes GPT-2 using Low-Rank Adaptation (LoRA) on collected agent
decision data. This improves the agent's decision-making by learning
from successful state → action mappings.

LoRA Configuration:
- Target modules: c_attn, c_proj
- Rank: 8
- Alpha: 16
- Dropout: 0.1
- Trainable parameters: ~800K (0.65% of model)
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

logger = logging.getLogger(__name__)


class AgentDecisionDataset(Dataset):
    """Dataset for agent state → action pairs."""

    def __init__(self, examples: List[Dict[str, Any]], tokenizer, max_length: int = 256):
        self.examples = examples
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self) -> int:
        return len(self.examples)

    def _format_state(self, state: Dict[str, Any]) -> str:
        """Convert agent state to text prompt."""
        goals = state.get('active_goals', [])
        current_goal = goals[0] if goals else "None"
        num_goals = len(goals)

        curiosity_count = state.get('curiosity_count', 0)
        knowledge_count = state.get('knowledge_count', 0)

        recent_actions = state.get('recent_actions', [])
        recent_str = " -> ".join(recent_actions[-3:]) if recent_actions else "none"

        prompt = (
            f"Agent state: {num_goals} active goals. "
            f"Current goal: {current_goal}. "
            f"{curiosity_count} curiosities. "
            f"{knowledge_count} knowledge items. "
            f"Recent: {recent_str}\n"
            f"Best action:"
        )
        return prompt

    def _format_action(self, action: Dict[str, Any]) -> str:
        """Convert action to target text."""
        action_type = action.get('action', 'idle')
        query = action.get('query', '')

        if query:
            return f" {action_type}({query})"
        return f" {action_type}"

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        example = self.examples[idx]

        prompt = self._format_state(example['state'])
        target = self._format_action(example['action'])
        full_text = prompt + target

        # Tokenize
        encodings = self.tokenizer(
            full_text,
            truncation=True,
            max_length=self.max_length,
            padding='max_length',
            return_tensors='pt'
        )

        input_ids = encodings['input_ids'].squeeze(0)
        attention_mask = encodings['attention_mask'].squeeze(0)

        # For causal LM, labels are the same as input_ids
        # We'll mask the prompt portion in the loss calculation
        labels = input_ids.clone()

        # Tokenize just the prompt to find where target starts
        prompt_encodings = self.tokenizer(
            prompt,
            truncation=True,
            max_length=self.max_length,
            return_tensors='pt'
        )
        prompt_length = prompt_encodings['input_ids'].shape[1]

        # Mask prompt tokens in labels (set to -100 to ignore in loss)
        labels[:prompt_length] = -100

        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'labels': labels
        }


class GPT2LoRATrainer:
    """
    Fine-tunes GPT-2 using LoRA (Low-Rank Adaptation).

    LoRA allows efficient fine-tuning by only training small adapter
    matrices (~800K parameters) while keeping the original GPT-2
    weights frozen.
    """

    def __init__(
        self,
        model_name: str = "gpt2",
        device: str = None,
        learning_rate: float = 1e-4,
        lora_rank: int = 8,
        lora_alpha: int = 16,
        lora_dropout: float = 0.1,
        target_modules: List[str] = None
    ):
        """
        Initialize GPT2LoRATrainer.

        Args:
            model_name: HuggingFace model name (default: gpt2)
            device: Device to train on (auto-detected if None)
            learning_rate: Learning rate for training
            lora_rank: LoRA rank (lower = fewer params, less capacity)
            lora_alpha: LoRA alpha scaling factor
            lora_dropout: Dropout for LoRA layers
            target_modules: Which modules to apply LoRA to
        """
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        self.learning_rate = learning_rate
        self.lora_rank = lora_rank
        self.lora_alpha = lora_alpha
        self.lora_dropout = lora_dropout
        self.target_modules = target_modules or ["c_attn", "c_proj"]

        # Load model and tokenizer
        self._load_model(model_name)

        # Training statistics
        self.total_epochs = 0
        self.best_loss = float('inf')

        logger.info(f"GPT2LoRATrainer initialized (device={self.device})")
        logger.info(f"LoRA config: rank={lora_rank}, alpha={lora_alpha}, dropout={lora_dropout}")
        logger.info(f"Target modules: {self.target_modules}")

    def _load_model(self, model_name: str) -> None:
        """Load GPT-2 model with LoRA adapters."""
        try:
            from transformers import GPT2LMHeadModel, GPT2Tokenizer
            from peft import get_peft_model, LoraConfig, TaskType
        except ImportError as e:
            raise ImportError(
                "Required packages not installed. Please run:\n"
                "pip install transformers peft"
            ) from e

        logger.info(f"Loading {model_name}...")

        # Load base model and tokenizer
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_name)
        self.tokenizer.pad_token = self.tokenizer.eos_token

        base_model = GPT2LMHeadModel.from_pretrained(model_name)

        # Configure LoRA
        lora_config = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            r=self.lora_rank,
            lora_alpha=self.lora_alpha,
            lora_dropout=self.lora_dropout,
            target_modules=self.target_modules,
            bias="none"
        )

        # Apply LoRA
        self.model = get_peft_model(base_model, lora_config)
        self.model.to(self.device)

        # Count parameters
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        total_params = sum(p.numel() for p in self.model.parameters())

        logger.info(f"Model loaded: {total_params:,} total parameters")
        logger.info(f"Trainable (LoRA): {trainable_params:,} parameters ({100*trainable_params/total_params:.2f}%)")

        # Initialize optimizer
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.learning_rate
        )

    def load_training_data(self, data_path: str) -> List[Dict[str, Any]]:
        """
        Load training examples from JSON file.

        Args:
            data_path: Path to training data JSON

        Returns:
            List of training examples
        """
        path = Path(data_path)
        if not path.exists():
            raise FileNotFoundError(f"Training data not found: {data_path}")

        with open(path, 'r') as f:
            data = json.load(f)

        examples = data.get('examples', data if isinstance(data, list) else [])
        logger.info(f"Loaded {len(examples)} training examples from {data_path}")

        return examples

    def train(
        self,
        examples: List[Dict[str, Any]],
        epochs: int = 3,
        batch_size: int = 4,
        checkpoint_dir: str = "checkpoints"
    ) -> Dict[str, Any]:
        """
        Train the model on collected examples.

        Args:
            examples: List of training examples
            epochs: Number of training epochs
            batch_size: Batch size for training
            checkpoint_dir: Directory to save checkpoints

        Returns:
            Training statistics
        """
        # Create checkpoint directory
        checkpoint_path = Path(checkpoint_dir)
        checkpoint_path.mkdir(parents=True, exist_ok=True)

        # Create dataset and dataloader
        dataset = AgentDecisionDataset(examples, self.tokenizer)
        dataloader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=0
        )

        logger.info("=" * 70)
        logger.info("GPT-2 + LoRA FINE-TUNING")
        logger.info("=" * 70)
        logger.info(f"Training on {len(examples)} examples for {epochs} epochs")
        logger.info(f"Batch size: {batch_size}")
        logger.info(f"Device: {self.device}")
        logger.info("=" * 70)

        self.model.train()
        training_stats = []

        for epoch in range(epochs):
            total_loss = 0.0
            num_batches = 0

            for batch in dataloader:
                # Move to device
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels'].to(self.device)

                # Forward pass
                self.optimizer.zero_grad()
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels
                )

                loss = outputs.loss

                # Backward pass
                loss.backward()
                self.optimizer.step()

                total_loss += loss.item()
                num_batches += 1

            avg_loss = total_loss / num_batches
            self.total_epochs += 1

            logger.info(f"Epoch {epoch + 1}/{epochs}: Loss={avg_loss:.4f} ({num_batches} batches)")

            training_stats.append({
                'epoch': epoch + 1,
                'loss': avg_loss
            })

            # Save checkpoint
            ckpt_path = checkpoint_path / f"gpt2_lora_epoch_{epoch + 1}.pt"
            self.save_checkpoint(str(ckpt_path))
            logger.info(f"  ✓ Checkpoint saved: {ckpt_path}")

            # Track best loss
            if avg_loss < self.best_loss:
                self.best_loss = avg_loss

        # Save final model
        final_path = checkpoint_path / "gpt2_lora_trained.pt"
        self.save_checkpoint(str(final_path))

        logger.info("")
        logger.info(f"✓ Training complete! Final model saved: {final_path}")
        logger.info(f"  Final loss: {training_stats[-1]['loss']:.4f}")
        logger.info("=" * 70)

        return {
            'epochs': epochs,
            'final_loss': training_stats[-1]['loss'],
            'best_loss': self.best_loss,
            'training_stats': training_stats
        }

    def train_epoch(self, examples: List[Dict[str, Any]], batch_size: int = 4) -> Tuple[float, float]:
        """
        Train for a single epoch (for compatibility with existing training loops).

        Args:
            examples: Training examples
            batch_size: Batch size

        Returns:
            Tuple of (loss, accuracy)
        """
        dataset = AgentDecisionDataset(examples, self.tokenizer)
        dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

        self.model.train()
        total_loss = 0.0
        num_batches = 0

        for batch in dataloader:
            input_ids = batch['input_ids'].to(self.device)
            attention_mask = batch['attention_mask'].to(self.device)
            labels = batch['labels'].to(self.device)

            self.optimizer.zero_grad()
            outputs = self.model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                labels=labels
            )

            loss = outputs.loss
            loss.backward()
            self.optimizer.step()

            total_loss += loss.item()
            num_batches += 1

        avg_loss = total_loss / max(num_batches, 1)
        self.total_epochs += 1

        # Estimate accuracy (approximation based on loss)
        # Lower loss generally means better predictions
        accuracy = max(0.0, min(1.0, 1.0 - (avg_loss / 10.0)))

        return avg_loss, accuracy

    def save_checkpoint(self, path: str) -> None:
        """Save model checkpoint."""
        checkpoint_path = Path(path)
        checkpoint_path.parent.mkdir(parents=True, exist_ok=True)

        # Save LoRA weights
        self.model.save_pretrained(str(checkpoint_path.parent / checkpoint_path.stem))

        # Also save training state
        state = {
            'total_epochs': self.total_epochs,
            'best_loss': self.best_loss,
            'optimizer_state': self.optimizer.state_dict()
        }
        torch.save(state, path)

        logger.debug(f"Checkpoint saved: {path}")

    def load_checkpoint(self, path: str) -> None:
        """Load model checkpoint."""
        if not Path(path).exists():
            raise FileNotFoundError(f"Checkpoint not found: {path}")

        state = torch.load(path, map_location=self.device)
        self.total_epochs = state.get('total_epochs', 0)
        self.best_loss = state.get('best_loss', float('inf'))

        if 'optimizer_state' in state:
            self.optimizer.load_state_dict(state['optimizer_state'])

        logger.info(f"Checkpoint loaded: {path}")

    def generate(self, prompt: str, max_length: int = 50) -> str:
        """
        Generate text completion for a prompt.

        Args:
            prompt: Input prompt
            max_length: Maximum generation length

        Returns:
            Generated text
        """
        self.model.eval()

        inputs = self.tokenizer(prompt, return_tensors='pt').to(self.device)

        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_length=max_length,
                num_return_sequences=1,
                pad_token_id=self.tokenizer.eos_token_id,
                do_sample=True,
                temperature=0.7
            )

        generated = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return generated
