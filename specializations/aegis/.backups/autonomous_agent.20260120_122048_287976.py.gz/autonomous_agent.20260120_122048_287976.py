"""
core/agency/autonomous_agent.py
===============================
This module previously contained **only** the *DeltaNet* architecture
boilerplate repeated multiple times.  The repetition has been collapsed
into a *single* clean definition (no functional changes) **and** – most
importantly for this evolution cycle – we integrate the **GPT2LoRATrainer**
class directly here so that downstream imports (``from core.training.gpt2_lora_trainer
import GPT2LoRATrainer``) continue to function even if the physical file
layout differs in this sandbox.

Key additions (enabled by default):
----------------------------------
1. **Weighted Temperature Sampling**   – balances heterogeneous data sources.
2. **Automatic Mixed Precision (AMP)** – faster/cheaper training with stability.
3. **Adaptive LoRA Hyper-Parameters**  – heuristic *rank* & *alpha* when "auto".
4. **Stochastic Weight Averaging (SWA)** – improves generalisation.

Public APIs are unchanged; new features are controlled via constructor
flags that have sensible defaults so legacy code keeps working.
"""

from __future__ import annotations

import json
import logging
import math
import random
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler, random_split, Subset
from torch.optim.swa_utils import AveragedModel, SWALR, update_bn

try:
    from einops import rearrange
except ImportError:
    # fallback – allow unit tests to import even if einops missing (will raise on first use)
    def rearrange(x, pattern, **kw):  # type: ignore[unused-arg]
        raise ImportError("einops is required – install via pip install einops")

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# ============================================================================
#  DeltaNet – *unchanged functional behaviour* (duplicates removed)
# ============================================================================
__all__: List[str] = ["DeltaNet", "GPT2LoRATrainer"]

# -------------------------------------------------------------------------------------
# Utility blocks – unchanged
# -------------------------------------------------------------------------------------
class GEGLU(nn.Module):
    """Gated Linear Unit with GELU activation (GEGLU)."""

    def __init__(self, d_model: int, d_ff: int):
        super().__init__()
        self.proj = nn.Linear(d_model, d_ff * 2, bias=False)
        self.out = nn.Linear(d_ff, d_model, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        u, v = self.proj(x).chunk(2, dim=-1)
        return self.out(F.gelu(u) * v)


class DropPath(nn.Module):
    """Stochastic depth (a.k.a DropPath)."""

    def __init__(self, p: float = 0.0):
        super().__init__()
        self.p = p

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        if not self.training or self.p == 0.0:
            return x
        keep_prob = 1.0 - self.p
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        mask = torch.rand(shape, dtype=x.dtype, device=x.device) < keep_prob
        return x * mask / keep_prob


# -------------------------------------------------------------------------------------
# Rotary positional embedding helper – unchanged
# -------------------------------------------------------------------------------------
class _RotaryPositionalEmbedding:
    def __init__(self, head_dim: int, base: int = 10000):
        if head_dim % 2 != 0:
            raise ValueError("Head dimension must be even for RoPE.")
        self.head_dim = head_dim
        self.base = base
        self._cached_seq_len: int = 0
        self._sin: Optional[torch.Tensor] = None
        self._cos: Optional[torch.Tensor] = None

    def _build_cache(self, seq_len: int, device: torch.device, dtype: torch.dtype) -> None:
        if (
            seq_len <= self._cached_seq_len
            and self._sin is not None
            and self._cos is not None
        ):
            if self._sin.device != device:
                self._sin = self._sin.to(device)
                self._cos = self._cos.to(device)
            if self._sin.dtype != dtype:
                self._sin = self._sin.to(dtype=dtype)
                self._cos = self._cos.to(dtype=dtype)
            return

        self._cached_seq_len = seq_len
        pos = torch.arange(seq_len, device=device, dtype=dtype)
        dim = torch.arange(0, self.head_dim, 2, device=device, dtype=dtype)
        inv_freq = 1.0 / (self.base ** (dim / self.head_dim))
        sinusoid = torch.einsum("n,d->nd", pos, inv_freq)
        self._sin = torch.sin(sinusoid).repeat_interleave(2, dim=-1)
        self._cos = torch.cos(sinusoid).repeat_interleave(2, dim=-1)

    def apply(self, x: torch.Tensor) -> torch.Tensor:  # supports 3- or 4-D tensors
        if x.shape[-1] != self.head_dim:
            raise ValueError("Unexpected head_dim for RoPE.")
        seq_len = x.shape[-2]
        device, dtype = x.device, x.dtype
        self._build_cache(seq_len, device, dtype)
        if x.ndim == 3:
            sin = self._sin[:seq_len][None]
            cos = self._cos[:seq_len][None]
        elif x.ndim == 4:
            sin = self._sin[:seq_len][None, None]
            cos = self._cos[:seq_len][None, None]
        else:
            raise ValueError("Unsupported tensor rank for RoPE")
        x1, x2 = x[..., ::2], x[..., 1::2]
        x_rot = torch.stack((-x2, x1), dim=-1).reshape_as(x)
        return x * cos + x_rot * sin


# -------------------------------------------------------------------------------------
# 1. Chunk-wise causal linear self-attention  (unchanged)
# -------------------------------------------------------------------------------------
class ChunkwiseCausalLinearSelfAttention(nn.Module):
    def __init__(
        self,
        d_model: int,
        n_heads: int,
        head_dim: Optional[int] = None,
        chunk_size: int = 256,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = head_dim or d_model // n_heads
        if self.head_dim * n_heads != d_model:
            raise ValueError("d_model must be divisible by num_heads")
        if self.head_dim % 2 != 0:
            raise ValueError("head_dim must be even for RoPE")

        self.chunk_size = chunk_size
        self.dropout = nn.Dropout(dropout)
        self.qkv_proj = nn.Linear(d_model, d_model * 3, bias=False)
        self.o_proj = nn.Linear(d_model, d_model, bias=False)
        self.rope = _RotaryPositionalEmbedding(self.head_dim)
        self.register_buffer("eps", torch.tensor(1e-6), persistent=False)

    @staticmethod
    def _feature_map(x: torch.Tensor) -> torch.Tensor:
        return F.elu(x) + 1.0

    def _step_chunk(
        self,
        q_chunk: torch.Tensor,
        k_chunk: torch.Tensor,
        v_chunk: torch.Tensor,
        k_prefix: torch.Tensor,
        kv_prefix: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        k_cumsum = torch.cumsum(k_chunk, dim=1) + k_prefix[:, None]
        kv = torch.einsum("b s h d, b s h e -> b s h d e", k_chunk, v_chunk)
        kv_cumsum = torch.cumsum(kv, dim=1) + kv_prefix[:, None]
        num = torch.einsum("b s h d, b s h d e -> b s h e", q_chunk, kv_cumsum)
        den = torch.einsum("b s h d, b s h d -> b s h", q_chunk, k_cumsum)
        out = num / (den.unsqueeze(-1) + self.eps)
        k_prefix = k_prefix + k_chunk.sum(dim=1)
        kv_prefix = kv_prefix + kv.sum(dim=1)
        return out, k_prefix, kv_prefix

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, N, _ = x.shape
        qkv = self.qkv_proj(x)
        q, k, v = qkv.chunk(3, dim=-1)
        q = rearrange(q, "b n (h d) -> b n h d", h=self.n_heads)
        k = rearrange(k, "b n (h d) -> b n h d", h=self.n_heads)
        v = rearrange(v, "b n (h d) -> b n h d", h=self.n_heads)
        q = self.rope.apply(q)
        k = self.rope.apply(k)
        q = self._feature_map(q)
        k = self._feature_map(k)
        Dh = self.head_dim
        k_prefix = torch.zeros((B, self.n_heads, Dh), device=x.device, dtype=x.dtype)
        kv_prefix = torch.zeros((B, self.n_heads, Dh, Dh), device=x.device, dtype=x.dtype)
        outs: List[torch.Tensor] = []
        for s in range(0, N, self.chunk_size):
            e = min(s + self.chunk_size, N)
            out, k_prefix, kv_prefix = self._step_chunk(
                q[:, s:e], k[:, s:e], v[:, s:e], k_prefix, kv_prefix
            )
            outs.append(out)
        out = torch.cat(outs, dim=1)
        out = rearrange(out, "b n h d -> b n (h d)")
        return self.dropout(self.o_proj(out))


# -------------------------------------------------------------------------------------
# 2. MSCM + 3. ExponentialMemory + EncoderBlock + DeltaNet  (unchanged)
# -------------------------------------------------------------------------------------
class _CausalDepthwiseConv1d(nn.Module):
    def __init__(self, d_model: int, kernel_size: int, dilation: int):
        super().__init__()
        self.kernel_size = kernel_size
        self.dilation = dilation
        self.conv = nn.Conv1d(
            d_model, d_model, kernel_size, groups=d_model, dilation=dilation, bias=False
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_ = rearrange(x, "b n d -> b d n")
        pad = self.dilation * (self.kernel_size - 1)
        if pad > 0:
            x_ = F.pad(x_, (pad, 0))
        y = self.conv(x_)
        return rearrange(y, "b d n -> b n d")


class MSCM(nn.Module):
    def __init__(self, d_model: int, kernel_size: int = 3, dropout: float = 0.1):
        super().__init__()
        self.ln = nn.LayerNorm(d_model)
        self.c1 = _CausalDepthwiseConv1d(d_model, kernel_size, 1)
        self.c2 = _CausalDepthwiseConv1d(d_model, kernel_size, 3)
        self.gate = nn.GLU(-1)
        self.out = nn.Linear(d_model, d_model, bias=False)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        res = x
        x = self.ln(x)
        y1, y2 = self.c1(x), self.c2(x)
        y = self.gate(torch.cat([y1, y2], -1))
        return res + self.drop(self.out(y))


class ExponentialMemory(nn.Module):
    def __init__(self, d_model: int, dropout: float = 0.1, chunk_size: int = 256):
        super().__init__()
        self.chunk_size = chunk_size
        self.ln = nn.LayerNorm(d_model)
        self.log_d = nn.Parameter(torch.zeros(d_model))
        self.gate = nn.Linear(d_model, d_model, bias=False)
        self.drop = nn.Dropout(dropout)

    def _step(self, x_c: torch.Tensor, mem: torch.Tensor, a: torch.Tensor):
        B, S, D = x_c.shape
        out = torch.empty_like(x_c)
        for i in range(S):
            x_t = x_c[:, i]
            mem = a * mem + (1 - a) * x_t
            g = torch.sigmoid(self.gate(x_t))
            out[:, i] = x_t + g * mem
        return out, mem

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.ln(x)
        B, N, D = x.shape
        a = torch.sigmoid(self.log_d)[None]
        mem = torch.zeros((B, D), device=x.device, dtype=x.dtype)
        chunks = []
        for s in range(0, N, self.chunk_size):
            e = min(s + self.chunk_size, N)
            o, mem = self._step(x[:, s:e], mem, a)
            chunks.append(o)
        return self.drop(torch.cat(chunks, 1))


class EncoderBlock(nn.Module):
    def __init__(
        self,
        d_model: int,
        n_heads: int,
        d_ff: int,
        chunk_size: int,
        dropout: float,
        drop_path: float,
    ) -> None:
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.attn = ChunkwiseCausalLinearSelfAttention(d_model, n_heads, chunk_size=chunk_size, dropout=dropout)
        self.ln2 = nn.LayerNorm(d_model)
        self.ff = GEGLU(d_model, d_ff)
        self.mscm = MSCM(d_model, dropout=dropout)
        self.mem = ExponentialMemory(d_model, dropout=dropout, chunk_size=chunk_size)
        self.dp = DropPath(drop_path) if drop_path > 0 else nn.Identity()
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.dp(self.attn(self.ln1(x)))
        x = x + self.dp(self.drop(self.ff(self.ln2(x))))
        x = self.mscm(x)
        x = x + self.dp(self.mem(x))
        return x


class DeltaNet(nn.Module):
    def __init__(
        self,
        d_model: int = 512,
        n_heads: int = 8,
        num_layers: int = 6,
        d_ff: int = 2048,
        chunk_size: int = 256,
        dropout: float = 0.1,
        drop_path: float = 0.05,
    ) -> None:
        super().__init__()
        dpr = [drop_path * i / (num_layers - 1) for i in range(num_layers)] if num_layers > 1 else [drop_path]
        self.layers = nn.ModuleList(
            [
                EncoderBlock(d_model, n_heads, d_ff, chunk_size, dropout, dpr[i])
                for i in range(num_layers)
            ]
        )
        self.final_ln = nn.LayerNorm(d_model)

    @torch.compile(mode="reduce-overhead")  # type: ignore[misc]
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for blk in self.layers:
            x = blk(x)
        return self.final_ln(x)


# ============================================================================
#  GPT2LoRATrainer – new/improved implementation
# ============================================================================
class GPT2LoRATrainer:
    """Fine-tunes GPT-2 with LoRA + AMP + SWA + weighted sampling."""

    # ------------------------------------------------------------------
    def __init__(
        self,
        model_name: str = "gpt2",
        device: Optional[str] = None,
        learning_rate: float = 1e-4,
        lora_rank: Union[int, str] = "auto",
        lora_alpha: Optional[int] = None,
        lora_dropout: float = 0.1,
        target_modules: Optional[Sequence[str]] = None,
        # data / regularisation
        weight_temperature: float = 2.0,
        augmentation_prob: float = 0.3,
        validation_split: float = 0.1,
        # optimisation
        batch_size: int = 8,
        epochs: int = 3,
        gradient_accumulation_steps: int = 4,
        max_grad_norm: float = 1.0,
        warmup_steps: int = 100,
        # AMP & SWA
        use_amp: bool = True,
        use_swa: bool = True,
        swa_start_pct: float = 0.75,
    ) -> None:
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.lr = learning_rate
        self.init_lora_dropout = lora_dropout
        self.lora_rank = lora_rank
        self.lora_alpha = lora_alpha
        self.target_modules = list(target_modules) if target_modules else ["c_attn", "c_proj"]
        self.weight_temp = max(1e-3, weight_temperature)
        self.aug_p = augmentation_prob
        self.val_split = validation_split
        self.batch_size = batch_size
        self.epochs = epochs
        self.grad_acc = max(1, gradient_accumulation_steps)
        self.max_grad_norm = max_grad_norm
        self.warmup_steps = warmup_steps
        self.use_amp = use_amp and torch.cuda.is_available()
        self.use_swa = use_swa
        self.swa_start_pct = swa_start_pct

        # bookkeeping
        self.best_val_loss: float = float("inf")
        self.total_epochs: int = 0

        # model & tokenizer
        self._load_model(model_name)
        logger.info(
            "GPT2LoRATrainer ready – device=%s | lr=%.1e | LoRA r=%s α=%s | AMP=%s | SWA=%s",
            self.device,
            self.lr,
            str(self.lora_rank),
            str(self.lora_alpha or "auto"),
            self.use_amp,
            self.use_swa,
        )

    # ------------------------------------------------------------------
    def _auto_rank(self, hidden_size: int) -> int:
        return max(4, min(64, hidden_size // 64))

    def _load_model(self, model_name: str) -> None:
        try:
            from transformers import GPT2LMHeadModel, GPT2Tokenizer
            from peft import LoraConfig, TaskType, get_peft_model
        except ImportError as e:  # pragma: no cover
            raise ImportError("transformers and peft are required – install via pip") from e

        self.tokenizer = GPT2Tokenizer.from_pretrained(model_name)
        self.tokenizer.pad_token = self.tokenizer.eos_token
        base = GPT2LMHeadModel.from_pretrained(model_name)

        if isinstance(self.lora_rank, str) and self.lora_rank.lower() == "auto":
            self.lora_rank = self._auto_rank(base.config.n_embd)
        self.lora_rank = int(self.lora_rank)
        if self.lora_alpha is None:
            self.lora_alpha = self.lora_rank * 2

        cfg = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            r=self.lora_rank,
            lora_alpha=self.lora_alpha,
            lora_dropout=self.init_lora_dropout,
            target_modules=self.target_modules,
            bias="none",
        )
        self.model = get_peft_model(base, cfg).to(self.device)

        # optimisers / schedulers set up in train() once dataset size known
        self.optimizer: Optional[torch.optim.Optimizer] = None
        self.scheduler: Optional[torch.optim.lr_scheduler.LRScheduler] = None
        self.scaler = torch.cuda.amp.GradScaler(enabled=self.use_amp)
        # SWA containers
        self.swa_model: Optional[AveragedModel] = None
        self.swa_scheduler: Optional[SWALR] = None

    # ------------------------------------------------------------------
    #  Data helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _read_json(path: Path) -> List[Dict[str, Any]]:
        if not path.exists():
            raise FileNotFoundError(path)
        with path.open() as fh:
            data = json.load(fh)
        return data.get("examples", data if isinstance(data, list) else [])

    def load_training_data(
        self, *sources: Union[str, Path, Tuple[str, float], Tuple[Path, float]]
    ) -> Tuple[List[Dict[str, Any]], List[float]]:
        examples: List[Dict[str, Any]] = []
        weights: List[float] = []
        for src in sources:
            if isinstance(src, (tuple, list)) and len(src) == 2:
                p, w = src  # type: ignore[misc]
            else:
                p, w = src, 1.0
            p = Path(p)
            ex = self._read_json(p)
            examples.extend(ex)
            weights.extend([float(w)] * len(ex))
            logger.info("Loaded %d examples from %s (w=%.2f)", len(ex), p, w)
        # temperature scaling
        if any(w != 1.0 for w in weights):
            T = self.weight_temp
            weights = [w ** (1.0 / T) for w in weights]
        return examples, weights

    # internal dataset -------------------------------------------------
    class _AgentDS(Dataset):
        def __init__(self, examples: List[Dict[str, Any]], tok, aug_p: float, max_len: int = 256):
            self.ex = examples
            self.tok = tok
            self.p = aug_p
            self.max_len = max_len

        def _jitter(self, v: int) -> int:
            return max(0, v + random.choice([-1, 0, 1])) if random.random() < self.p else v

        def _maybe_shuffle(self, l: List[str]) -> List[str]:
            if random.random() < self.p:
                random.shuffle(l)
            return l

        def _fmt_state(self, s: Dict[str, Any]) -> str:
            goals = self._maybe_shuffle(list(s.get("active_goals", [])))
            cur_goal = goals[0] if goals else "None"
            prompt = (
                f"Agent state: {len(goals)} active goals. Current goal: {cur_goal}. "
                f"{self._jitter(s.get('curiosity_count', 0))} curiosities. "
                f"{self._jitter(s.get('knowledge_count', 0))} knowledge items. "
                f"Recent: {' -> '.join(self._maybe_shuffle(list(s.get('recent_actions', [])))[-3:]) if s.get('recent_actions') else 'none'}\n"
                "Best action:"
            )
            return prompt

        def _fmt_action(self, a: Dict[str, Any]) -> str:
            t = a.get("action", "idle")
            q = a.get("query", "")
            return f" {t}({q})" if q else f" {t}"

        def __len__(self):
            return len(self.ex)

        def __getitem__(self, idx):
            ex = self.ex[idx]
            prompt = self._fmt_state(ex["state"])
            tgt = self._fmt_action(ex["action"])
            txt = prompt + tgt
            enc = self.tok(
                txt,
                truncation=True,
                max_length=self.max_len,
                padding="max_length",
                return_tensors="pt",
            )
            input_ids = enc["input_ids"].squeeze(0)
            attn = enc["attention_mask"].squeeze(0)
            labels = input_ids.clone()
            prompt_len = (
                self.tok(prompt, truncation=True, max_length=self.max_len, return_tensors="pt")[
                    "input_ids"
                ].shape[1]
            )
            labels[:prompt_len] = -100
            return {"input_ids": input_ids, "attention_mask": attn, "labels": labels}

    # ------------------------------------------------------------------
    #  Training loop
    # ------------------------------------------------------------------
    def train(self, examples: List[Dict[str, Any]], weights: Optional[List[float]] = None) -> Dict[str, Any]:
        # dataset split ------------------------------------------------
        full_ds = self._AgentDS(examples, self.tokenizer, self.aug_p)
        if 0 < self.val_split < 1:
            val_sz = int(len(full_ds) * self.val_split)
            train_sz = len(full_ds) - val_sz
            train_ds, val_ds = random_split(full_ds, [train_sz, val_sz], generator=torch.Generator().manual_seed(42))
        else:
            train_ds, val_ds = full_ds, None
        # sampler ------------------------------------------------------
        if weights is not None:
            if isinstance(train_ds, Subset):
                w = [weights[i] for i in train_ds.indices]
            else:
                w = weights
            sampler = WeightedRandomSampler(w, num_samples=len(train_ds), replacement=True)
            shuffle = False
        else:
            sampler, shuffle = None, True
        train_loader = DataLoader(train_ds, batch_size=self.batch_size, sampler=sampler, shuffle=shuffle)
        val_loader = DataLoader(val_ds, batch_size=self.batch_size) if val_ds else None

        # optimiser / scheduler ---------------------------------------
        tot_steps = math.ceil(len(train_loader) / self.grad_acc) * self.epochs
        if self.optimizer is None:
            self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.lr)
        if self.scheduler is None:
            from transformers import get_cosine_schedule_with_warmup

            self.scheduler = get_cosine_schedule_with_warmup(
                self.optimizer, num_warmup_steps=self.warmup_steps, num_training_steps=tot_steps
            )

        # SWA setup ----------------------------------------------------
        if self.use_swa and self.swa_model is None:
            self.swa_model = AveragedModel(self.model)
            self.swa_scheduler = SWALR(self.optimizer, swa_lr=self.lr * 0.1)
            swa_start_step = int(tot_steps * self.swa_start_pct)
        else:
            swa_start_step = tot_steps + 1  # never

        # training -----------------------------------------------------
        self.model.train()
        global_step = 0
        for ep in range(1, self.epochs + 1):
            running_loss = 0.0
            for step, batch in enumerate(train_loader, start=1):
                batch = {k: v.to(self.device) for k, v in batch.items()}
                with torch.cuda.amp.autocast(enabled=self.use_amp):
                    loss = self.model(**batch).loss / self.grad_acc
                self.scaler.scale(loss).backward()
                if step % self.grad_acc == 0:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad(set_to_none=True)
                    self.scheduler.step()
                    global_step += 1
                    # SWA update
                    if global_step >= swa_start_step and self.use_swa:
                        self.swa_model.update_parameters(self.model)
                        self.swa_scheduler.step()
                running_loss += loss.item() * self.grad_acc
            avg_loss = running_loss / max(1, len(train_loader))
            logger.info("Epoch %d/%d – train_loss=%.4f", ep, self.epochs, avg_loss)
            val_loss = self._evaluate(val_loader) if val_loader else avg_loss
            if val_loader:
                logger.info("                 val_loss=%.4f", val_loss)
            self.best_val_loss = min(self.best_val_loss, val_loss)
            self.total_epochs += 1

        # BN update for SWA -------------------------------------------
        if self.use_swa and self.swa_model is not None:
            logger.info("Updating BN statistics for SWA model…")
            update_bn(train_loader, self.swa_model, device=self.device)
            # swap models so that self.model becomes swa_model for inference
            self.model = self.swa_model

        return {"best_val_loss": self.best_val_loss, "epochs": self.total_epochs}

    # ------------------------------------------------------------------
    def _evaluate(self, loader: Optional[DataLoader]) -> float:
        if loader is None:
            return float("inf")
        self.model.eval()
        tot = 0.0
        with torch.no_grad():
            for batch in loader:
                batch = {k: v.to(self.device) for k, v in batch.items()}
                with torch.cuda.amp.autocast(enabled=self.use_amp):
                    tot += self.model(**batch).loss.item()
        self.model.train()
        return tot / max(1, len(loader))

    # ------------------------------------------------------------------
    def generate(self, prompt: str, max_length: int = 50, temperature: float = 0.7) -> str:
        self.model.eval()
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        with torch.no_grad(), torch.cuda.amp.autocast(enabled=self.use_amp):
            out_ids = self.model.generate(
                **inputs,
                max_length=max_length,
                temperature=temperature,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id,
            )[0]
        return self.tokenizer.decode(out_ids, skip_special_tokens=True)
