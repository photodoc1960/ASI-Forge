"""
GPT2LoRATrainer – Robustness & Adaptability v4
=============================================
This evolution focuses on *stability* and *device-adaptive precision* – two
pain-points observed in the previous generation:

1. **Variance-Safe Weight Normalisation**
   • Extreme dataset weight ratios can destabilise training when the
     `WeightedRandomSampler` over-focuses on a tiny corpus.  We now introduce a
     *clamp* controlled by `max_weight_ratio` (default **100×**).  After all
     sources are loaded the maximum weight is limited to *min_weight ·
     max_weight_ratio* – preventing runaway variance while still respecting the
     user-provided relative importances.

2. **Adaptive Mixed-Precision (AMP) + bfloat16 Support**
   • AMP automatically *disables itself* on CUDA devices with compute capability
     < 7.0 (no tensor cores).
   • `amp_dtype` ("auto" | "float16" | "bfloat16") lets users pick the desired
     precision.  The *auto* mode selects **bfloat16** on GPUs with ≥ SM 8.0
     (Ampere+) and `float16` otherwise – ensuring maximum throughput with safe
     numerical range on modern hardware.
   • All autocast contexts have been migrated to the unified
     `torch.cuda.amp.autocast(device_type="cuda", dtype=self.amp_dtype, …)` API.

These improvements are **enabled by default**; public APIs remain fully
backwards compatible – only optional parameters were appended with safe
defaults.
"""
from __future__ import annotations

import json
import logging
import math
import random
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple, Union

import torch
from torch.utils.data import (
    DataLoader,
    Dataset,
    WeightedRandomSampler,
    random_split,
    Subset,
)

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# ==============================================================================
#  Dataset – identical to v3 (but kept here for single-file distribution)
# ==============================================================================
class AgentDecisionDataset(Dataset):
    """Dataset of agent *state → action* pairs with optional augmentation & weights."""

    def __init__(
        self,
        examples: List[Dict[str, Any]],
        tokenizer,
        max_length: int = 256,
        augmentation_prob: float = 0.3,
        sample_weights: Optional[List[float]] = None,
    ) -> None:
        self.examples = examples
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.augmentation_prob = augmentation_prob
        self.weights = sample_weights if sample_weights is not None else [1.0] * len(examples)

    # ------------------------------------------------------------------
    # Helper – prompt / target formatting (identical to previous rev.)
    # ------------------------------------------------------------------
    def _format_state(self, state: Dict[str, Any]) -> str:
        goals = list(state.get("active_goals", []))
        if goals and random.random() < self.augmentation_prob:
            random.shuffle(goals)
        current_goal = goals[0] if goals else "None"
        num_goals = len(goals)

        def _jitter(val: int) -> int:
            if random.random() < self.augmentation_prob:
                return max(0, val + random.choice([-1, 0, 1]))
            return val

        curiosity_count = _jitter(state.get("curiosity_count", 0))
        knowledge_count = _jitter(state.get("knowledge_count", 0))

        recent_actions = list(state.get("recent_actions", []))
        if recent_actions and random.random() < self.augmentation_prob:
            random.shuffle(recent_actions)
        recent_str = " -> ".join(recent_actions[-3:]) if recent_actions else "none"

        prompt = (
            f"Agent state: {num_goals} active goals. "
            f"Current goal: {current_goal}. "
            f"{curiosity_count} curiosities. "
            f"{knowledge_count} knowledge items. "
            f"Recent: {recent_str}\n"
            f"Best action:"
        )
        return prompt

    @staticmethod
    def _format_action(action: Dict[str, Any]) -> str:
        action_type = action.get("action", "idle")
        query = action.get("query", "")
        return f" {action_type}({query})" if query else f" {action_type}"

    # ------------------------------------------------------------------
    def __len__(self) -> int:  # noqa: D401
        return len(self.examples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        example = self.examples[idx]
        prompt = self._format_state(example["state"])
        target = self._format_action(example["action"])
        full_text = prompt + target

        encodings = self.tokenizer(
            full_text,
            truncation=True,
            max_length=self.max_length,
            padding="max_length",
            return_tensors="pt",
        )
        input_ids = encodings["input_ids"].squeeze(0)
        attention_mask = encodings["attention_mask"].squeeze(0)
        labels = input_ids.clone()

        prompt_len = (
            self.tokenizer(prompt, truncation=True, max_length=self.max_length, return_tensors="pt")
            .input_ids.shape[1]
        )
        labels[:prompt_len] = -100  # mask prompt part

        return {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "labels": labels,
        }

    def get_weights(self) -> List[float]:
        return self.weights


# ==============================================================================
#  GPT2 + LoRA Trainer (v4)
# ==============================================================================
class GPT2LoRATrainer:
    """Fine-tunes GPT-2 with LoRA – now variance-safe and precision-adaptive."""

    def __init__(
        self,
        model_name: str = "gpt2",
        device: Optional[str] = None,
        learning_rate: float = 1e-4,
        lora_rank: int = 8,
        lora_alpha: Optional[int] = None,
        lora_dropout: float = 0.1,
        target_modules: Optional[Sequence[str]] = None,
        # --------------------------------------------------------------------------------------------------
        augmentation_prob: float = 0.3,
        gradient_accumulation_steps: int = 4,
        max_grad_norm: float = 1.0,
        warmup_steps: int = 100,
        validation_split: float = 0.1,
        use_amp: bool = True,
        amp_dtype: str = "auto",  # "auto" | "float16" | "bfloat16"
        max_weight_ratio: float = 100.0,  # clamp for per-sample weights (∞ disables)
    ) -> None:
        # Device & precision --------------------------------------------------------------
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.learning_rate = learning_rate
        self.lora_rank = lora_rank
        self.lora_alpha = lora_alpha if lora_alpha is not None else lora_rank * 2
        self.lora_dropout = lora_dropout
        self.target_modules = list(target_modules) if target_modules else ["c_attn", "c_proj"]

        # Training hyper-parameters -------------------------------------------------------
        self.augmentation_prob = augmentation_prob
        self.gradient_accumulation_steps = max(1, gradient_accumulation_steps)
        self.max_grad_norm = max_grad_norm
        self.warmup_steps = warmup_steps
        self.validation_split = validation_split
        self.max_weight_ratio = max(1.0, max_weight_ratio)  # ensure ≥ 1

        # AMP config ---------------------------------------------------------------------
        self.use_amp = use_amp and torch.cuda.is_available()
        self.amp_dtype = self._resolve_amp_dtype(amp_dtype)

        # Internal bookkeeping -----------------------------------------------------------
        self.total_epochs: int = 0
        self.best_val_loss: float = float("inf")

        self._load_model(model_name)
        logger.info(
            "GPT2LoRATrainer ready – device=%s | LR=%.2e | LoRA r=%d α=%d (dropout=%.2f) | AMP=%s(%s)",
            self.device,
            self.learning_rate,
            self.lora_rank,
            self.lora_alpha,
            self.lora_dropout,
            self.use_amp,
            str(self.amp_dtype).split(".")[-1],
        )

    # ----------------------------------------------------------------------------------
    #  AMP helpers
    # ----------------------------------------------------------------------------------
    def _resolve_amp_dtype(self, amp_dtype: str) -> torch.dtype:
        """Determine the autocast dtype based on user hint + hardware."""
        if not torch.cuda.is_available():
            return torch.float32  # CPU – no amp

        major_cc, _ = torch.cuda.get_device_capability()
        # Hardware capability checks ----------------------------------------------------
        supports_bf16 = major_cc >= 8  # Ampere (sm8x) introduced native bf16

        if amp_dtype.lower() in {"float16", "fp16"}:
            return torch.float16
        if amp_dtype.lower() in {"bfloat16", "bf16"}:
            if supports_bf16:
                return torch.bfloat16
            logger.warning("Requested bfloat16 but hardware lacks support – falling back to fp16.")
            return torch.float16
        # auto mode – choose best available
        if supports_bf16:
            return torch.bfloat16
        # For older GPUs (<7.0) disable AMP entirely – fp16 is slow / unsafe there
        if major_cc < 7:
            self.use_amp = False
            logger.info("Disabling AMP – GPU compute capability < 7.0 (no tensor cores).")
            return torch.float32
        return torch.float16

    # ----------------------------------------------------------------------------------
    #  Model + Optimiser initialisation
    # ----------------------------------------------------------------------------------
    def _load_model(self, model_name: str) -> None:
        try:
            from transformers import GPT2LMHeadModel, GPT2Tokenizer
            from peft import LoraConfig, TaskType, get_peft_model
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "transformers and peft are required. Install with: pip install transformers peft"
            ) from exc

        self.tokenizer = GPT2Tokenizer.from_pretrained(model_name)
        self.tokenizer.pad_token = self.tokenizer.eos_token  # ensure padding idx exists

        base_model = GPT2LMHeadModel.from_pretrained(model_name)
        lora_cfg = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            r=self.lora_rank,
            lora_alpha=self.lora_alpha,
            lora_dropout=self.lora_dropout,
            target_modules=self.target_modules,
            bias="none",
        )
        self.model = get_peft_model(base_model, lora_cfg).to(self.device)

        # Optimiser & schedulers will be initialised lazily in train()
        self.optimizer: Optional[torch.optim.Optimizer] = None
        self.lr_scheduler: Optional[torch.optim.lr_scheduler.LRScheduler] = None
        self.scaler: Optional[torch.cuda.amp.GradScaler] = torch.cuda.amp.GradScaler(enabled=self.use_amp)

    # ----------------------------------------------------------------------------------
    #  Data loading helpers
    # ----------------------------------------------------------------------------------
    @staticmethod
    def _read_json_examples(path: Path) -> List[Dict[str, Any]]:
        if not path.exists():
            raise FileNotFoundError(path)
        with path.open("r") as fh:
            data = json.load(fh)
        return data.get("examples", data if isinstance(data, list) else [])

    def load_training_data(
        self, *sources: Union[str, Tuple[str, float], Path, Tuple[Path, float]]
    ) -> Tuple[List[Dict[str, Any]], List[float]]:
        """Load training data from multiple JSON sources with optional per-source weights.

        Each *source* can be either a raw *path* (weight = 1.0) or a *(path, weight)* tuple.
        After loading, weights are *clamped* so that `max(weight) / min(weight) ≤ max_weight_ratio`.
        """
        all_examples: List[Dict[str, Any]] = []
        all_weights: List[float] = []

        for entry in sources:
            if isinstance(entry, (list, tuple)) and len(entry) == 2:
                path, weight = entry  # type: ignore[misc]
            else:
                path, weight = entry, 1.0
            p = Path(path)
            examples = self._read_json_examples(p)
            all_examples.extend(examples)
            all_weights.extend([float(weight)] * len(examples))
            logger.info("Loaded %d examples from %s (weight=%.2f)", len(examples), p, weight)

        # Variance-safe clamping ---------------------------------------------------------
        if all_weights:
            min_w = max(min(all_weights), 1e-8)
            max_allowed = min_w * self.max_weight_ratio
            if any(w > max_allowed for w in all_weights):
                all_weights = [min(w, max_allowed) for w in all_weights]
                logger.info(
                    "Clamped sample weights with ratio > %.2f× to %.2f (min=%.2f)",
                    self.max_weight_ratio,
                    max_allowed,
                    min_w,
                )
        logger.info("Total aggregated examples: %d", len(all_examples))
        return all_examples, all_weights

    # ----------------------------------------------------------------------------------
    #  Core training loop
    # ----------------------------------------------------------------------------------
    def train(
        self,
        examples: List[Dict[str, Any]],
        sample_weights: Optional[List[float]] = None,
        epochs: int = 3,
        batch_size: int = 8,
        checkpoint_dir: Union[str, Path] = "checkpoints",
    ) -> Dict[str, Any]:
        checkpoint_dir = Path(checkpoint_dir)
        checkpoint_dir.mkdir(parents=True, exist_ok=True)

        # Dataset & split ---------------------------------------------------------------
        full_ds = AgentDecisionDataset(
            examples,
            self.tokenizer,
            augmentation_prob=self.augmentation_prob,
            sample_weights=sample_weights,
        )
        if 0.0 < self.validation_split < 1.0:
            val_size = int(len(full_ds) * self.validation_split)
            train_size = len(full_ds) - val_size
            train_ds, val_ds = random_split(
                full_ds, [train_size, val_size], generator=torch.Generator().manual_seed(42)
            )
        else:
            train_ds, val_ds = full_ds, None
            val_size = 0
        logger.info("Train/Val split: %d / %d", len(train_ds), val_size)

        # Sampler ----------------------------------------------------------------------
        if sample_weights is not None:
            if isinstance(train_ds, Subset):
                subset_weights = [sample_weights[idx] for idx in train_ds.indices]
                sampler = WeightedRandomSampler(subset_weights, num_samples=len(train_ds), replacement=True)
            else:
                weights = train_ds.get_weights() if hasattr(train_ds, "get_weights") else sample_weights
                sampler = WeightedRandomSampler(weights, num_samples=len(train_ds), replacement=True)
            shuffle = False
        else:
            sampler, shuffle = None, True

        train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=shuffle, sampler=sampler)
        val_loader = DataLoader(val_ds, batch_size=batch_size) if val_ds is not None else None

        # Optimiser & scheduler ---------------------------------------------------------
        total_steps = math.ceil(len(train_loader) / self.gradient_accumulation_steps) * epochs
        if self.optimizer is None:
            self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.learning_rate)
        if self.lr_scheduler is None:
            from transformers import get_cosine_schedule_with_warmup

            self.lr_scheduler = get_cosine_schedule_with_warmup(
                self.optimizer,
                num_warmup_steps=self.warmup_steps,
                num_training_steps=total_steps,
            )

        logger.info(
            "Training: %d epochs | %d optimisation steps (batch=%d, accum=%d)",
            epochs,
            total_steps,
            batch_size,
            self.gradient_accumulation_steps,
        )

        self.model.train()
        stats: List[Dict[str, float]] = []
        global_step = 0

        for epoch in range(1, epochs + 1):
            running_loss = 0.0
            for step, batch in enumerate(train_loader, start=1):
                batch = {k: v.to(self.device) for k, v in batch.items()}
                with torch.cuda.amp.autocast(device_type="cuda", dtype=self.amp_dtype, enabled=self.use_amp):
                    outputs = self.model(**batch)
                    loss = outputs.loss / self.gradient_accumulation_steps
                # Backward (scaled if AMP)
                self.scaler.scale(loss).backward()

                if step % self.gradient_accumulation_steps == 0:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad(set_to_none=True)
                    self.lr_scheduler.step()
                    global_step += 1
                running_loss += loss.item() * self.gradient_accumulation_steps

            avg_train_loss = running_loss / len(train_loader)
            logger.info("Epoch %d/%d – train-loss: %.4f", epoch, epochs, avg_train_loss)

            # ---------------- Validation ----------------
            val_loss = avg_train_loss
            if val_loader is not None:
                val_loss = self._evaluate(val_loader)
                logger.info("                 val-loss: %.4f", val_loss)

            # --------------- Checkpointing ---------------
            ckpt_path = checkpoint_dir / f"epoch_{epoch}.pt"
            self.save_checkpoint(ckpt_path)
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                self.save_checkpoint(checkpoint_dir / "best.pt")
            stats.append({"epoch": epoch, "train_loss": avg_train_loss, "val_loss": val_loss})
            self.total_epochs += 1

        self.save_checkpoint(checkpoint_dir / "last.pt")
        return {"history": stats, "best_val_loss": self.best_val_loss}

    # ----------------------------------------------------------------------------------
    def _evaluate(self, loader: DataLoader) -> float:
        self.model.eval()
        total_loss = 0.0
        with torch.no_grad():
            for batch in loader:
                batch = {k: v.to(self.device) for k, v in batch.items()}
                with torch.cuda.amp.autocast(device_type="cuda", dtype=self.amp_dtype, enabled=self.use_amp):
                    loss = self.model(**batch).loss
                total_loss += loss.item()
        self.model.train()
        return total_loss / max(len(loader), 1)

    # ----------------------------------------------------------------------------------
    #  Convenience wrappers
    # ----------------------------------------------------------------------------------
    def train_epoch(self, examples: List[Dict[str, Any]], batch_size: int = 4) -> Tuple[float, float]:
        stats = self.train(examples, epochs=1, batch_size=batch_size)
        last = stats["history"][-1]
        acc = max(0.0, min(1.0, 1.0 - last["train_loss"] / 10.0))
        return last["train_loss"], acc

    # ----------------------------------------------------------------------------------
    def save_checkpoint(self, path: Union[str, Path]) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.model.save_pretrained(str(path))  # LoRA weights only
        torch.save(
            {
                "total_epochs": self.total_epochs,
                "best_val_loss": self.best_val_loss,
                "optimizer_state": self.optimizer.state_dict() if self.optimizer else None,
                "scheduler_state": self.lr_scheduler.state_dict() if self.lr_scheduler else None,
            },
            path.with_suffix(".trainer_state.pt"),
        )

    def load_checkpoint(self, path: Union[str, Path]) -> None:
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(path)
        try:
            from peft import PeftModel
        except ImportError as exc:
            raise ImportError("peft must be installed to load LoRA checkpoints") from exc
        self.model = PeftModel.from_pretrained(self.model, str(path)).to(self.device)
        state_path = path.with_suffix(".trainer_state.pt")
        if state_path.exists():
            state = torch.load(state_path, map_location=self.device)
            self.total_epochs = state.get("total_epochs", 0)
            self.best_val_loss = state.get("best_val_loss", float("inf"))
            if self.optimizer and state.get("optimizer_state"):
                self.optimizer.load_state_dict(state["optimizer_state"])
            if self.lr_scheduler and state.get("scheduler_state"):
                self.lr_scheduler.load_state_dict(state["scheduler_state"])
        logger.info("Checkpoint loaded from %s", path)

    # ----------------------------------------------------------------------------------
    def generate(self, prompt: str, max_length: int = 50, temperature: float = 0.7) -> str:  # noqa: D401
        self.model.eval()
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        with torch.no_grad(), torch.cuda.amp.autocast(device_type="cuda", dtype=self.amp_dtype, enabled=self.use_amp):
            output_ids = self.model.generate(
                **inputs,
                max_length=max_length,
                temperature=temperature,
                do_sample=True,
                num_return_sequences=1,
                pad_token_id=self.tokenizer.eos_token_id,
            )[0]
        return self.tokenizer.decode(output_ids, skip_special_tokens=True)
