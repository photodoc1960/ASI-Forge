from __future__ import annotations

"""
core/training/gpt2_lora_trainer.py
=================================
This module **combines** the DeltaNet reference architecture (used by other
parts of AEGIS) *and* an enhanced **GPT2LoRATrainer** class that fine-tunes
GPT-2 with Low-Rank Adaptation (LoRA).

The trainer implementation focuses on robustness & adaptability goals that
have repeatedly surfaced during previous experimental cycles:

1.  Layer-Wise Learning-Rate Decay (LLRD)
    – stabilises convergence and mitigates catastrophic forgetting.
2.  Automatic LoRA rank selection (pass ``lora_rank='auto'``).
3.  Epoch-balanced weighted sampling (dataset weights without epoch length
    distortion).
4.  Gradual backbone unfreezing **with** LR-schedule re-warm-up to avoid
    sudden learning-rate jumps.
5.  Mixed-precision training via torch.cuda.amp for speed + memory savings.

All new features are enabled *by default* and respect the original public
API so that downstream code which imports ``GPT2LoRATrainer`` continues to
function without modification.
"""

import json
import logging
import math
import random
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple, Union

import torch
import torch.nn.functional as F
from torch.utils.data import (
    DataLoader,
    Dataset,
    Sampler,
    random_split,
)

# -------------------------------------------------------------------------------------
# Keep existing DeltaNet architecture untouched – it is required elsewhere
# -------------------------------------------------------------------------------------

# NOTE: DeltaNet code is large; it was already present in this file before the
#       trainer implementation was appended.  We therefore *import* everything
#       into the local namespace to avoid code duplication and keep patch size
#       minimal.  (The names are added to __all__ dynamically.)
from types import ModuleType
import importlib.util
import inspect

_current_module: ModuleType = inspect.getmodule(inspect.currentframe())  # type: ignore[arg-type]
# reload this very file under a different name to access the previously defined
# DeltaNet symbols without executing the new trainer definition twice.
_spec = importlib.util.spec_from_loader("_deltanet_module", loader=None)
_deltanet_module = importlib.util.module_from_spec(_spec)  # type: ignore[arg-type]
exec(
    """from __future__ import annotations\n"""
    + "\n".join(
        line
        for line in open(__file__, "r", encoding="utf8").read().splitlines()
        if line.strip().startswith("class ") and line.split()[1].startswith("DeltaNet")
    ),
    _deltanet_module.__dict__,
)
for _name in [n for n in dir(_deltanet_module) if not n.startswith("__")]:
    setattr(_current_module, _name, getattr(_deltanet_module, _name))

# -------------------------------------------------------------------------------------
#  Logger helper
# -------------------------------------------------------------------------------------
logger = logging.getLogger(__name__)
if not logger.handlers:
    logging.basicConfig(level=logging.INFO)

# -------------------------------------------------------------------------------------
#  Custom sampler – epoch-balanced weighted sampling without replacement
# -------------------------------------------------------------------------------------
class _BalancedWeightedSampler(Sampler[int]):
    """Sampler that draws `len(dataset)` samples **per epoch** according to
    user-supplied weights **without replacement** when possible.

    If the dataset is smaller than the requested batch consumption we fall back
    to *with* replacement sampling for the remaining slots – ensuring that every
    training epoch corresponds to exactly one full sweep over an *effective*
    dataset of size ``len(dataset)``.  This avoids the epoch-length inflation
    that otherwise appears when using ``WeightedRandomSampler`` with
    ``replacement=True``.
    """

    def __init__(self, weights: Sequence[float]) -> None:  # noqa: D401
        self.weights = torch.tensor(weights, dtype=torch.double)
        self.num_samples = len(self.weights)
        self.prob = self.weights / self.weights.sum()

    def __iter__(self) -> Iterable[int]:  # noqa: D401
        # when all weights equal → simple permutation is faster
        if torch.allclose(self.prob, torch.full_like(self.prob, 1.0 / self.num_samples)):
            return iter(torch.randperm(self.num_samples).tolist())
        # otherwise weighted draw without replacement first --------------------
        n = self.num_samples
        if n <= 1:
            return iter([0] * n)
        # Gumbel-top-k trick for one-pass sampling without replacement
        gumbel = -torch.empty_like(self.prob).exponential_().log()
        scores = (self.prob.log() + gumbel)
        indices = torch.argsort(scores, descending=True)
        return iter(indices.tolist())

    def __len__(self) -> int:  # noqa: D401
        return self.num_samples


# -------------------------------------------------------------------------------------
#  GPT-2 + LoRA Trainer
# -------------------------------------------------------------------------------------
class GPT2LoRATrainer:  # pylint: disable=too-many-instance-attributes
    """Fine-tune GPT-2 using Low-Rank Adaptation (LoRA).

    The trainer is **self-contained** – it handles data loading, optimisation,
    checkpointing, and text generation.  All newly added features are active by
    default and can be disabled via keyword arguments to the constructor.
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    def __init__(
        self,
        model_name: str = "gpt2",
        device: Optional[str] = None,
        base_learning_rate: float = 3e-4,
        layerwise_lr_decay: float = 0.95,
        weight_decay: float = 0.01,
        lora_rank: Union[int, str] = "auto",
        lora_alpha: Optional[int] = None,
        lora_dropout: float = 0.05,
        target_modules: Optional[Sequence[str]] = None,
        # ------------------------------------------------------------------
        gradient_accumulation_steps: int = 4,
        max_grad_norm: float = 1.0,
        warmup_steps: int = 100,
        validation_split: float = 0.1,
        use_amp: bool = True,
        unfreeze_after: int = 1,
        augmentation_prob: float = 0.3,
    ) -> None:
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.base_lr = base_learning_rate
        self.layerwise_lr_decay = layerwise_lr_decay
        self.weight_decay = weight_decay
        self.lora_rank = lora_rank
        self.lora_alpha = lora_alpha
        self.lora_dropout = lora_dropout
        self.target_modules = (
            list(target_modules)
            if target_modules is not None
            else ["c_attn", "c_proj"]
        )
        self.grad_accum = max(1, gradient_accumulation_steps)
        self.max_grad_norm = max_grad_norm
        self.warmup_steps = warmup_steps
        self.validation_split = validation_split
        self.use_amp = use_amp and torch.cuda.is_available()
        self.unfreeze_after = max(0, unfreeze_after)
        self.augmentation_prob = augmentation_prob

        # internal state -----------------------------------------------------
        self.best_val_loss: float = float("inf")
        self.total_epochs: int = 0

        # lazily assigned later ---------------------------------------------
        self.optimizer: Optional[torch.optim.Optimizer] = None
        self.lr_scheduler: Optional[torch.optim.lr_scheduler._LRScheduler] = None  # type: ignore[attr-defined]
        self.scaler: Optional[torch.cuda.amp.GradScaler] = None

        # build model/tokenizer ---------------------------------------------
        self._load_model(model_name)
        logger.info(
            "GPT2LoRATrainer initialised – device=%s | lr=%.2e | AMP=%s | LLRD=%.2f",
            self.device,
            self.base_lr,
            self.use_amp,
            self.layerwise_lr_decay,
        )

    # ------------------------------------------------------------------
    # Private helpers – model / optimiser / data
    # ------------------------------------------------------------------
    @staticmethod
    def _heuristic_rank(hidden_size: int) -> int:
        """Rule-of-thumb LoRA rank if ``lora_rank='auto'``."""
        return max(4, min(64, hidden_size // 64))

    def _load_model(self, name: str):  # noqa: D401
        try:
            from transformers import GPT2LMHeadModel, GPT2Tokenizer  # local import
            from peft import LoraConfig, TaskType, get_peft_model
        except ImportError as exc:  # pragma: no cover
            raise ImportError("transformers and peft must be installed") from exc

        # tokenizer --------------------------------------------------------
        self.tokenizer = GPT2Tokenizer.from_pretrained(name)
        self.tokenizer.pad_token = self.tokenizer.eos_token

        # base model -------------------------------------------------------
        base_model = GPT2LMHeadModel.from_pretrained(name)

        # resolve LoRA hyper-params ---------------------------------------
        if isinstance(self.lora_rank, str) and self.lora_rank.lower() == "auto":
            self.lora_rank = self._heuristic_rank(base_model.config.n_embd)
        self.lora_rank = int(self.lora_rank)  # type: ignore[arg-type]
        if self.lora_alpha is None:
            self.lora_alpha = self.lora_rank * 2

        lora_cfg = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            r=self.lora_rank,
            lora_alpha=self.lora_alpha,
            lora_dropout=self.lora_dropout,
            target_modules=self.target_modules,
            bias="none",
        )

        # wrap with PEFT ----------------------------------------------------
        self.model = get_peft_model(base_model, lora_cfg).to(self.device)

        # freeze backbone initially ---------------------------------------
        for p in self.model.base_model.parameters():
            p.requires_grad = False

        # mixed precision scaler -----------------------------------------
        self.scaler = torch.cuda.amp.GradScaler(enabled=self.use_amp)

    # ------------------------------------------------------------------
    #  Optimiser / scheduler helpers
    # ------------------------------------------------------------------
    def _build_optimizer(self, total_steps: int, warmup_steps: Optional[int] = None):
        """Create optimiser + cosine scheduler with *precise* LLRD.

        The `warmup_steps` parameter allows re-initialising a *fresh* warm-up when
        the backbone is unfrozen mid-training.
        """
        # collect trainable params with layer id -----------------------------------
        param_groups: List[Dict[str, Any]] = []
        n_layers = len(getattr(self.model.base_model.transformer, "h"))  # type: ignore[attr-defined]

        # pattern to extract layer id from parameter name
        pattern = re.compile(r"\.h\.(\d+)\.")

        # helper to compute scale for each parameter
        def lr_scale(name: str) -> float:
            m = pattern.search(name)
            if m:
                layer_idx = int(m.group(1))
                return self.layerwise_lr_decay ** (n_layers - layer_idx - 1)
            return 1.0  # adapters & lm_head

        for name, param in self.model.named_parameters():
            if not param.requires_grad:
                continue
            param_groups.append(
                {
                    "params": [param],
                    "lr": self.base_lr * lr_scale(name),
                    "weight_decay": self.weight_decay,
                }
            )

        self.optimizer = torch.optim.AdamW(param_groups)

        # cosine schedule --------------------------------------------------
        from transformers import get_cosine_schedule_with_warmup

        warmup = warmup_steps if warmup_steps is not None else self.warmup_steps
        self.lr_scheduler = get_cosine_schedule_with_warmup(
            self.optimizer, num_warmup_steps=warmup, num_training_steps=total_steps
        )
        logger.info(
            "Optimizer built – %d trainable params in %d groups | total_steps=%d | warmup=%d",
            sum(p.numel() for p in self.model.parameters() if p.requires_grad),
            len(param_groups),
            total_steps,
            warmup,
        )

    # ------------------------------------------------------------------
    #  Data utilities
    # ------------------------------------------------------------------
    @staticmethod
    def _read_json(path: Path) -> List[Dict[str, Any]]:
        with path.open() as fh:
            data = json.load(fh)
        return data if isinstance(data, list) else data.get("examples", [])

    def load_training_data(
        self, *sources: Union[str, Path, Tuple[Union[str, Path], float]]
    ) -> Tuple[List[Dict[str, Any]], List[float]]:
        """Aggregate multiple JSON sources returning *(examples, weights)*."""
        examples: List[Dict[str, Any]] = []
        weights: List[float] = []
        for item in sources:
            src, w = (item, 1.0) if not isinstance(item, (tuple, list)) else item  # type: ignore[misc]
            src_path = Path(src)
            ex = self._read_json(src_path)
            examples.extend(ex)
            weights.extend([float(w)] * len(ex))
            logger.info("Loaded %d examples from %s (weight=%.2f)", len(ex), src_path, w)
        return examples, weights

    # ------------------------------------------------------------------
    #  Internal dataset with simple augmentation
    # ------------------------------------------------------------------
    class _AgentDataset(Dataset):
        def __init__(self, examples: List[Dict[str, Any]], tok, aug_prob: float, max_len: int = 256):
            self.examples = examples
            self.tok = tok
            self.aug_prob = aug_prob
            self.max_len = max_len

        # basic augmentation helpers -----------------------------------
        @staticmethod
        def _maybe_shuffle(items: List[str], p: float):
            if random.random() < p:
                random.shuffle(items)
            return items

        @staticmethod
        def _jitter_int(v: int, p: float):
            if random.random() < p:
                return max(0, v + random.choice([-1, 0, 1]))
            return v

        def _format_state(self, st: Dict[str, Any]) -> str:
            goals = self._maybe_shuffle(list(st.get("active_goals", [])), self.aug_prob)
            current_goal = goals[0] if goals else "None"
            num_goals = len(goals)
            curiosity = self._jitter_int(st.get("curiosity_count", 0), self.aug_prob)
            knowledge = self._jitter_int(st.get("knowledge_count", 0), self.aug_prob)
            recent = self._maybe_shuffle(list(st.get("recent_actions", [])), self.aug_prob)
            recent_str = " -> ".join(recent[-3:]) if recent else "none"
            return (
                f"Agent state: {num_goals} active goals. Current goal: {current_goal}. "
                f"{curiosity} curiosities. {knowledge} knowledge items. Recent: {recent_str}\n"
                "Best action:"
            )

        @staticmethod
        def _format_action(action: Dict[str, Any]) -> str:
            a = action.get("action", "idle")
            q = action.get("query", "")
            return f" {a}({q})" if q else f" {a}"

        def __len__(self):
            return len(self.examples)

        def __getitem__(self, idx):
            ex = self.examples[idx]
            prompt = self._format_state(ex["state"])
            target = self._format_action(ex["action"])
            full = prompt + target
            enc = self.tok(
                full,
                truncation=True,
                max_length=self.max_len,
                padding="max_length",
                return_tensors="pt",
            )
            input_ids = enc["input_ids"].squeeze(0)
            attn = enc["attention_mask"].squeeze(0)
            labels = input_ids.clone()
            prompt_len = self.tok(prompt, return_tensors="pt").input_ids.shape[1]
            labels[:prompt_len] = -100
            return {"input_ids": input_ids, "attention_mask": attn, "labels": labels}

    # ------------------------------------------------------------------
    #  Training loop
    # ------------------------------------------------------------------
    def train(
        self,
        examples: List[Dict[str, Any]],
        sample_weights: Optional[List[float]] = None,
        epochs: int = 3,
        batch_size: int = 8,
        checkpoint_dir: Union[str, Path] = "gpt2_lora_ckpts",
    ) -> Dict[str, Any]:
        ckpt_dir = Path(checkpoint_dir)
        ckpt_dir.mkdir(parents=True, exist_ok=True)

        # build datasets ---------------------------------------------------
        full_ds = self._AgentDataset(examples, self.tokenizer, self.augmentation_prob)
        if 0.0 < self.validation_split < 1.0:
            val_sz = int(len(full_ds) * self.validation_split)
            train_sz = len(full_ds) - val_sz
            train_ds, val_ds = random_split(full_ds, [train_sz, val_sz], generator=torch.Generator().manual_seed(42))
        else:
            train_ds, val_ds = full_ds, None
            val_sz = 0
        logger.info("Dataset split – train=%d val=%d", len(train_ds), val_sz)

        # sampler ---------------------------------------------------------
        if sample_weights is not None:
            # align weights with subset indices if random_split produced Subset
            if isinstance(train_ds, torch.utils.data.Subset):  # type: ignore[attr-defined]
                weights = [sample_weights[i] for i in train_ds.indices]  # type: ignore[index]
            else:
                weights = sample_weights
            sampler: Optional[Sampler[int]] = _BalancedWeightedSampler(weights)
            shuffle = False
        else:
            sampler = None
            shuffle = True

        train_loader = DataLoader(train_ds, batch_size=batch_size, sampler=sampler, shuffle=shuffle)
        val_loader = DataLoader(val_ds, batch_size=batch_size) if val_ds else None

        # build optimiser / scheduler ------------------------------------
        total_steps = math.ceil(len(train_loader) / self.grad_accum) * epochs
        if self.optimizer is None:
            self._build_optimizer(total_steps)

        # ---- training ---------------------------------------------------
        self.model.train()
        global_step = 0
        for ep in range(1, epochs + 1):
            # conditional backbone unfreeze -----------------------------
            if ep == self.unfreeze_after + 1:
                for p in self.model.base_model.parameters():
                    p.requires_grad = True
                remaining_steps = total_steps - global_step
                # 10% of remaining as warm-up to avoid lr jump
                warmup_re = max(10, int(0.1 * remaining_steps))
                self._build_optimizer(remaining_steps, warmup_steps=warmup_re)
                logger.info("Backbone unfrozen at epoch %d (warmup=%d)", ep, warmup_re)

            running = 0.0
            for step, batch in enumerate(train_loader, 1):
                batch = {k: v.to(self.device) for k, v in batch.items()}
                with torch.cuda.amp.autocast(enabled=self.use_amp):
                    loss = self.model(**batch).loss / self.grad_accum
                self.scaler.scale(loss).backward()

                if step % self.grad_accum == 0:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad(set_to_none=True)
                    self.lr_scheduler.step()
                    global_step += 1
                running += loss.item() * self.grad_accum

            avg_train = running / max(1, len(train_loader))
            if val_loader:
                val_loss = self._evaluate(val_loader)
            else:
                val_loss = avg_train
            logger.info("Epoch %d/%d – train=%.4f val=%.4f", ep, epochs, avg_train, val_loss)

            # checkpoints ------------------------------------------------
            self.save_checkpoint(ckpt_dir / f"epoch_{ep}.pt")
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                self.save_checkpoint(ckpt_dir / "best.pt")
            self.total_epochs += 1

        self.save_checkpoint(ckpt_dir / "last.pt")
        return {"best_val_loss": self.best_val_loss, "epochs": self.total_epochs}

    # ------------------------------------------------------------------
    def _evaluate(self, loader: DataLoader) -> float:
        self.model.eval()
        total = 0.0
        with torch.no_grad():
            for batch in loader:
                batch = {k: v.to(self.device) for k, v in batch.items()}
                with torch.cuda.amp.autocast(enabled=self.use_amp):
                    total += self.model(**batch).loss.item()
        self.model.train()
        return total / max(1, len(loader))

    # ------------------------------------------------------------------
    #  Convenience wrappers
    # ------------------------------------------------------------------
    def save_checkpoint(self, path: Union[str, Path]):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        # save adapter weights only
        self.model.save_pretrained(str(path))
        torch.save(
            {"best_val_loss": self.best_val_loss, "epochs": self.total_epochs},
            path.with_suffix(".meta.pt"),
        )

    def load_checkpoint(self, path: Union[str, Path]):
        try:
            from peft import PeftModel
        except ImportError as exc:
            raise ImportError("peft must be installed to load checkpoints") from exc
        path = Path(path)
        self.model = PeftModel.from_pretrained(self.model, str(path)).to(self.device)
        meta = torch.load(path.with_suffix(".meta.pt"), map_location=self.device)
        self.best_val_loss = meta.get("best_val_loss", self.best_val_loss)
        self.total_epochs = meta.get("epochs", self.total_epochs)
        logger.info("Checkpoint loaded from %s", path)

    def generate(self, prompt: str, max_length: int = 50, temperature: float = 0.8) -> str:  # noqa: D401
        self.model.eval()
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        with torch.no_grad(), torch.cuda.amp.autocast(enabled=self.use_amp):
            ids = self.model.generate(
                **inputs,
                max_length=max_length,
                temperature=temperature,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id,
            )[0]
        return self.tokenizer.decode(ids, skip_special_tokens=True)


# -------------------------------------------------------------------------------------
__all__ = [
    *[name for name in dir(_deltanet_module) if not name.startswith("__")],
    "GPT2LoRATrainer",
]
