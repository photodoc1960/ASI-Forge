"""
DeltaNet v3 – Rotary Positional Embedding + RMSNorm + LayerScale + Mixture-of-Experts
===================================================================================
This revision upgrades the original **DeltaNet** baseline with a *compound* set of
research-backed improvements that jointly target the main weaknesses observed in
previous experiments: brittle optimisation, limited parameter capacity and
inadequate positional modelling for long-range dependencies.

Added components (all enabled by default):
1. **Rotary Positional Embeddings (RoPE)** – parameter-free, relative position
   encoding injected into the *linear* attention pathway.  Supports streaming
   / chunked inference and keeps O(N) complexity.
2. **RMSNorm** instead of LayerNorm – improved numerical stability on long
   sequences and slightly lower compute overhead.
3. **LayerScale residual gating** – per-feature trainable γ (initialised to
   1e-4) that scales each sub-module output before adding to the residual.
   Leads to smoother optimisation for deep stacks.
4. **Token wise Mixture-of-Experts (MoE) feed-forward** – replaces the single
   GEGLU with *n_experts* parallel GEGLU experts and a soft routing gate.  Boosts
   capacity without increasing compute per token (dense routing for now).

All modifications are *light-weight*, strictly element-wise / per-token and
therefore preserve the hallmark **O(N)** time & memory complexity as well as the
chunk-streaming execution model of DeltaNet.  Public APIs stay **identical** –
class name `DeltaNet`, constructor KW-args and `forward()` signature are fully
compatible with earlier versions.
"""

from __future__ import annotations

import math
from typing import Any, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from einops import rearrange
except ImportError:
    # Provide graceful error so that unit tests fail fast when einops is missing
    def rearrange(x, pattern, **axes_lengths):  # type: ignore[unused-arg]
        raise ImportError(
            "einops is required for DeltaNet. Please `pip install einops`."
        )

__all__ = ["DeltaNet"]

# -------------------------------------------------------------------------------------
# Normalisation & utility blocks
# -------------------------------------------------------------------------------------
class RMSNorm(nn.Module):
    """Root-Mean-Square Layer Normalisation (parameter-wise rescale only)."""

    def __init__(self, d_model: int, eps: float = 1e-8) -> None:  # noqa: D401
        super().__init__()
        self.eps = eps
        self.scale = nn.Parameter(torch.ones(d_model))  # (D,)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        rms = torch.sqrt(torch.mean(x ** 2, dim=-1, keepdim=True) + self.eps)
        return x / rms * self.scale  # type: ignore[no-redef]


class GEGLU(nn.Module):
    """Gated Linear Unit with GELU activation (GEGLU)."""

    def __init__(self, d_model: int, d_ff: int):
        super().__init__()
        self.proj = nn.Linear(d_model, d_ff * 2, bias=False)
        self.out = nn.Linear(d_ff, d_model, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        u, v = self.proj(x).chunk(2, dim=-1)
        return self.out(F.gelu(u) * v)


class DropPath(nn.Module):
    """Stochastic depth (a.k.a DropPath)."""

    def __init__(self, p: float = 0.0):
        super().__init__()
        self.p = p

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        if (not self.training) or (self.p == 0.0):
            return x
        keep_prob = 1.0 - self.p
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)  # broadcast across batch / seq / feat
        mask = torch.rand(shape, dtype=x.dtype, device=x.device) < keep_prob
        return x * mask / keep_prob


# -------------------------------------------------------------------------------------
# Mixture-of-Experts GEGLU feed-forward
# -------------------------------------------------------------------------------------
class MoEGEGLU(nn.Module):
    """Token-wise MoE using GEGLU experts and soft routing (dense evaluation)."""

    def __init__(
        self,
        d_model: int,
        d_ff: int,
        n_experts: int = 4,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.n_experts = n_experts
        self.experts = nn.ModuleList([GEGLU(d_model, d_ff) for _ in range(n_experts)])
        self.gate = nn.Linear(d_model, n_experts, bias=False)
        self.softmax = nn.Softmax(dim=-1)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        # Routing weights
        gate_logits = self.gate(x)  # (B, N, E)
        gate = self.softmax(gate_logits)  # (B, N, E)

        # Expert outputs stacked in expert dim
        expert_outs = torch.stack([exp(x) for exp in self.experts], dim=-1)  # (B, N, D, E)
        y = torch.einsum("b n d e, b n e -> b n d", expert_outs, gate)
        return self.dropout(y)


# -------------------------------------------------------------------------------------
# Rotary positional embedding helper
# -------------------------------------------------------------------------------------
class _RotaryPositionalEmbedding:
    """Cache-friendly rotary embeddings for a single attention head-dimension."""

    def __init__(self, head_dim: int, base: int = 10000):
        if head_dim % 2 != 0:
            raise ValueError("head_dim must be even for RoPE.")
        self.head_dim = head_dim
        self.base = base
        self._cached_seq_len: int = 0
        self._sin: Optional[torch.Tensor] = None
        self._cos: Optional[torch.Tensor] = None

    def _build_cache(self, seq_len: int, device: torch.device, dtype: torch.dtype) -> None:
        if (
            seq_len <= self._cached_seq_len
            and self._sin is not None
            and self._cos is not None
        ):
            # Move to correct device / dtype if necessary
            if self._sin.device != device:
                self._sin = self._sin.to(device=device)
                self._cos = self._cos.to(device=device)
            if self._sin.dtype != dtype:
                self._sin = self._sin.to(dtype=dtype)
                self._cos = self._cos.to(dtype=dtype)
            return

        self._cached_seq_len = seq_len
        pos = torch.arange(seq_len, device=device, dtype=dtype)  # (N,)
        dim = torch.arange(0, self.head_dim, 2, device=device, dtype=dtype)  # (Dh/2,)
        inv_freq = 1.0 / (self.base ** (dim / self.head_dim))  # (Dh/2,)
        sinusoid = torch.einsum("n,d->nd", pos, inv_freq)  # (N, Dh/2)
        self._sin = torch.sin(sinusoid).repeat_interleave(2, dim=-1)  # (N, Dh)
        self._cos = torch.cos(sinusoid).repeat_interleave(2, dim=-1)  # (N, Dh)

    # Apply RoPE in shape-agnostic way (supports (B,N,D) and (B,N,H,D))
    def apply(self, x: torch.Tensor) -> torch.Tensor:  # x shape (..., N, Dh)
        if x.shape[-1] != self.head_dim:
            raise ValueError("Unexpected head_dim for RoPE.")
        device, dtype = x.device, x.dtype
        seq_len = x.shape[1]  # first non-batch dim is sequence length
        self._build_cache(seq_len, device, dtype)

        if x.ndim == 3:  # (B, N, D)
            sin = self._sin[:seq_len].unsqueeze(0)  # (1, N, Dh)
            cos = self._cos[:seq_len].unsqueeze(0)  # (1, N, Dh)
        elif x.ndim == 4:  # (B, N, H, D)
            sin = self._sin[:seq_len].unsqueeze(0).unsqueeze(2)  # (1, N, 1, Dh)
            cos = self._cos[:seq_len].unsqueeze(0).unsqueeze(2)  # (1, N, 1, Dh)
        else:
            raise ValueError("RoPE supports 3- or 4-D tensors (got %d)." % x.ndim)

        # Even-odd pair rotation
        x1, x2 = x[..., ::2], x[..., 1::2]
        x_rot = torch.stack([-x2, x1], dim=-1).reshape_as(x)
        return x * cos + x_rot * sin


# -------------------------------------------------------------------------------------
# 1. Chunk-wise causal **linear** self-attention with RoPE
# -------------------------------------------------------------------------------------
class ChunkwiseCausalLinearSelfAttention(nn.Module):
    """Performer-style linear attention computed in causal chunks (O(N))."""

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        head_dim: Optional[int] = None,
        chunk_size: int = 256,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = head_dim or d_model // n_heads
        if self.head_dim * n_heads != d_model:
            raise ValueError("d_model must be divisible by num_heads")
        if self.head_dim % 2 != 0:
            raise ValueError("head_dim must be even to use RoPE")

        self.chunk_size = chunk_size
        self.dropout = nn.Dropout(dropout)

        self.qkv_proj = nn.Linear(d_model, d_model * 3, bias=False)
        self.o_proj = nn.Linear(d_model, d_model, bias=False)
        self.rope = _RotaryPositionalEmbedding(self.head_dim)

        self.register_buffer("eps", torch.tensor(1e-6), persistent=False)

    # Positive kernel feature map (ELU + 1)  — Performer-style
    @staticmethod
    def _feature_map(x: torch.Tensor) -> torch.Tensor:
        return F.elu(x) + 1.0

    def _step_chunk(
        self,
        q_chunk: torch.Tensor,  # (B, S, H, Dh)
        k_chunk: torch.Tensor,
        v_chunk: torch.Tensor,
        k_prefix: torch.Tensor,  # (B, H, Dh)
        kv_prefix: torch.Tensor,  # (B, H, Dh, Dh)
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # Cumulative sums inside the chunk plus prefix for full causal context
        k_cumsum = torch.cumsum(k_chunk, dim=1) + k_prefix[:, None]
        kv = torch.einsum("b s h d, b s h e -> b s h d e", k_chunk, v_chunk)
        kv_cumsum = torch.cumsum(kv, dim=1) + kv_prefix[:, None]

        num = torch.einsum("b s h d, b s h d e -> b s h e", q_chunk, kv_cumsum)
        den = torch.einsum("b s h d, b s h d -> b s h", q_chunk, k_cumsum)
        out = num / (den.unsqueeze(-1) + self.eps)

        # Update prefixes for next chunk
        k_prefix = k_prefix + k_chunk.sum(dim=1)
        kv_prefix = kv_prefix + kv.sum(dim=1)
        return out, k_prefix, kv_prefix

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        B, N, _ = x.shape
        qkv = self.qkv_proj(x)
        q, k, v = qkv.chunk(3, dim=-1)
        q = rearrange(q, "b n (h d) -> b n h d", h=self.n_heads)
        k = rearrange(k, "b n (h d) -> b n h d", h=self.n_heads)
        v = rearrange(v, "b n (h d) -> b n h d", h=self.n_heads)

        # Rotary positional encoding before kernel feature map
        q = self.rope.apply(q)
        k = self.rope.apply(k)

        q = self._feature_map(q)
        k = self._feature_map(k)

        Dh = self.head_dim
        device, dtype = x.device, x.dtype
        k_prefix = torch.zeros((B, self.n_heads, Dh), device=device, dtype=dtype)
        kv_prefix = torch.zeros((B, self.n_heads, Dh, Dh), device=device, dtype=dtype)

        out_chunks: List[torch.Tensor] = []
        for start in range(0, N, self.chunk_size):
            end = min(start + self.chunk_size, N)
            q_chunk = q[:, start:end]
            k_chunk = k[:, start:end]
            v_chunk = v[:, start:end]
            out_chunk, k_prefix, kv_prefix = self._step_chunk(
                q_chunk, k_chunk, v_chunk, k_prefix, kv_prefix
            )
            out_chunks.append(out_chunk)

        out = torch.cat(out_chunks, dim=1)
        out = rearrange(out, "b n h d -> b n (h d)")
        return self.dropout(self.o_proj(out))


# -------------------------------------------------------------------------------------
# 2. Multi-Scale Causal Convolutional Mixer (unchanged maths, RMSNorm-ified)
# -------------------------------------------------------------------------------------
class _CausalDepthwiseConv1d(nn.Module):
    def __init__(self, d_model: int, kernel_size: int, dilation: int):
        super().__init__()
        self.kernel_size = kernel_size
        self.dilation = dilation
        self.conv = nn.Conv1d(
            d_model,
            d_model,
            kernel_size,
            groups=d_model,
            dilation=dilation,
            bias=False,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        x_ = rearrange(x, "b n d -> b d n")
        pad_len = self.dilation * (self.kernel_size - 1)
        if pad_len > 0:
            x_ = F.pad(x_, (pad_len, 0))  # causal padding on the left
        y = self.conv(x_)
        return rearrange(y, "b d n -> b n d")


class MSCM(nn.Module):
    """Two-scale 1-D depth-wise causal convolution mixer."""

    def __init__(self, d_model: int, kernel_size: int = 3, dropout: float = 0.1):
        super().__init__()
        self.ln = RMSNorm(d_model)
        self.conv1 = _CausalDepthwiseConv1d(d_model, kernel_size, dilation=1)
        self.conv2 = _CausalDepthwiseConv1d(d_model, kernel_size, dilation=3)
        self.gate = nn.GLU(dim=-1)
        self.out = nn.Linear(d_model, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        residual = x
        x = self.ln(x)
        y1, y2 = self.conv1(x), self.conv2(x)
        y = self.gate(torch.cat([y1, y2], dim=-1))
        y = self.out(y)
        return residual + self.dropout(y)


# -------------------------------------------------------------------------------------
# 3. Exponential Recurrent Memory (unchanged maths, RMSNorm-ified)
# -------------------------------------------------------------------------------------
class ExponentialMemory(nn.Module):
    """Light-weight gated exponential moving-average memory (O(N))."""

    def __init__(self, d_model: int, dropout: float = 0.1, chunk_size: int = 256):
        super().__init__()
        self.chunk_size = chunk_size
        self.log_decay = nn.Parameter(torch.zeros(d_model))  # sigmoid(log_decay) in (0,1)
        self.gate_proj = nn.Linear(d_model, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)
        self.ln = RMSNorm(d_model)

    def _step_chunk(
        self,
        x_chunk: torch.Tensor,  # (B, S, D)
        memory: torch.Tensor,  # (B, D)
        a: torch.Tensor,  # (1, D)
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        B, S, D = x_chunk.shape
        out = torch.empty_like(x_chunk)
        for i in range(S):  # small – S <= chunk_size (<=256)
            x_t = x_chunk[:, i]
            memory = a * memory + (1.0 - a) * x_t
            g_t = torch.sigmoid(self.gate_proj(x_t))
            out[:, i] = x_t + g_t * memory
        return out, memory

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        x = self.ln(x)
        B, N, D = x.shape
        a = torch.sigmoid(self.log_decay).unsqueeze(0)  # (1, D)
        memory = torch.zeros((B, D), device=x.device, dtype=x.dtype)

        out_chunks: List[torch.Tensor] = []
        for start in range(0, N, self.chunk_size):
            end = min(start + self.chunk_size, N)
            chunk, memory = self._step_chunk(x[:, start:end], memory, a)
            out_chunks.append(chunk)
        y = torch.cat(out_chunks, dim=1)
        return self.dropout(y)


# -------------------------------------------------------------------------------------
# Encoder block – Attention → MoE-FF → Conv-Mixer → Memory (all LayerScaled)
# -------------------------------------------------------------------------------------
class EncoderBlock(nn.Module):
    def __init__(
        self,
        d_model: int,
        n_heads: int,
        d_ff: int,
        chunk_size: int,
        dropout: float,
        drop_path: float,
        n_experts: int = 4,
    ) -> None:
        super().__init__()
        layerscale_init = 1e-4  # tiny initial value as in CaiT / ConvNeXt

        # 1. Attention
        self.ln1 = RMSNorm(d_model)
        self.attn = ChunkwiseCausalLinearSelfAttention(
            d_model,
            n_heads,
            chunk_size=chunk_size,
            dropout=dropout,
        )
        self.gamma_attn = nn.Parameter(layerscale_init * torch.ones(d_model))

        # 2. Mixture-of-Experts feed-forward
        self.ln2 = RMSNorm(d_model)
        self.ff = MoEGEGLU(d_model, d_ff, n_experts=n_experts, dropout=dropout)
        self.gamma_ff = nn.Parameter(layerscale_init * torch.ones(d_model))

        # 3. Conv mixer (contains its own residual internally)
        self.conv_mixer = MSCM(d_model, dropout=dropout)

        # 4. Exponential recurrent memory
        self.memory = ExponentialMemory(d_model, dropout=dropout, chunk_size=chunk_size)
        self.gamma_mem = nn.Parameter(layerscale_init * torch.ones(d_model))

        # Regularisation
        self.drop_path = DropPath(drop_path) if drop_path > 0.0 else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B, N, D)
        x = x + self.drop_path(self.gamma_attn * self.attn(self.ln1(x)))
        x = x + self.drop_path(self.gamma_ff * self.ff(self.ln2(x)))
        x = self.conv_mixer(x)
        x = x + self.drop_path(self.gamma_mem * self.memory(x))
        return x


# -------------------------------------------------------------------------------------
# DeltaNet – main model
# -------------------------------------------------------------------------------------
class DeltaNet(nn.Module):
    """DeltaNet – linear attention + MoE feed-forward + conv mixer + recurrent memory + RoPE + RMSNorm + LayerScale."""

    def __init__(
        self,
        d_model: int = 512,
        n_heads: int = 8,
        num_layers: int = 6,
        d_ff: int = 2048,
        chunk_size: int = 256,
        dropout: float = 0.1,
        drop_path: float = 0.05,
        n_experts: int = 4,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        dpr = (
            [drop_path * i / (num_layers - 1) for i in range(num_layers)]
            if num_layers > 1
            else [drop_path]
        )
        self.layers = nn.ModuleList(
            [
                EncoderBlock(
                    d_model,
                    n_heads,
                    d_ff,
                    chunk_size,
                    dropout,
                    dpr[i],
                    n_experts=n_experts,
                )
                for i in range(num_layers)
            ]
        )
        self.final_norm = RMSNorm(d_model)

    # Compile only heavy forward pass to avoid overhead on helpers
    @torch.compile(mode="reduce-overhead")  # type: ignore[misc]
    def forward(self, x: torch.Tensor, **kwargs) -> torch.Tensor:  # (B, N, D)
        for layer in self.layers:
            x = layer(x)
        return self.final_norm(x)
