#!/usr/bin/env python3
"""
Advanced Synthesizer Engine
Professional-quality synthesis for beautiful musical timbres
"""

import numpy as np
import logging
from typing import Dict, List, Tuple, Optional
from enum import Enum
import scipy.signal as signal
from dataclasses import dataclass

logger = logging.getLogger(__name__)

class WaveformType(Enum):
    SINE = "sine"
    SAWTOOTH = "sawtooth"
    SQUARE = "square"
    TRIANGLE = "triangle"
    NOISE = "noise"
    PLUCK = "pluck"
    PAD = "pad"

@dataclass
class EnvelopeADSR:
    """Advanced ADSR envelope with curves"""
    attack: float = 0.01
    decay: float = 0.1
    sustain: float = 0.7
    release: float = 0.3
    attack_curve: float = 1.0  # Exponential curve factor
    decay_curve: float = 1.0
    release_curve: float = 1.0

@dataclass
class FilterParams:
    """Advanced filter parameters"""
    cutoff: float = 1000.0
    resonance: float = 0.1
    filter_type: str = "lowpass"  # "lowpass", "highpass", "bandpass"
    envelope_amount: float = 0.0

@dataclass
class LFOParams:
    """Low Frequency Oscillator parameters"""
    frequency: float = 5.0
    depth: float = 0.1
    waveform: WaveformType = WaveformType.SINE
    target: str = "pitch"  # "pitch", "amplitude", "filter"

class AdvancedSynthesizer:
    """
    Professional-quality synthesizer engine
    Produces beautiful, rich timbres for musical expression
    """

    def __init__(self, sample_rate: float = 48000):
        self.sample_rate = sample_rate
        logger.info(f"Initialized Advanced Synthesizer at {sample_rate} Hz")

    def synthesize_note(self,
                       pitch: int,
                       velocity: int,
                       duration: float,
                       voice_name: str,
                       timbre_type: str,
                       envelope: Optional[EnvelopeADSR] = None,
                       filter_params: Optional[FilterParams] = None,
                       lfo_params: Optional[LFOParams] = None) -> np.ndarray:
        """
        Synthesize a single note with advanced synthesis techniques
        """
        # Convert MIDI pitch to frequency
        frequency = self._midi_to_frequency(pitch)

        # Normalize velocity (0-127 to 0-1)
        amplitude = (velocity / 127.0) ** 0.5  # Velocity curve

        # Generate time array
        sample_count = int(duration * self.sample_rate)
        t = np.linspace(0, duration, sample_count, endpoint=False)

        # Generate waveform based on timbre type
        waveform = self._generate_waveform(frequency, t, timbre_type, amplitude)

        # Apply LFO modulation
        if lfo_params:
            waveform = self._apply_lfo(waveform, t, frequency, lfo_params)

        # Apply envelope
        if envelope is None:
            envelope = self._get_default_envelope(timbre_type)

        envelope_curve = self._generate_envelope(sample_count, duration, envelope)
        waveform *= envelope_curve

        # Apply filtering
        if filter_params:
            waveform = self._apply_filter(waveform, filter_params, envelope_curve)

        # Apply final processing
        waveform = self._apply_final_processing(waveform, timbre_type)

        return waveform

    def _midi_to_frequency(self, midi_note: int) -> float:
        """Convert MIDI note number to frequency"""
        return 440.0 * (2.0 ** ((midi_note - 69) / 12.0))

    def _generate_waveform(self, frequency: float, t: np.ndarray,
                          timbre_type: str, amplitude: float) -> np.ndarray:
        """Generate waveform with rich harmonic content"""

        if timbre_type == "sine":
            return self._generate_sine_wave(frequency, t, amplitude)

        elif timbre_type == "sawtooth":
            return self._generate_sawtooth_wave(frequency, t, amplitude)

        elif timbre_type == "square":
            return self._generate_square_wave(frequency, t, amplitude)

        elif timbre_type == "triangle":
            return self._generate_triangle_wave(frequency, t, amplitude)

        elif timbre_type == "pluck":
            return self._generate_plucked_string(frequency, t, amplitude)

        elif timbre_type == "pad":
            return self._generate_pad_sound(frequency, t, amplitude)

        elif timbre_type == "noise":
            return self._generate_noise_percussion(frequency, t, amplitude)

        else:
            # Default to enhanced sine
            return self._generate_sine_wave(frequency, t, amplitude)

    def _generate_sine_wave(self, frequency: float, t: np.ndarray, amplitude: float) -> np.ndarray:
        """Generate rich sine wave with harmonics"""
        fundamental = np.sin(2 * np.pi * frequency * t)

        # Add harmonics for richness
        harmonic2 = 0.3 * np.sin(2 * np.pi * frequency * 2 * t)
        harmonic3 = 0.15 * np.sin(2 * np.pi * frequency * 3 * t)
        harmonic4 = 0.08 * np.sin(2 * np.pi * frequency * 4 * t)

        return amplitude * (fundamental + harmonic2 + harmonic3 + harmonic4)

    def _generate_sawtooth_wave(self, frequency: float, t: np.ndarray, amplitude: float) -> np.ndarray:
        """Generate bright sawtooth wave with controlled harmonics"""
        # Start with basic sawtooth
        sawtooth = signal.sawtooth(2 * np.pi * frequency * t)

        # Filter high frequencies to avoid aliasing and harshness
        nyquist = self.sample_rate / 2
        cutoff = min(frequency * 10, nyquist * 0.4)  # Adaptive filtering

        # Design lowpass filter
        sos = signal.butter(4, cutoff / nyquist, btype='low', output='sos')
        filtered_sawtooth = signal.sosfilt(sos, sawtooth)

        return amplitude * filtered_sawtooth

    def _generate_square_wave(self, frequency: float, t: np.ndarray, amplitude: float) -> np.ndarray:
        """Generate warm square wave"""
        square = signal.square(2 * np.pi * frequency * t)

        # Soften the square wave
        nyquist = self.sample_rate / 2
        cutoff = min(frequency * 8, nyquist * 0.3)

        sos = signal.butter(3, cutoff / nyquist, btype='low', output='sos')
        filtered_square = signal.sosfilt(sos, square)

        return amplitude * filtered_square

    def _generate_triangle_wave(self, frequency: float, t: np.ndarray, amplitude: float) -> np.ndarray:
        """Generate smooth triangle wave"""
        triangle = signal.sawtooth(2 * np.pi * frequency * t, width=0.5)
        return amplitude * triangle

    def _generate_plucked_string(self, frequency: float, t: np.ndarray, amplitude: float) -> np.ndarray:
        """Generate realistic plucked string sound using Karplus-Strong algorithm"""
        # Initialize with noise burst
        period_samples = int(self.sample_rate / frequency)
        delay_line = np.random.random(period_samples) * 2 - 1

        # Generate output
        output = np.zeros(len(t))

        for i in range(len(t)):
            # Output current sample
            output[i] = delay_line[0]

            # Karplus-Strong filtering
            new_sample = 0.5 * (delay_line[0] + delay_line[1])
            new_sample *= 0.996  # Decay factor

            # Shift delay line
            delay_line[:-1] = delay_line[1:]
            delay_line[-1] = new_sample

        return amplitude * output

    def _generate_pad_sound(self, frequency: float, t: np.ndarray, amplitude: float) -> np.ndarray:
        """Generate warm, evolving pad sound"""
        # Multiple detuned oscillators
        base_freq = frequency

        osc1 = np.sin(2 * np.pi * base_freq * t)
        osc2 = np.sin(2 * np.pi * (base_freq * 1.003) * t)  # Slightly detuned
        osc3 = np.sin(2 * np.pi * (base_freq * 0.997) * t)  # Slightly detuned down

        # Add some harmonics
        harmonic2 = 0.4 * np.sin(2 * np.pi * base_freq * 2 * t)
        harmonic3 = 0.2 * np.sin(2 * np.pi * base_freq * 3 * t)

        # Combine with slight chorusing effect
        combined = (osc1 + osc2 + osc3) / 3.0 + (harmonic2 + harmonic3)

        # Add slow amplitude modulation for movement
        lfo = 1.0 + 0.1 * np.sin(2 * np.pi * 0.3 * t)  # 0.3 Hz LFO

        return amplitude * combined * lfo

    def _generate_noise_percussion(self, frequency: float, t: np.ndarray, amplitude: float) -> np.ndarray:
        """Generate noise-based percussion sound"""
        # Filtered noise burst
        noise = np.random.random(len(t)) * 2 - 1

        # Filter around the frequency for tonal color
        nyquist = self.sample_rate / 2
        low_cutoff = max(frequency * 0.5, 100) / nyquist
        high_cutoff = min(frequency * 2, nyquist * 0.4) / nyquist

        # Bandpass filter
        sos = signal.butter(4, [low_cutoff, high_cutoff], btype='band', output='sos')
        filtered_noise = signal.sosfilt(sos, noise)

        # Add pitched component for musicality
        pitched = 0.3 * np.sin(2 * np.pi * frequency * t)

        return amplitude * (0.7 * filtered_noise + 0.3 * pitched)

    def _get_default_envelope(self, timbre_type: str) -> EnvelopeADSR:
        """Get appropriate envelope for timbre type"""
        envelopes = {
            "sine": EnvelopeADSR(0.01, 0.1, 0.7, 0.3),
            "sawtooth": EnvelopeADSR(0.01, 0.2, 0.6, 0.4),
            "square": EnvelopeADSR(0.02, 0.3, 0.8, 0.5),
            "triangle": EnvelopeADSR(0.02, 0.15, 0.7, 0.4),
            "pluck": EnvelopeADSR(0.001, 0.1, 0.3, 0.8),
            "pad": EnvelopeADSR(0.1, 0.5, 0.9, 1.2),
            "noise": EnvelopeADSR(0.001, 0.05, 0.1, 0.15),
        }
        return envelopes.get(timbre_type, EnvelopeADSR())

    def _generate_envelope(self, sample_count: int, duration: float, envelope: EnvelopeADSR) -> np.ndarray:
        """Generate ADSR envelope with curves"""
        env = np.zeros(sample_count)

        # Calculate phase lengths in samples
        attack_samples = int(envelope.attack * self.sample_rate)
        decay_samples = int(envelope.decay * self.sample_rate)
        release_samples = int(envelope.release * self.sample_rate)

        # Ensure we don't exceed total duration
        attack_samples = min(attack_samples, sample_count // 4)
        decay_samples = min(decay_samples, sample_count // 4)
        release_samples = min(release_samples, sample_count // 2)

        sustain_samples = sample_count - attack_samples - decay_samples - release_samples
        sustain_samples = max(0, sustain_samples)

        current_sample = 0

        # Attack phase with curve
        if attack_samples > 0:
            t_attack = np.linspace(0, 1, attack_samples)
            env[current_sample:current_sample + attack_samples] = \
                np.power(t_attack, envelope.attack_curve)
            current_sample += attack_samples

        # Decay phase with curve
        if decay_samples > 0:
            t_decay = np.linspace(1, envelope.sustain, decay_samples)
            if envelope.decay_curve != 1.0:
                curve_factor = np.linspace(0, 1, decay_samples)
                curve_factor = np.power(curve_factor, envelope.decay_curve)
                t_decay = 1 + (envelope.sustain - 1) * curve_factor
            env[current_sample:current_sample + decay_samples] = t_decay
            current_sample += decay_samples

        # Sustain phase
        if sustain_samples > 0:
            env[current_sample:current_sample + sustain_samples] = envelope.sustain
            current_sample += sustain_samples

        # Release phase with curve
        if release_samples > 0 and current_sample < sample_count:
            remaining_samples = sample_count - current_sample
            release_samples = min(release_samples, remaining_samples)
            t_release = np.linspace(envelope.sustain, 0, release_samples)
            if envelope.release_curve != 1.0:
                curve_factor = np.linspace(0, 1, release_samples)
                curve_factor = np.power(curve_factor, envelope.release_curve)
                t_release = envelope.sustain * (1 - curve_factor)
            env[current_sample:current_sample + release_samples] = t_release

        return env

    def _apply_lfo(self, waveform: np.ndarray, t: np.ndarray,
                   frequency: float, lfo_params: LFOParams) -> np.ndarray:
        """Apply LFO modulation"""
        if lfo_params.target == "pitch":
            # Vibrato
            lfo_wave = np.sin(2 * np.pi * lfo_params.frequency * t)
            freq_mod = frequency * (1 + lfo_params.depth * lfo_wave)
            # This would require re-generating the waveform, simplified for now
            return waveform * (1 + 0.1 * lfo_params.depth * lfo_wave)

        elif lfo_params.target == "amplitude":
            # Tremolo
            lfo_wave = np.sin(2 * np.pi * lfo_params.frequency * t)
            amp_mod = 1 + lfo_params.depth * lfo_wave
            return waveform * amp_mod

        return waveform

    def _apply_filter(self, waveform: np.ndarray,
                     filter_params: FilterParams,
                     envelope: np.ndarray) -> np.ndarray:
        """Apply frequency filtering"""
        nyquist = self.sample_rate / 2
        cutoff = filter_params.cutoff / nyquist

        # Modulate cutoff with envelope if desired
        if filter_params.envelope_amount > 0:
            # This is simplified - real implementation would apply per-sample
            cutoff *= (1 + filter_params.envelope_amount * np.mean(envelope))

        cutoff = np.clip(cutoff, 0.01, 0.99)

        try:
            if filter_params.filter_type == "lowpass":
                sos = signal.butter(4, cutoff, btype='low', output='sos')
            elif filter_params.filter_type == "highpass":
                sos = signal.butter(4, cutoff, btype='high', output='sos')
            elif filter_params.filter_type == "bandpass":
                low_cutoff = cutoff * 0.5
                high_cutoff = cutoff * 1.5
                sos = signal.butter(4, [low_cutoff, high_cutoff], btype='band', output='sos')
            else:
                return waveform

            # Add resonance (simplified)
            if filter_params.resonance > 0:
                # Boost around cutoff frequency
                peak_freq = filter_params.cutoff / nyquist
                peak_gain = 1 + filter_params.resonance * 3
                sos_peak = signal.butter(2, [peak_freq * 0.9, peak_freq * 1.1],
                                       btype='band', output='sos')
                resonance_boost = signal.sosfilt(sos_peak, waveform) * filter_params.resonance
                waveform = waveform + resonance_boost

            return signal.sosfilt(sos, waveform)

        except Exception as e:
            logger.warning(f"Filter application failed: {e}")
            return waveform

    def _apply_final_processing(self, waveform: np.ndarray, timbre_type: str) -> np.ndarray:
        """Apply final processing and effects"""
        # Soft saturation for warmth
        waveform = np.tanh(waveform * 0.7) / 0.7

        # Dynamic range control
        max_amp = np.max(np.abs(waveform))
        if max_amp > 0:
            # Gentle compression
            threshold = 0.7
            if max_amp > threshold:
                ratio = 0.3
                over_thresh = waveform * (max_amp > threshold)
                waveform = np.where(np.abs(waveform) > threshold,
                                  threshold + (waveform - threshold) * ratio,
                                  waveform)

        # Final normalization
        max_final = np.max(np.abs(waveform))
        if max_final > 0:
            waveform = waveform / max_final * 0.8  # Leave headroom

        return waveform

    def mix_voices(self, voice_audio_list: List[Tuple[np.ndarray, str, str]]) -> np.ndarray:
        """
        Mix multiple voice parts with intelligent balancing
        voice_audio_list: List of (audio, voice_name, role) tuples
        """
        if not voice_audio_list:
            return np.array([])

        # Find maximum length
        max_length = max(len(audio) for audio, _, _ in voice_audio_list)

        # Initialize mix
        mixed_audio = np.zeros(max_length)

        # Voice balance based on role
        role_gains = {
            "melody": 0.8,    # Prominent
            "bass": 0.7,      # Strong foundation
            "harmony": 0.5,   # Supporting
            "pad": 0.4,       # Background
            "percussion": 0.6  # Rhythmic accent
        }

        for audio, voice_name, role in voice_audio_list:
            # Pad audio to max length
            if len(audio) < max_length:
                padded_audio = np.zeros(max_length)
                padded_audio[:len(audio)] = audio
                audio = padded_audio
            else:
                audio = audio[:max_length]

            # Apply role-based gain
            gain = role_gains.get(role, 0.5)
            mixed_audio += audio * gain

        # Master processing
        # Gentle compression
        max_amp = np.max(np.abs(mixed_audio))
        if max_amp > 0:
            # Normalize then apply soft limiting
            mixed_audio = mixed_audio / max_amp
            mixed_audio = np.tanh(mixed_audio * 0.9) * 0.9

        return mixed_audio