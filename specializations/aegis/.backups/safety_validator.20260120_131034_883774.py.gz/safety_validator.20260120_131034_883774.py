"""Safety Validator – Rule-based & Extensible Guardrail System
==================================================================
This module implements a lightweight yet *extensible* safety validation
pipeline for agent actions.  It replaces the previous placeholder while
**preserving** the historical public symbol ``DeltaNet`` via an alias so
that any legacy import paths remain functional.

Key features (ON by default):
1. **Rule-based core with Regex patterns**
   • Fast, deterministic validation against disallowed keywords and regexes.
2. **Pluggable Custom Rules**
   • Users / higher-level systems can register additional callables that
     implement bespoke safety checks (sync *or* async).
3. **Context-aware Validation Hooks**
   • Rules receive both the *action* **and** its *context* (arbitrary
     mapping) enabling nuanced decisions (e.g. rate-limits, user roles).
4. **LRU Cache**
   • Recent validation results are memoised for speed – avoids repeated work
     when the same action is evaluated in rapid succession.
5. **Async-compatible API**
   • ``async_is_safe`` seamlessly awaits async custom rules, making the
     validator usable in modern event-driven agents.
6. **Severity Scoring**
   • Each violation carries a weight; the aggregate *safety score* helps
     downstream components decide whether to refuse, request clarification or
     route to a human overseer.

Public API (stable):
    class SafetyValidator
        ├─ is_safe(action: str, context: Optional[Mapping]=None) -> bool
        ├─ validate(action: str, context: Optional[Mapping]=None) -> SafetyResult
        ├─ async_is_safe(...)                                (async)
        ├─ register_rule(rule_fn, *, name=None, weight=1.0)  (class-method)
        └─ clear_cache()                                     (class-method)

Backward-compat:** ``DeltaNet`` is retained *as an alias* to
``SafetyValidator`` so legacy code importing that symbol from this module
continues to work without modification.
"""
from __future__ import annotations

import asyncio
import logging
import re
from functools import lru_cache
from typing import Any, Awaitable, Callable, Iterable, List, Mapping, MutableMapping, NamedTuple, Tuple

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

__all__ = [
    "SafetyValidator",  # modern name
    "DeltaNet",         # legacy alias (compat)
    "SafetyResult",     # helper tuple type
]

RuleFn = Callable[[str, Mapping[str, Any] | None], Tuple[bool, str, float]]
# Returns: (is_safe, message, severity_weight)
#   • is_safe==True  → rule passes (no violation)
#   • is_safe==False → violation described by *message*
#                      and weighted by *severity_weight* (>=0)


class SafetyResult(NamedTuple):
    """Structured validation outcome returned by *validate()*"""

    is_safe: bool
    violations: List[str]
    score: float  # aggregate severity (∑ weights)


# -----------------------------------------------------------------------------
#  Default rule implementations
# -----------------------------------------------------------------------------

# NOTE: these starter rules are intentionally *conservative*.  They can be
#       tuned or complemented by the calling application via *register_rule*.

_FORBIDDEN_KEYWORDS: Iterable[str] = [
    "kill",
    "murder",
    "bomb",
    "terror",
    "suicide",
    "self\-harm",
    "child",
    "porn",
    "nuke",
    "hack",
]

_FORBIDDEN_REGEXES = [
    re.compile(r"(?:https?://)?(?:[\w.-]+)\.(?:onion|ru|xxx|blackmarket)", re.I),
    re.compile(r"\bcredit\s*card\s*number\b", re.I),
]


def _keyword_rule(action: str, _context: Mapping[str, Any] | None = None) -> Tuple[bool, str, float]:
    lowered = action.lower()
    for kw in _FORBIDDEN_KEYWORDS:
        if kw in lowered:
            return False, f"forbidden keyword '{kw}' detected", 1.0
    return True, "", 0.0


def _regex_rule(action: str, _context: Mapping[str, Any] | None = None) -> Tuple[bool, str, float]:
    for rx in _FORBIDDEN_REGEXES:
        if rx.search(action):
            return False, "forbidden pattern matched", 1.2
    return True, "", 0.0


# -----------------------------------------------------------------------------
#  Safety Validator – main class
# -----------------------------------------------------------------------------
class SafetyValidator:  # pylint: disable=too-few-public-methods
    """Lightweight rule-based validator with pluggable extensions."""

    # Class-level registry so rules are shared across instances -------------
    _rules: List[Tuple[str, RuleFn]] = [
        ("keyword_rule", _keyword_rule),
        ("regex_rule", _regex_rule),
    ]

    # ------------------------------------------------------------------
    #  Rule registration helpers
    # ------------------------------------------------------------------
    @classmethod
    def register_rule(
        cls,
        rule_fn: RuleFn,
        *,
        name: str | None = None,
        weight: float | None = None,
    ) -> None:
        """Register *rule_fn* (sync **or** async) for future validations.

        Parameters
        ----------
        rule_fn: Callable[[str, Mapping|None], Tuple[bool, str, float]]
            Function that evaluates *(action, context)* → (is_safe, msg, weight).
        name: str | None
            Optional unique rule identifier (defaults to *rule_fn.__name__*).
        weight: float | None
            If provided **overrides** the third return value (severity weight)
            of *rule_fn*.  Useful when the function does not expose an
            intrinsic severity.
        """
        rule_name = name or getattr(rule_fn, "__name__", "anonymous_rule")
        if any(existing_name == rule_name for existing_name, _ in cls._rules):
            raise ValueError(f"Safety rule with name '{rule_name}' already registered")

        if weight is not None:
            # Wrap to inject / override weight while preserving message
            def _wrapped(action: str, ctx: Mapping[str, Any] | None = None):  # type: ignore[override]
                is_safe, msg, _old_weight = rule_fn(action, ctx)  # pylint: disable=unused-variable
                return is_safe, msg, float(weight)

            cls._rules.append((rule_name, _wrapped))
        else:
            cls._rules.append((rule_name, rule_fn))
        # Invalidate cache – new rule affects outcomes
        cls.clear_cache()
        logger.info("SafetyValidator: registered rule '%s' (total=%d)", rule_name, len(cls._rules))

    # ------------------------------------------------------------------
    #  Cache helpers
    # ------------------------------------------------------------------
    @classmethod
    def clear_cache(cls) -> None:
        """Flush the internal LRU cache (useful when rules are updated)."""

        cls._validate_cached.cache_clear()  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    #  Public API – synchronous
    # ------------------------------------------------------------------
    @classmethod
    def is_safe(cls, action: str, *, context: Mapping[str, Any] | None = None) -> bool:
        """Boolean convenience wrapper around *validate* (sync).

        Returns **True** iff *all* rules pass.
        """
        return cls.validate(action, context=context).is_safe

    @classmethod
    def validate(
        cls, action: str, *, context: Mapping[str, Any] | None = None
    ) -> SafetyResult:
        """Run all registered rules and return a structured *SafetyResult*."""
        return cls._validate_cached(action, _freeze_context(context))

    # ------------------------------------------------------------------
    #  Internal cached validation routine (sync only)
    # ------------------------------------------------------------------
    @classmethod
    @lru_cache(maxsize=4096)
    def _validate_cached(
        cls, action: str, frozen_ctx: Tuple[Tuple[str, Any], ...] | None
    ) -> SafetyResult:
        # Convert back to mapping for rule consumption
        ctx: MutableMapping[str, Any] | None = dict(frozen_ctx) if frozen_ctx else None
        is_safe = True
        violations: List[str] = []
        score = 0.0
        for name, rule in cls._rules:
            try:
                ok, msg, sev = rule(action, ctx)  # type: ignore[arg-type]
            except Exception as exc:  # pragma: no cover – defensive guard
                logger.exception("Safety rule '%s' failed with error: %s", name, exc)
                ok, msg, sev = False, f"rule_error: {exc}", 2.0
            if not ok:
                is_safe = False
                violations.append(msg or name)
                score += sev
        return SafetyResult(is_safe=is_safe, violations=violations, score=round(score, 3))

    # ------------------------------------------------------------------
    #  Public API – asynchronous version
    # ------------------------------------------------------------------
    @classmethod
    async def async_is_safe(
        cls, action: str, *, context: Mapping[str, Any] | None = None
    ) -> bool:
        """Awaitable boolean helper."""
        res = await cls.async_validate(action, context=context)
        return res.is_safe

    @classmethod
    async def async_validate(
        cls, action: str, *, context: Mapping[str, Any] | None = None
    ) -> SafetyResult:
        """Async variant that awaits coroutine rules if necessary.

        Sync rules are executed in-line.  coroutine
        rules (i.e. *async def*) are *awaited* preserving full concurrency.
        The results are **not** cached since async rule side-effects often
        depend on external state (e.g. rate-limit, remote API checks).
        """
        ctx = context or {}
        is_safe = True
        violations: List[str] = []
        score = 0.0

        for name, rule in cls._rules:
            try:
                maybe_coro = rule(action, ctx)
                if isinstance(maybe_coro, Awaitable):
                    ok, msg, sev = await maybe_coro  # type: ignore[assignment]
                else:
                    ok, msg, sev = maybe_coro  # type: ignore[misc]
            except Exception as exc:  # pragma: no cover
                logger.exception("Async safety rule '%s' errored: %s", name, exc)
                ok, msg, sev = False, f"rule_error: {exc}", 2.0
            if not ok:
                is_safe = False
                violations.append(msg or name)
                score += sev

        return SafetyResult(is_safe=is_safe, violations=violations, score=round(score, 3))


# -----------------------------------------------------------------------------
#  Helper utilities
# -----------------------------------------------------------------------------

def _freeze_context(ctx: Mapping[str, Any] | None) -> Tuple[Tuple[str, Any], ...] | None:
    """Convert potentially mutable *context* mapping into a hashable tuple so
    it can participate in the LRU cache key.  *None* is propagated through."""
    if ctx is None:
        return None
    # Sort keys to ensure deterministic ordering → stable cache keys
    return tuple(sorted(ctx.items()))


# -----------------------------------------------------------------------------
#  Backward-compat symbol
# -----------------------------------------------------------------------------
# Historically, other modules *may* import ``DeltaNet`` from this path due to an
# earlier placeholder implementation.  We alias it here to the new
# ``SafetyValidator`` class to avoid breaking such imports while gently nudging
# developers towards the correct symbol.
DeltaNet = SafetyValidator
